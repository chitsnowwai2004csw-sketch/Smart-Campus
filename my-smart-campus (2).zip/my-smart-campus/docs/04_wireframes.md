# Section 4: UI Wireframe & Layout Specifications

**Project:** Smart Campus Smart Building Monitoring System
**Developer:** Chit Snow Wai

Wireframes map directly to the implemented `templates/*.html` files in the codebase.

---

## 4.1 Dashboard Page — `/`

**Template:** `templates/dashboard.html`
**Access:** All authenticated users
**Layout:** Top navbar + 3 summary widgets row + 3 Chart.js graphs row + Recent tickets table

### ASCII Wireframe

```
+--------------------------------------------------------------+
| Smart Campus [Dashboard | Telemetry | Equipment | Maint | Dev]|
| Hi, Chit Snow Wai  [admin]                  [Sign Out]       |
+--------------------------------------------------------------+
|                                                              |
| Operations Dashboard                                         |
|                                                              |
| +-- Total Equipment 12 --+ +-- Active Alerts 2 --+ +-- Open 3 -+|
| | (hdd-rack icon)       | | (warn icon)        | | (tools)  ||
| +-----------------------+ +---------------------+ +---------+|
|                                                              |
| +-- Temperature ---+ +-- Humidity ----+ +-- Air Quality -+   |
| |  line chart 24h  | | line chart     | | line chart     |   |
| |  (Chart.js red)  | | (Chart.js blue)| | (Chart.js green)|  |
| +------------------+ +----------------+ +-----------------+   |
|                                                              |
| Recent Maintenance Tickets                                   |
| +--+----------------+---------+----------+----------+-------+|
| |ID|Title          |Reporter |Priority |Status    |Date   ||
| |#3|Sensor calib   |dev      |Low      |Resolved  |...    ||
| |#2|Light flicker  |staff    |High     |In Progr  |...    ||
| |#1|AC rattling    |staff    |Medium   |Open      |...    ||
| +--+----------------+---------+----------+----------+-------+|
+--------------------------------------------------------------+
| Smart Campus v1.0.0  © 2026 Chit Snow Wai                     |
+--------------------------------------------------------------+
```

### Component Map

| Component | Bootstrap Class | Data Source |
|-----------|----------------|-------------|
| Navbar | `navbar navbar-dark smart-navbar` | Static |
| Equipment widget | `card widget-card` w/ icon `bi-hdd-rack` | `stats.equipment_total` |
| Alerts widget | `card widget-card` w/ icon `bi-exclamation-triangle` | `stats.active_alerts` |
| Tickets widget | `card widget-card` w/ icon `bi-tools` | `stats.open_tickets` |
| 3 Charts | `card` containing `<canvas>` + Chart.js | `/api/telemetry/latest` |
| Recent table | `table table-hover` | `recent` rows from SQLite |

### Color Tokens (Badge Mapping)

- Priority: `Low` = secondary (gray), `Medium` = warning (yellow), `High` = danger (red)
- Status: `Open` = primary (blue), `In Progress` = info (cyan), `Resolved` = success (green)

---

## 4.2 Equipment Monitoring Page — `/equipment`

**Template:** `templates/equipment.html`
**Access:** All authenticated users (read-only); Admin/Developer can override status
**Layout:** Full-width filterable table

### ASCII Wireframe

```
+--------------------------------------------------------------+
| Smart Campus [Dashboard | Telemetry | Equipment | ... ]       |
+--------------------------------------------------------------+
| Equipment Monitoring                                         |
| +------------------------------------------------------+     |
| | # | Name           | Location       | Status    | ...|     |
| +---+----------------+----------------+-----------+-----+     |
| | 1 | HVAC Unit A1   | Block A Fl 1   | OPERATIONAL |  |     |
| | 2 | HVAC Unit A2   | Block A Fl 2   | MAINT REQ |  |     |
| | 3 | Lighting B1    | Block B Lobby  | OPERATIONAL |  |     |
| | 4 | Lighting B2    | Block B Library| OFFLINE   |  |     |
| | 5 | Main Dist Board| Block C Base   | OPERATIONAL |  |     |
| +---+----------------+----------------+-----------+-----+     |
|                                                              |
| Admin Actions (visible only to admin/developer):             |
|   [Select dropdown ▼]  [Save button]                         |
+--------------------------------------------------------------+
```

### Status Badge Styles

| Status | Bootstrap Class | Visual |
|--------|----------------|--------|
| Operational | `bg-success` | Green |
| Maintenance Required | `bg-warning` | Yellow |
| Offline | `bg-danger` | Red |

### Interactive Elements (Admin/Developer only)

- Dropdown: `<select class="form-select form-select-sm status-select">`
- Button: `<button class="btn btn-sm btn-primary save-status">`
- AJAX endpoint: `POST /api/equipment/<id>/status` (JSON body)
- JS handler: `static/js/equipment.js` updates badge color in place

---

## 4.3 Maintenance Workflow Page — `/maintenance`

**Template:** `templates/maintenance.html`
**Access:** All authenticated users (submit); Admin/Developer can update
**Layout:** Two-column split — submission form (left) + ticket tracker (right)

### ASCII Wireframe

```
+--------------------------------------------------------------+
| Smart Campus [Dashboard | Telemetry | Equipment | Maintenance]|
+--------------------------------------------------------------+
| Maintenance Workflow                                         |
| +-- Submit Ticket -----+ +-- Ticket Tracker ---------------+ |
| | Title [_________]    | | #| Title         |Prio |Status | |
| | Desc  [_________]    | | #1| AC noise     | Med | Open  | |
| |       [_________]    | | #2| Light flick  | High| InPro | |
| | Priority [Medium ▼]  | | #3| Sensor calib | Low | Done  | |
| | [Submit Ticket]      | |                                | |
| +----------------------+ +--------------------------------+ |
|                                                              |
| Admin Update Controls (visible only to admin/developer):     |
|   [Status dropdown ▼] [Save]                                 |
+--------------------------------------------------------------+
```

### Form Specification (Left Column)

| Field | Input Type | Validation | Required |
|-------|-----------|------------|----------|
| Title | `input[type=text]` | Non-empty | Yes |
| Description | `textarea` (rows=3) | Non-empty | Yes |
| Priority | `select` (Low/Medium/High) | Enum | Yes (default Medium) |

### Ticket Tracker (Right Column)

- Bootstrap `table table-hover` with columns: ID, Title, Reporter, Priority, Status, Update (admin only)
- Status badge colors: `Open`=primary, `In Progress`=info, `Resolved`=success
- AJAX endpoint: `POST /api/tickets/<id>/status`

---

## 4.4 Developer Profile Page — `/developer`

**Template:** `templates/developer.html`
**Access:** All authenticated users
**Layout:** Two-column — Profile card (left) + System stats + logs (right)

### ASCII Wireframe

```
+--------------------------------------------------------------+
| Smart Campus [Dashboard | Telemetry | Equipment | Maint | Dev]|
+--------------------------------------------------------------+
| +-- Profile --------+ +-- System Statistics ---------------+ |
| |  (avatar icon)    | |  4 Users | 8 Equipment | 72 Telemetry||
| |  Chit Snow Wai    | |  3 Tickets                         | |
| |  BSc (Hons) CSE   | +--------------------------------------+|
| |  Developer Svc    | +-- System Logs ----------------------+|
| |  Build v1.0.0     | | Username | Role     | Joined        ||
| |  Python · Flask   | | admin    | admin    | 2026-08-24    ||
| |  SQLite · Chart.js| | staff    | user     | 2026-08-24    ||
| |  bcrypt · Bootstrap| | dev     | developer| 2026-08-24    ||
| +-------------------+ +-------------------------------------+|
+--------------------------------------------------------------+
```

### Profile Card Contents

- Developer name + programme
- Role: Smart Building Solutions Consultant
- Build version (dynamic from app config)
- Tech stack list (joined with ` · `)
- Client-side timestamp via `new Date().toLocaleString()`

### System Stats Row

Four-column grid displaying counts:
- `counts.users` (from SQLite `SELECT COUNT(*)`)
- `counts.equipment`
- `counts.telemetry`
- `counts.tickets`

### System Logs Table

Read-only table listing all users with: username, role badge, joined date.

---

## 4.5 Responsive Breakpoints

All templates use Bootstrap 5 grid; verified across:

| Device | Breakpoint | Behavior |
|--------|-----------|----------|
| Mobile (xs) | < 576px | Single-column stack, widgets full-width |
| Tablet (md) | 576–992px | 2-column widgets, full-width charts |
| Desktop (lg) | > 992px | 4-column widgets, 3-up charts, 2-up maintenance |

CSS variables in `static/css/custom.css`:
- `--smart-primary: #2563EB`
- `--smart-bg: #F8FAFC`
- `.smart-navbar` uses 135° linear gradient `#1E3A8A → #2563EB`

---

*End of Section 4.*

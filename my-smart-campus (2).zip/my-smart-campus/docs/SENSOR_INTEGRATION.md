# Sensor Integration Guide

This guide explains how to connect physical sensors to the Smart Campus Monitoring System.

## Overview

The system supports two sensor modes:

| Mode | Description | Use Case |
|---|---|---|
| `simulator` (default) | Generates fake random readings for demo/testing | Development, demos |
| `real` | Only accepts readings via HTTP POST | Production with real sensors |

When `SENSOR_MODE=real`, the simulator is disabled. Charts will be empty until real sensors start posting data.

---

## HTTP Ingest API

### Endpoint

```
POST /api/telemetry/ingest
```

### Authentication

Include your device API key in the `X-API-Key` header:

```
X-API-Key: <your-device-api-key>
```

The API key is configured via the `DEVICE_API_KEY` environment variable.

### Request Body (JSON)

| Field | Required | Type | Description |
|---|---|---|---|
| `sensor_type` | Yes | string | One of: `Temperature`, `Humidity`, `Air Quality`, `Energy`, `CO2` |
| `reading_value` | Yes | number | The sensor reading (finite number) |
| `unit` | No | string | Unit of measurement (defaults to canonical per type) |
| `sensor_id` | No | string | Physical sensor identifier (max 64 chars) |
| `location` | No | string | Where the sensor is installed (max 128 chars) |
| `timestamp` | No | string | ISO 8601 timestamp (defaults to server time) |

### Canonical Units

| Sensor Type | Default Unit |
|---|---|
| Temperature | C |
| Humidity | % |
| Air Quality | AQI |
| Energy | kW |
| CO2 | ppm |

### Response Codes

| Code | Meaning |
|---|---|
| 201 | Reading ingested successfully |
| 400 | Invalid request (bad sensor_type, missing value, etc.) |
| 401 | Invalid or missing API key |
| 429 | Rate limited (max 1 reading per 5s per sensor) |

### Example: curl

```bash
curl -X POST http://localhost:5050/api/telemetry/ingest \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-device-api-key-here" \
  -d '{
    "sensor_type": "Temperature",
    "reading_value": 23.5,
    "unit": "C",
    "sensor_id": "esp32-001",
    "location": "Library 3F"
  }'
```

### Example: Python requests

```python
import requests

response = requests.post(
    "http://localhost:5050/api/telemetry/ingest",
    headers={
        "Content-Type": "application/json",
        "X-API-Key": "your-device-api-key-here"
    },
    json={
        "sensor_type": "Temperature",
        "reading_value": 23.5,
        "unit": "C",
        "sensor_id": "esp32-001",
        "location": "Library 3F"
    }
)
print(response.json())
```

---

## Sensor Types and Hardware

### Temperature + Humidity (DHT22 / AM2302)

- **Sensor**: DHT22 (AM2302)
- **Range**: -40°C to 80°C, 0-100% RH
- **Accuracy**: ±0.5°C, ±2% RH
- **Cost**: ~$3-5
- **Connect to**: ESP32 GPIO pin 4

### CO2 (MH-Z19B)

- **Sensor**: MH-Z19B (NDIR)
- **Range**: 400-5000 ppm
- **Accuracy**: ±50 ppm
- **Cost**: ~$15
- **Connect to**: ESP32 UART (TX/RX)

### Air Quality (PMS5003)

- **Sensor**: PMS5003 (particulate matter)
- **Measures**: PM1.0, PM2.5, PM10
- **Cost**: ~$10
- **Connect to**: ESP32 UART

### Energy (CT Clamp + SCT-013)

- **Sensor**: SCT-013-000 (current transformer)
- **Range**: 0-100A (depends on model)
- **Cost**: ~$8
- **Connect to**: ESP32 ADC (with burden resistor)

---

## ESP32 Arduino Sketch (WiFi + DHT22)

```cpp
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

// WiFi credentials
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

// Server config
const char* serverUrl = "http://YOUR_SERVER_IP:5050/api/telemetry/ingest";
const char* apiKey = "YOUR_DEVICE_API_KEY";

// DHT sensor
#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

// Sensor identity
const char* sensorId = "esp32-001";
const char* location = "Library 3F";

void setup() {
  Serial.begin(115200);
  dht.begin();
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    float temp = dht.readTemperature();
    float humidity = dht.readHumidity();
    
    if (!isnan(temp) && !isnan(humidity)) {
      sendReading("Temperature", temp, "C", sensorId, location);
      delay(1000);  // Rate limit: wait 1s between readings
      sendReading("Humidity", humidity, "%", sensorId, location);
    }
  }
  delay(29000);  // Wait 30s before next cycle
}

void sendReading(String type, float value, String unit, String id, String loc) {
  HTTPClient http;
  http.begin(serverUrl);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-API-Key", apiKey);
  
  String json = "{\"sensor_type\":\"" + type + "\","
                "\"reading_value\":" + String(value, 2) + ","
                "\"unit\":\"" + unit + "\","
                "\"sensor_id\":\"" + id + "\","
                "\"location\":\"" + loc + "\"}";
  
  int httpResponseCode = http.POST(json);
  Serial.println("POST " + type + ": " + String(value) + " -> " + String(httpResponseCode));
  http.end();
}
```

---

## Raspberry Pi Python Script

```python
import requests
import time
import random

SERVER_URL = "http://YOUR_SERVER_IP:5050/api/telemetry/ingest"
API_KEY = "YOUR_DEVICE_API_KEY"

SENSOR_ID = "pi-001"
LOCATION = "Server Room"

def send_reading(sensor_type, value, unit=""):
    payload = {
        "sensor_type": sensor_type,
        "reading_value": value,
        "sensor_id": SENSOR_ID,
        "location": LOCATION,
    }
    if unit:
        payload["unit"] = unit
    
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": API_KEY,
    }
    
    try:
        resp = requests.post(SERVER_URL, json=payload, headers=headers, timeout=5)
        print(f"{sensor_type}: {value} -> {resp.status_code}")
    except Exception as e:
        print(f"Error: {e}")

while True:
    # Replace with real sensor readings
    temp = 22.0 + random.uniform(-3, 3)
    humidity = 55.0 + random.uniform(-10, 10)
    
    send_reading("Temperature", round(temp, 2), "C")
    time.sleep(1)
    send_reading("Humidity", round(humidity, 2), "%")
    
    time.sleep(29)  # Wait 30s total
```

---

## Industrial PLC / Modbus Gateway

For industrial sensors that use Modbus RTU/TCP, you need a gateway to translate Modbus registers to HTTP POST requests.

### Architecture

```
[PLC / Modbus Sensor]
       |
       | RS485 / Ethernet
       v
[Modbus Gateway]
       |
       | HTTP POST /api/telemetry/ingest
       v
[Smart Campus Server]
```

### Gateway Options

1. **Raspberry Pi + pymodbus**: Read Modbus registers, POST to server
2. **Industrial gateway** (e.g., Advantech, Moxa): Built-in HTTP client
3. **Node-RED**: Visual flow-based programming for Modbus to HTTP

### Python Modbus Gateway Script

```python
#!/usr/bin/env python3
"""Modbus-to-HTTP gateway for Smart Campus."""

import requests
import time
from pymodbus.client.sync import ModbusSerialClient

SERVER_URL = "http://YOUR_SERVER_IP:5050/api/telemetry/ingest"
API_KEY = "YOUR_DEVICE_API_KEY"

# Modbus client (RS485)
client = ModbusSerialClient(
    method="rtu",
    port="/dev/ttyUSB0",
    baudrate=9600,
    parity="N",
    stopbits=1,
    bytesize=8,
    timeout=3,
)
client.connect()

def read_modbus_register(unit, address):
    """Read a single holding register."""
    result = client.read_holding_registers(address, 1, unit=unit)
    if not result.isError():
        return result.registers[0]
    return None

def send_reading(sensor_type, value, unit="", sensor_id="", location=""):
    headers = {"Content-Type": "application/json", "X-API-Key": API_KEY}
    payload = {
        "sensor_type": sensor_type,
        "reading_value": value,
        "sensor_id": sensor_id,
        "location": location,
    }
    if unit:
        payload["unit"] = unit
    try:
        resp = requests.post(SERVER_URL, json=payload, headers=headers, timeout=5)
        print(f"{sensor_type}: {value} -> {resp.status_code}")
    except Exception as e:
        print(f"Error: {e}")

# Example: Read temperature from Modbus register 0 on unit 1
while True:
    raw_temp = read_modbus_register(unit=1, address=0)
    if raw_temp is not None:
        temp = raw_temp / 10.0  # Scale factor (example: divide by 10)
        send_reading("Temperature", temp, "C", "plc-001", "HVAC Plant Room")
    
    time.sleep(5)
```

### Common Modbus Register Maps

| Device | Register | Address | Scale | Unit |
|---|---|---|---|---|
| Temperature sensor | Holding | 0 | /10 | C |
| Humidity sensor | Holding | 1 | /10 | % |
| Energy meter | Holding | 10 | /100 | kW |
| CO2 sensor | Holding | 20 | /1 | ppm |

---

## MQTT (Future Phase)

MQTT is the industry standard for IoT sensor networks. It's recommended for production deployments with many sensors.

### Architecture

```
[Sensor] -> WiFi -> [MQTT Broker] -> [Subscriber] -> [SQLite]
```

### Topic Structure

```
campus/{building}/{floor}/{sensor_type}/{sensor_id}
```

Example:
```
campus/main/library/3f/temperature/esp32-001
campus/main/hvac/1f/energy/meter-01
```

### MQTT Subscriber (Python)

```python
import paho.mqtt.client as mqtt
import json
import sqlite3

BROKER = "localhost"
PORT = 1883
TOPIC = "campus/#"

def on_message(client, userdata, msg):
    payload = json.loads(msg.payload.decode())
    # Insert into telemetry table
    conn = sqlite3.connect("instance/smart_campus.db")
    conn.execute(
        "INSERT INTO telemetry (sensor_type, reading_value, unit, timestamp, sensor_id, location, source) "
        "VALUES (?,?,?,?,?,?,?)",
        (payload["sensor_type"], payload["reading_value"], payload.get("unit", ""),
         payload.get("timestamp", ""), payload.get("sensor_id", ""),
         payload.get("location", ""), "mqtt")
    )
    conn.commit()
    conn.close()

client = mqtt.Client()
client.on_message = on_message
client.connect(BROKER, PORT)
client.subscribe(TOPIC)
client.loop_forever()
```

---

## Troubleshooting

### Charts empty after switching to `SENSOR_MODE=real`

This is expected. The simulator is disabled. You need to start posting data from real sensors via `POST /api/telemetry/ingest`.

### 401 Unauthorized

- Check that `DEVICE_API_KEY` is set in your environment
- Verify the `X-API-Key` header matches exactly
- Keys are case-sensitive

### 429 Rate Limited

- Wait 5 seconds between readings per sensor
- The rate limit is per `sensor_id` (or per `sensor_type` if no sensor_id)

### Timestamps out of order

- Ensure sensor clocks are synchronized (use NTP on ESP32/Pi)
- Server defaults to `received_at` (server time) if timestamp is invalid

### Data not appearing in charts

- Check that the `sensor_type` value is exactly one of: `Temperature`, `Humidity`, `Air Quality`, `Energy`, `CO2`
- Verify the reading is being inserted: `SELECT * FROM telemetry ORDER BY id DESC LIMIT 5;`

---

## Configuration Reference

| Environment Variable | Default | Description |
|---|---|---|
| `SENSOR_MODE` | `simulator` | `simulator` or `real` |
| `DEVICE_API_KEY` | (empty) | API key for POST /api/telemetry/ingest |
| `SECRET_KEY` | (built-in) | Flask session secret key |

### Docker Compose

```yaml
environment:
  SENSOR_MODE: "real"
  DEVICE_API_KEY: "your-secure-key-here"
```

### Command Line

```bash
SENSOR_MODE=real DEVICE_API_KEY=your-key python app.py
```

---

## Hardware Shopping List

### Per Sensor Node (ESP32-based)

| Component | Model | Approx Cost | Measures |
|---|---|---|---|
| Microcontroller | ESP32-DevKitC | $5 | WiFi + processor |
| Temp + Humidity | DHT22 | $3 | Temperature, Humidity |
| CO2 | MH-Z19B | $15 | CO2 (NDIR) |
| Air Quality | PMS5003 | $10 | PM1.0/2.5/10 (AQI) |
| Energy | SCT-013-000 | $8 | Current (kW) |
| Misc | Wires, USB, enclosure | $5 | — |
| **Total per node** | | **$10-25** | Up to 5 sensors |

### For Campus (10 zones x 5 sensors)

- Hardware: $100-250
- MQTT broker: Free (Mosquitto) or $5/mo (HiveMQ Cloud)
- Gateway (if Modbus): Raspberry Pi $35 or industrial gateway $100+

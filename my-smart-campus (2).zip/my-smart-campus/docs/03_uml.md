# Section 3: UML Diagrams

**Project:** Smart Campus Smart Building Monitoring System  
**Developer:** Chit Snow Wai  
**Build:** 1.1.0 · 12 tables · 43 routes · 3 roles · 5 sensor types

Diagrams exist in two forms:

1. **draw.io (authoritative for export):** [`SmartCampus_Design_Pack.drawio`](./SmartCampus_Design_Pack.drawio) — **exactly 4 pages**:
   1. **WBS** — full T1.1–T6.6 (200h · 19 Jul–30 Sep 2026)
   2. **UML** (one page) — Use Case · Class · Sequence Login/Ticket/Telemetry · Activity · State
   3. **ER** — SQLite 12 tables (PK/FK/UK)
   4. **Flow Chart** — application navigation & request flow (live routes)

   Textbook style (white boxes, black borders, «enumeration», multiplicities). Copy also in submission folder: `pd_1393 (2)\pd\SmartCampus_Design_Pack.drawio`. Open in [diagrams.net](https://app.diagrams.net) or VS Code Draw.io Integration; export PNG/PDF for the report.
1b. **Legacy multi-page UML:** [`SmartCampus_UML.drawio`](./SmartCampus_UML.drawio) — 10 separate UML pages (no WBS / flow); same textbook style.
2. **Mermaid (below):** GitHub / VS Code preview. Same content as the draw.io pack (notation may differ slightly from the hand-styled draw.io).

---

## 3.1 Use Case Diagram

**Actors:** Visitor · User (Staff) · Admin · Developer · Device / Simulator  
**System boundary:** Smart Campus Smart Building Monitoring System

```mermaid
usecaseDiagram
    actor Visitor as V
    actor "User (Staff)" as U
    actor Admin as A
    actor Developer as D
    actor "Device / Simulator" as Dev

    V --> (Register Account)
    V --> (Login / Logout)
    V --> (Poll Approval Status)

    U --> (Login / Logout)
    U --> (View Dashboard KPIs)
    U --> (View Live Sensor Telemetry)
    U --> (View Equipment Status)
    U --> (Create Maintenance Ticket)
    U --> (Track Ticket Status)
    U --> (Manage Own Profile)
    U --> (View Developer / About Page)

    A --> (Login / Logout)
    A --> (View Live Sensor Telemetry)
    A --> (View Equipment Status)
    A --> (Create Maintenance Ticket)
    A --> (Approve / Reject Signups)
    A --> (Manage Users)
    A --> (CRUD Equipment)
    A --> (Override Equipment Status)
    A --> (Update Ticket Status)
    A --> (View Audit Log)
    A --> (Manage Devices & Sensors)
    A --> (Inject Test Reading)
    A --> (Manage Own Profile)

    D --> (Login / Logout)
    D --> (View Dashboard KPIs)
    D --> (View Live Sensor Telemetry)
    D --> (View Equipment Status)
    D --> (Create Maintenance Ticket)
    D --> (Update Ticket Status)
    D --> (View Audit Log)
    D --> (Manage Devices & Sensors)
    D --> (Inject Test Reading)
    D --> (Edit Developer Profile)
    D --> (Edit App About)
    D --> (Manage Own Profile)

    Dev --> (Send Telemetry)
    Dev --> (Generate Simulated Readings)
```

**Use case notes:**

- Visitor is unauthenticated: signup creates `users.status=pending`, `is_active=0`.
- User and Developer share staff views; Developer also edits profile/About and shares device/sensor admin with Admin.
- Device authenticates with **X-API-Key**, not a browser session.
- Create ticket always stores **Pending**; only Admin can change ticket status.

---

## 3.2 Class Diagram (domain model)

**draw.io page “2 UML” · Class panel** (Design Pack) is the primary artifact: textbook class boxes (name / attributes / operations), five **`«enumeration»`** boxes (`UserRole`, `EquipmentStatus`, `TicketStatus`, `TicketPriority`, `SensorType`), associations with **role names** and **multiplicities** (`1`, `0..*`, `0..1`), **composition** (User–DeveloperProfile), **aggregation** (Room–Equipment), and dashed **enum/dependency** edges.

Flask `app.py` uses module-level functions (no ORM classes). Entities map 1:1 to SQLite tables; services are logical groupings of route helpers and decorators. Roles/statuses are **CHECK enumerations in the schema**, not subclasses (no generalization triangles on entities).

```mermaid
classDiagram
    class User {
        +id: Integer
        +username: String
        +role: UserRole
        +status: String
        +isActive: Boolean
        +authenticate(password) Boolean
        +approve(role) void
    }
    class Ticket {
        +id: Integer
        +title: String
        +priority: TicketPriority
        +status: TicketStatus
        +create() Integer
        +updateStatus(s) void
    }
    class Equipment {
        +id: Integer
        +status: EquipmentStatus
        +updateStatus(s) void
    }
    class DeveloperProfile {
        +userId: Integer {id, FK}
        +fullName: String
        +skills: String
        +email: String [0..1]
    }
    class Telemetry {
        +id: Integer
        +sensorType: SensorType
        +readingValue: Real
    }
    class Device {
        +id: Integer
        +sensorType: SensorType
        +enabled: Boolean
        +setInterval(n) void
    }
    class UserRole {
        <<enumeration>>
        Admin
        User
        Developer
    }
    class TicketStatus {
        <<enumeration>>
        Pending
        In Progress
        Resolved
        Rejected
    }
    class EquipmentStatus {
        <<enumeration>>
        Operational
        Maintenance Required
        Offline
    }
    class SensorType {
        <<enumeration>>
        Temperature
        Humidity
        Air Quality
        Energy
        CO2
    }
    class TicketPriority {
        <<enumeration>>
        Low
        Medium
        High
    }

    User "1" --> "0..*" Ticket : submits
    Equipment "0..1" --> "0..*" Ticket : related
    User "1" *--> "0..1" DeveloperProfile : profile
    Device "1" ..> "0..*" Telemetry : produces
    User --> UserRole : role
    Ticket --> TicketStatus : status
    Ticket --> TicketPriority : priority
    Equipment --> EquipmentStatus : status
    Telemetry --> SensorType : sensorType
    Device --> SensorType : sensorType
```

---

## 3.3 Entity-Relationship Diagram (complete)

**draw.io page “3 ER”** (Design Pack): white entity boxes (PK/FK/{UK} annotations), crow’s-foot style FK arrows, dashed logical links. **Database:** SQLite 3 (`instance/smart_campus.db`) · **12 tables** · `PRAGMA foreign_keys=ON`

```mermaid
erDiagram
    BUILDINGS ||--o{ FLOORS : contains
    BUILDINGS ||--o{ ROOMS : contains
    ROOMS ||--o{ EQUIPMENT : located_in
    USERS ||--o{ MAINTENANCE_TICKETS : submits
    EQUIPMENT ||--o{ MAINTENANCE_TICKETS : linked_to
    USERS ||--|| DEVELOPER_PROFILE : has
    DEVICES ||..o{ TELEMETRY : logical_sensor_id
    SENSOR_CONFIG ||..o{ TELEMETRY : enables_type

    BUILDINGS {
        TEXT code PK
        TEXT name
        INTEGER floors DEFAULT 5
    }
    FLOORS {
        INTEGER id PK
        TEXT building_code FK
        INTEGER floor_number
        TEXT label
    }
    ROOMS {
        INTEGER id PK
        TEXT building_code FK
        INTEGER floor_number
        TEXT name
    }
    USERS {
        INTEGER id PK
        TEXT username UK
        BLOB password_hash
        TEXT role "Admin|User|Developer"
        TEXT full_name
        TEXT status "active|pending|disabled"
        INTEGER is_active
        INTEGER must_change_password
        TEXT last_password_change
        TEXT created_at
    }
    DEVELOPER_PROFILE {
        INTEGER user_id PK_FK
        TEXT full_name
        TEXT title
        TEXT role_label
        TEXT bio
        TEXT skills
        TEXT email
    }
    EQUIPMENT {
        INTEGER id PK
        TEXT name
        TEXT location
        TEXT category "HVAC|Lighting|Security|Plumbing|Electrical|Other"
        TEXT status "Operational|Maintenance Required|Offline"
        TEXT last_inspected
        TEXT building
        INTEGER floor_number
        INTEGER room_id FK
    }
    MAINTENANCE_TICKETS {
        INTEGER id PK
        INTEGER user_id FK
        INTEGER equipment_id FK
        TEXT title
        TEXT description
        TEXT priority "Low|Medium|High"
        TEXT status "Pending|In Progress|Resolved|Rejected"
        TEXT created_at
    }
    TELEMETRY {
        INTEGER id PK
        TEXT sensor_type "Temperature|Humidity|Air Quality|Energy|CO2"
        REAL reading_value
        TEXT unit
        TEXT timestamp
        TEXT sensor_id
        TEXT location
        TEXT source "simulator|http|ui"
        TEXT received_at
    }
    DEVICES {
        INTEGER id PK
        TEXT sensor_id
        TEXT sensor_type
        TEXT location
        TEXT display_name
        TEXT building
        INTEGER enabled
        TEXT first_seen
        TEXT last_seen
        REAL last_value
        TEXT last_unit
        INTEGER update_interval_seconds
        INTEGER room_id FK
    }
    SENSOR_CONFIG {
        TEXT sensor_type PK
        INTEGER enabled
        TEXT last_toggle_by
        TEXT last_toggle_at
    }
    AUDIT_LOG {
        INTEGER id PK
        TEXT timestamp
        TEXT username
        TEXT action
        TEXT entity_type
        TEXT entity_id
        TEXT details
    }
    APP_ABOUT {
        INTEGER id PK
        TEXT tagline
        TEXT description
        TEXT updated_by
        TEXT updated_at
    }
```

**Cardinality summary**

| Relationship | Cardinality | Notes |
|---|---|---|
| buildings → floors | 1 : N | `building_code` FK |
| buildings → rooms | 1 : N | cascade building → floor → room |
| rooms → equipment | 1 : N? | `room_id` nullable |
| users → maintenance_tickets | 1 : N | `user_id` NOT NULL |
| equipment → maintenance_tickets | 1 : N? | `equipment_id` nullable |
| users → developer_profile | 1 : 1 | PK+FK `ON DELETE CASCADE` |
| devices → telemetry | 1 : N logical | `sensor_id` — **no declared FK** |
| sensor_config → telemetry | logical | PK = `sensor_type` |
| audit_log | standalone | `username` logical ref to users |
| app_about | singleton | `CHECK (id = 1)` |

---

## 3.4 Sequence — Login

```mermaid
sequenceDiagram
    autonumber
    actor Visitor
    participant B as Browser
    participant F as Flask
    participant A as Auth / bcrypt
    participant DB as SQLite users

    Visitor->>B: GET /login
    B->>F: render login.html
    Visitor->>B: POST username, password
    B->>F: login()
    F->>DB: SELECT * FROM users WHERE username=?
    DB-->>F: row (password_hash, status, is_active, must_change_password)
    F->>A: checkpw(password, hash)
    A-->>F: True / False

    alt invalid credentials
        F-->>B: flash("Invalid credentials"); re-render login
    else status=pending
        F-->>B: redirect /pending-approval
    else is_active=0
        F-->>B: deactivated message
    else valid
        F->>F: session[user_id, username, role, full_name]
        alt must_change_password=1
            F-->>B: 302 /profile
        else
            F-->>B: 302 /  (Dashboard)
        end
        B-->>Visitor: Dashboard KPI widgets
    end
```

---

## 3.5 Sequence — Maintenance Ticket Lifecycle

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant B as Browser
    participant F as Flask / RBAC
    participant DB as SQLite
    participant A as AuditLog
    actor Admin

    User->>B: GET /maintenance
    B->>F: @login_required
    F->>DB: SELECT tickets JOIN users LEFT JOIN equipment
    DB-->>F: rows
    F-->>B: maintenance.html

    User->>B: POST /api/tickets {title, description, priority, equipment_id?}
    B->>F: api_ticket_create()
    F->>DB: SELECT equipment WHERE id=? [optional]
    F->>DB: INSERT maintenance_tickets (status='Pending')
    DB-->>F: ticket_id
    F->>A: audit_log('create_ticket', ticket, id)
    A->>DB: INSERT audit_log
    F-->>B: flash + redirect
    B-->>User: badge = Pending

    Note over Admin,DB: Admin reviews queue

    Admin->>B: POST /api/tickets/<id>/status {status: In Progress}
    B->>F: @admin_required
    F->>DB: UPDATE maintenance_tickets SET status=?
    F->>A: audit_log('change_ticket_status')
    F-->>B: JSON {ok:true}
    B-->>Admin: badge In Progress (blue)

    Admin->>B: POST status → Resolved
    F->>DB: UPDATE status='Resolved'
    F->>A: audit_log(...)
    B-->>Admin: badge Resolved (green)
```

---

## 3.6 Sequence — Telemetry Ingest + SSE Fan-out

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Device / Simulator
    participant F as Flask ingest
    participant V as Validators
    participant DB as SQLite
    participant S as SSE Broker
    participant B as Browser

    B->>F: GET /api/telemetry/stream (SSE open)
    F-->>B: text/event-stream (held open)

    Dev->>F: POST /api/telemetry/ingest  X-API-Key
    F->>V: verify_device_api_key (hmac)
    V-->>F: ok / 401

    alt sensor disabled
        F-->>Dev: 403
    else unregistered device
        F-->>Dev: 403
    else rate-limited (5s / sensor)
        F-->>Dev: 429
    else ok
        F->>V: _ingest_reading(payload, source='http')
        V->>DB: INSERT telemetry
        V->>DB: UPDATE devices SET last_seen, last_value, last_unit
        V->>S: _broadcast_reading
        S-->>B: event: reading {json}
        F-->>Dev: 201 {ok:true, id}
    end

    Note over Dev,S: par — SimulatorThread loop every N s (SENSOR_MODE=simulator)
```

---

## 3.7 Activity — Signup → Approval

```mermaid
flowchart TD
    start([start]) --> form[Visitor opens /signup]
    form --> check[validate_password + uniqueness]
    check --> valid{valid?}
    valid -->|no| err[show field errors]
    valid -->|yes| ins[INSERT users<br/>role=User, status=pending, is_active=0]
    ins --> pend[/pending-approval<br/>poll check-approval/]
    admin[Admin /admin/users] --> decide{approve?}
    decide -->|approve| act[status=active, is_active=1<br/>role assigned]
    decide -->|reject| del[DELETE user + audit reject_user]
    act --> audit[audit_log approve_user]
    audit --> chk{approved active?}
    del --> endn([end])
    pend --> chk
    chk -->|yes| login[/login → Dashboard/]
    chk -->|no| endn
    login --> pw{must_change_password?}
    pw -->|yes| prof[force /profile change password]
    pw -->|no| endn
    prof --> endn
    err --> form
```

---

## 3.8 State Machine — Maintenance Ticket

```mermaid
stateDiagram-v2
    [*] --> Pending
    Pending --> InProgress : Admin sets In Progress
    Pending --> Rejected : Admin sets Rejected
    Pending --> Resolved : Admin sets Resolved
    InProgress --> Resolved : Admin sets Resolved
    InProgress --> Rejected : Admin sets Rejected
    InProgress --> Pending : Admin reopens
    Resolved --> [*]
    Rejected --> [*]

    note right of Pending
        CHECK status ∈
        Pending | In Progress | Resolved | Rejected
        priority ∈ Low | Medium | High
        Guard: @admin_required
        Side effect: audit_log
    end note
```

**Related state machines**

| Entity | States |
|---|---|
| users | `pending → active` (approve) · `pending → deleted` (reject) · `active → disabled` |
| devices | Awaiting → Live → Stale → Offline · or Disabled |
| sensor_config | enabled ⇄ disabled |

---

## 3.9 Component Diagram

```mermaid
flowchart LR
    subgraph Client
        HTML[Jinja2 templates]
        JS[Static JS / Chart.js]
        SSE[EventSource SSE]
        HTTP[HTTP + X-API-Key]
    end

    subgraph FlaskProc["Flask process (waitress :5050)"]
        Routes[Routes 43 handlers]
        RBAC[RBAC decorators]
        SVC[Services: equipment · tickets · users · devices · telemetry · audit]
        SSEC[SSE broker queues]
        SIM[Simulator thread]
        CAT[campus_catalog.py]
        VAL[Validators / rate limit]
        ST[static + templates]
    end

    subgraph Storage
        DB[(SQLite instance/smart_campus.db · 12 tables)]
    end

    subgraph Ops
        INIT[init_db.py seed]
        TOOLS[tools/* preflight · restore]
        IOT[IoT / fake_iot devices]
    end

    HTML --> Routes
    JS --> Routes
    SSE --> SSEC
    HTTP --> Routes
    Routes --> RBAC
    Routes --> SVC
    Routes --> SSEC
    SVC --> DB
    SVC --> CAT
    SVC --> VAL
    SIM -.-> SVC
    Routes --> ST
    INIT -.-> DB
    TOOLS -.-> DB
    IOT -.-> HTTP
```

---

## 3.10 Deployment Diagram

```mermaid
flowchart TB
    subgraph Host["Host / Docker container SmartCampus_Portable 1.1.0"]
        subgraph Proc["Process waitress threads=8 · HOST=127.0.0.1 · PORT=5050"]
            APP["app.py — 43 routes · RBAC · audit · SSE<br/>Thread: simulator-loop"]
            TPL["static/ + templates/"]
            CLI["init_db.py · tools/*"]
        end
        ENV["Env: SENSOR_MODE · DEVICE_API_KEY<br/>SEED_*_PASSWORD · HOST · PORT"]
        DBFILE[("instance/smart_campus.db")]
        NET{{"HTTP :5050"}}
    end

    BR["Browser — Admin · User · Developer"] -->|GET pages · JSON · SSE| NET
    IOT["IoT device / fake_iot<br/>X-API-Key"] -->|POST ingest| NET
    OPS["Operator CLI"] -->|shell| CLI
    NET --> APP
    APP --> DBFILE
    APP --> TPL
```

**Start order**

1. `python init_db.py` (seed / reset admin password)
2. `waitress-serve --host 127.0.0.1 --port 5050 app:app` **or** `docker compose up`
3. Open `http://127.0.0.1:5050` · login `Admin / Admin1234!`

**Deployment targets:** bare Python 3.12 on Windows · Docker image (Dockerfile + compose). Cloud not required by brief; container is the portable artefact. Preflight: `tools/preflight.py`.

---

*End of Section 3. Authoritative source: `SmartCampus_Design_Pack.drawio` — **4 pages** (WBS · UML · ER · Flow Chart). Legacy: `SmartCampus_UML.drawio`.*

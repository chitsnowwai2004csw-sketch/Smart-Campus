# Section 2: Project Schedule & Gantt Chart

**Project:** Smart Campus Smart Building Monitoring System
**Developer:** Chit Snow Wai
**BSc (Hons) Computer Systems Engineering**

---

## 2.1 Phase Allocation (Total: 200 Hours)

Canonical source: `Assignment-Cover-Sheet-1.docx` schedule (aligned across cover sheet, report, and this file).

| Phase | Hours | % |
|-------|------:|--:|
| Phase 1 — Initiation & Requirements Engineering | 20 | 10.0% |
| Phase 2 — Project Management & Planning | 15 | 7.5% |
| Phase 3 — Architecture & System Design | 30 | 15.0% |
| Phase 4 — Application Development & Implementation | 80 | 40.0% |
| Phase 5 — Testing, Evaluation & Deployment | 30 | 15.0% |
| Phase 6 — Portfolio Compilation & Video Demonstration | 25 | 12.5% |
| **TOTAL** | **200** | **100%** |

**Constraint compliance:**
- Total effort: exactly **200 hours** ✅
- Project window: **19 July 2026 → 30 September 2026** ✅
- Final Canvas submission target: **Week 13, 23:59** ✅

---

## 2.2 Detailed Project Schedule

**Project window:** July 19, 2026 → September 30, 2026 (~10 weeks)

| Task ID | Phase | Task Name | Hours | Start | End | Predecessor | Assigned Role |
|---------|-------|-----------|------:|-------|-----|-------------|---------------|
| T1.1 | P1 | Initial Client Meeting Proposal | 2 | 2026-07-19 | 2026-07-19 | — | Developer |
| T1.2 | P1 | Initial Client Meeting 1 follow-up & review (ICM notes) | 3 | 2026-07-20 | 2026-07-20 | T1.1 | Developer |
| T1.3 | P1 | Updated meeting & progress review; system boundaries | 5 | 2026-07-23 | 2026-07-27 | T1.2 | Developer |
| T1.4 | P1 | Define Functional & Non-Functional Requirements | 6 | 2026-07-28 | 2026-08-01 | T1.3 | Developer |
| T1.5 | P1 | Establish Acceptance Criteria & finalize requirements | 4 | 2026-08-01 | 2026-08-05 | T1.4 | Developer |
| T2.1 | P2 | Formulate Work Breakdown Structure (WBS) | 2 | 2026-07-26 | 2026-07-28 | T1.5 | PM |
| T2.2 | P2 | Construct project Gantt Chart | 3 | 2026-07-29 | 2026-07-31 | T2.1 | PM |
| T2.3 | P2 | Construct Risk Register | 3 | 2026-08-01 | 2026-08-03 | T2.2 | PM |
| T2.4 | P2 | Plan resource allocation | 2 | 2026-08-04 | 2026-08-06 | T2.3 | PM |
| T2.5 | P2 | Schedule Client Meetings 2 & 3 | 2 | 2026-08-07 | 2026-08-08 | T2.4 | PM |
| T2.6 | P2 | Prepare agendas & progress reports | 3 | 2026-08-09 | 2026-08-10 | T2.5 | PM |
| T3.1 | P3 | Select development methodology (RAD) | 2 | 2026-08-06 | 2026-08-07 | T2.2 | Architect |
| T3.2 | P3 | Design ERD & database schema + multi-building/catalogue refinement | 8 | 2026-08-08 | 2026-08-12 | T3.1 | Architect |
| T3.3 | P3 | Create UML diagrams (Use Case, Seq, Class) | 6 | 2026-08-12 | 2026-08-15 | T3.2 | Architect |
| T3.4 | P3 | Design low-fidelity wireframes (3 viewports) | 6 | 2026-08-16 | 2026-08-18 | T3.3 | Designer |
| T3.5 | P3 | Design detailed UI layouts (6 screens) | 8 | 2026-08-18 | 2026-08-20 | T3.4 | Designer |
| T4.1 | P4 | Initialize Flask + SQLite + bcrypt + dynamic column migration | 10 | 2026-08-15 | 2026-08-18 | T3.5 | Developer |
| T4.2 | P4 | Implement Auth, RBAC, password policy & user management/approval | 11 | 2026-08-18 | 2026-08-21 | T4.1 | Developer |
| T4.3 | P4 | Equipment Status Monitoring | 9 | 2026-08-21 | 2026-08-23 | T4.2 | Developer |
| T4.4 | P4 | Environmental Sensor Visualization (5 types) + SSE simulator + ingest API | 19 | 2026-08-24 | 2026-08-29 | T4.3 | Developer |
| T4.5 | P4 | Maintenance Ticket Workflow (Pending→In Progress→Resolved/Rejected) | 10 | 2026-08-29 | 2026-08-31 | T4.4 | Developer |
| T4.6 | P4 | Campus Dashboard, Developer Services, Profile Self-Service, Fleet & Audit Log | 13 | 2026-09-01 | 2026-09-04 | T4.5 | Developer |
| T4.7 | P4 | Bootstrap 5 styling, Dark/Light Theme & responsive QA | 8 | 2026-09-04 | 2026-09-05 | T4.6 | Developer |
| T5.1 | P5 | Functional Testing | 4 | 2026-09-06 | 2026-09-07 | T4.7 | QA |
| T5.2 | P5 | Security & Performance Testing + SSE latency benchmark | 8 | 2026-09-08 | 2026-09-11 | T5.1 | QA |
| T5.3 | P5 | Cross-Browser & User Acceptance Testing | 4 | 2026-09-11 | 2026-09-13 | T5.2 | QA |
| T5.4 | P5 | Deployment manual, Docker/WSGI stack & migration/release tooling | 14 | 2026-09-14 | 2026-09-18 | T5.3 | Developer |
| T6.1 | P6 | Conduct final client review (Meeting 3) | 2 | 2026-09-19 | 2026-09-20 | T5.4 | PM |
| T6.2 | P6 | Draft Critical Reflection section | 5 | 2026-09-20 | 2026-09-22 | T6.1 | Developer |
| T6.3 | P6 | Compile Sections 1–8 into portfolio | 7 | 2026-09-22 | 2026-09-24 | T6.2 | Developer |
| T6.4 | P6 | Harvard Referencing audit + PDF export | 4 | 2026-09-25 | 2026-09-26 | T6.3 | Developer |
| T6.5 | P6 | Video script + recording + 10-15 min MP4 export | 5 | 2026-09-26 | 2026-09-27 | T6.3 | Developer |
| T6.6 | P6 | Canvas declarations + upload | 2 | 2026-09-29 | 2026-09-30 | T6.4, T6.5 | Developer |
| | | **TOTAL EFFORT** | **200** | | **2026-09-30** | | |

**Verification:** Sum of all task hours = 200 ✅

---

## 2.3 Mermaid.js Gantt Chart

```mermaid
gantt
    title Smart Campus Project Schedule (200h, ends 2026-09-30)
    dateFormat YYYY-MM-DD
    axisFormat %b %d

    section Phase 1 Initiation
    Meeting proposal           :t11, 2026-07-19, 1d
    ICM follow-up              :t12, after t11, 1d
    Updated meeting + bounds   :t13, after t12, 4d
    FR and NFR                 :t14, after t13, 5d
    Acceptance criteria        :t15, after t14, 4d

    section Phase 2 Planning
    WBS                        :t21, 2026-07-26, 2d
    Gantt chart                :t22, after t21, 3d
    Risk register              :t23, after t22, 3d
    Resource plan              :t24, after t23, 2d
    Schedule meetings 2 and 3  :t25, after t24, 2d
    Agendas and reports        :t26, after t25, 3d

    section Phase 3 Design
    Methodology RAD            :t31, 2026-08-06, 2d
    ERD and catalogue schema   :t32, after t31, 8d
    UML diagrams               :t33, after t32, 6d
    Wireframes                 :t34, after t33, 6d
    Detailed UI layouts        :t35, after t34, 8d

    section Phase 4 Development
    Backend Flask SQLite       :t41, 2026-08-15, 10d
    Auth RBAC user approval    :t42, after t41, 11d
    Equipment module           :t43, after t42, 9d
    Sensors SSE ingest         :t44, after t43, 19d
    Maintenance workflow       :t45, after t44, 10d
    Campus developer audit     :t46, after t45, 13d
    Theme responsive QA        :t47, after t46, 8d

    section Phase 5 Testing
    Functional testing         :t51, 2026-09-06, 4d
    Security performance       :t52, after t51, 8d
    Cross-browser UAT          :t53, after t52, 4d
    Deployment Docker WSGI     :t54, after t53, 14d

    section Phase 6 Portfolio
    Client Meeting 3           :t61, 2026-09-19, 2d
    Critical Reflection        :t62, after t61, 5d
    Compile Sections 1 to 8    :t63, after t62, 7d
    Referencing PDF            :t64, after t63, 4d
    Video demo                 :t65, after t63, 5d
    Canvas upload              :t66, after t64, 2d

    section Milestone
    Final Submission           :milestone, 2026-09-30, 0d
```

---

## 2.4 Risk Register

| ID | Risk Description | Probability | Impact | Severity | Mitigation Strategy | Owner |
|----|------------------|------------:|-------:|---------:|---------------------|-------|
| R1 | Schedule slip past Sep 30, 2026 | Medium | High | **High** | Design freeze Aug 20; daily progress tracking; cut P2/P3 features first | PM |
| R2 | bcrypt / SQL injection vulnerability | Low | High | Medium | Parameterized SQLite queries only; bcrypt cost factor ≥ 12; security testing in Phase 5 | Developer |
| R3 | Chart.js rendering exceeds 2s page-load target | Medium | Medium | Medium | Pre-aggregate sensor data; cap chart to 24 points; one-shot /latest snapshot; SSE push for new points | Developer |
| R4 | SQLite concurrency under multi-user load | Medium | Medium | Medium | Enable WAL mode; minimize writes; document upgrade path to PostgreSQL | Developer |
| R5 | Scope creep (UI features beyond WBS) | High | Medium | **High** | Strict adherence to WBS; defer non-P0 features to future work | PM |
| R6 | Client meeting feedback delays next phase | Medium | Medium | Medium | 3-day buffer built into Phase 2 & 6; async progress reports via email | PM |
| R7 | Hardware/development environment failure | Low | High | Medium | Git version control; daily backups; cloud-synced repository | Developer |
| R8 | Cross-browser compatibility issues | Medium | Low | Low | Bootstrap 5 standards; test matrix Chrome/Firefox/Edge/Safari in Phase 5.3 | QA |
| R9 | Video demo quality / audio clarity issues | Medium | Medium | Medium | Rehearse script; record in quiet environment; re-record if needed | Developer |
| R10 | Harvard referencing errors in report | Low | Medium | Low | Zotero audit; peer review of citations; final cross-check before PDF export | Developer |

**Severity matrix:**
- **High** = probability × impact score ≥ 6 (R1, R5)
- **Medium** = score 3–5 (R2, R3, R4, R6, R7, R9, R10)
- **Low** = score ≤ 2 (R8)

---

*End of Section 2.*

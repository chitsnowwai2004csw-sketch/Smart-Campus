# Moving Smart Campus to Another Laptop

This guide explains how to move the Smart Campus application to a new laptop.
Three migration artifacts are provided in `dist/` after running `tools/release.py`.

---

## Current Build State (v1.1.0)

- **Version**: 1.1.0
- **Python**: 3.12
- **Database state at last build**: 3 users (admin, staff, dev), 8 equipment, 9 devices, 4 tickets
- **One-click helper**: `MIGRATE.bat` (Windows) or `MIGRATE.sh` (macOS / Linux) on the destination laptop
- **Pre-flight check**: `python tools/preflight.py` on the destination laptop
- **Manifest**: `dist/MANIFEST.txt` lists every artifact with MD5 + SHA-256 checksums

## What's New in v1.1.0 (since v1.0)

- **Audit Log Session** page (`/audit`) with role-tinted rows (Admin only)
- **Equipment status KPI**: replaced "Pending Tickets" with "Maintenance Required" on Equipment page
- **Ticket terminal state**: `Closed` → `Rejected` (per Meeting 3 client request)
- **Dark / light theme toggle** with `localStorage` persistence and `prefers-color-scheme` OS fallback
- **Audit log integrity whitelist** — fabricated action names are rejected
- **Real-action seeding** via `tools/seed_audit_real.py` (uses actual API endpoints)
- **Migration tooling**: `tools/release.py` produces 3 artifacts (code ZIP, data tar, Docker image tar)
- **Pre-flight check script**: `tools/preflight.py` validates Python, Docker, disk, port 5050 and checksums
- **One-click migration helpers**: `MIGRATE.bat` and `MIGRATE.sh` guide the user through Path A / B / C / D
- **Timezone hotfix**: all timestamps now use `datetime.utcnow()` so the "Next Expected" countdown works correctly when running bare Python on laptops with non-UTC timezones
- **Display layer**: `static/js/clock.js` (live UTC + viewer-local clock in the footer) and `static/js/localize.js` (auto-converts any `[data-utc-ts]` element on page load) convert server-stored UTC into the viewer's local time. Storage timezone is unchanged (UTC); only presentation is localized.
- **University campus catalog** (`campus_catalog.py`): 3 Blocks (A=Academic/Library, B=Laboratory/Research, C=Student Services/Admin). Each block has 5 numbered floors (Floor 1-5) — no basement. Each floor carries a list of standardized rooms (Library, Lecture Halls, Labs, Cafeteria, Gym, Server Room, etc.). Seeded into `floors` and `rooms` tables. The Equipment Add/Edit modal uses **cascading Building → Floor → Room dropdowns** with a live preview string built server-side. Existing seed locations are backfilled against the best-fit map during `ensure_schema()`. As of v2.22, basement has been removed from all 3 buildings — `_get_floors_for_building()` only returns floors that have ≥1 room, so the dropdown never offers an empty-room floor.
- **Developer profile editor**: each user with `role='Developer'` has their own row in the `developer_profile` table (one per dev user, auto-created on first `/developer` page load). Developers can edit 11 fields (full_name, title, role_label, bio, avatar_initials, accent_color, skills, phone_number, viber_number, email) via the Edit modal on `/developer`. Skills are picked from a curated 25-item IoT/CS catalog (`SKILLS_CATALOG` in `campus_catalog.py`) using a multi-select dropdown; backend rejects any value not in the catalog. Three contact buttons render on the card: **Phone** (`tel:` from `phone_number`), **Viber** (`viber://chat?number=...` from `viber_number` — separate from phone so a dedicated Viber line can be entered), and **Email** (`mailto:` from `email`). Changes are visible to all logged-in users (Admin, User, Developer). Edit endpoint `PUT /api/developer/profile/me` is gated by `@developer_required`; audits are recorded with action `update_developer_profile`. The display page uses a **modern-tech / GitHub-like design** (v2.21): gradient cover banner, monospace `// SECTION` headers, code-style dividers, large avatar with white ring floating over the banner edge, accent-color-tinted skill pills with hover lift, contact rows with hover slide-right, stats row (Skills/Dev/Devices), full dark-mode support. All `.dev-*` scoped styles in `custom.css`.
- **App About editor**: a singleton `app_about` row holds the page subtitle (tagline) and the app's intro description shown in the "About" card on `/developer`. The hardcoded text was migrated to defaults so existing installations look the same. Developers can edit both fields via the "Edit About" button on the About card; endpoint `PUT /api/developer/app-about` (gated by `@developer_required`); audit action `update_app_about`.

---

## Quick Decision: Which Path Should I Use?

| Destination setup | Recommended path | Artifact needed |
|---|---|---|
| Destination has Docker | **Path A** (Docker image) | `smartcampus-vX.Y.Z-image.tar` (~45 MB) |
| Destination has Docker (no build) | **Path B** (Code ZIP) | `smartcampus-code-vX.Y.Z.zip` (~124 KB) |
| Destination has Python only (no Docker) | **Path C** (Bare Python) | `smartcampus-code-vX.Y.Z.zip` |
| Want ongoing development | **Path D** (Git) | Full project folder or git clone |

---

## One-Click Helper: `MIGRATE.bat` / `MIGRATE.sh`

Both helper scripts are placed in the project root and **can be copied to the destination laptop alongside the `dist/` folder**. They:

1. Run the pre-flight check (`tools/preflight.py`)
2. Ask the user which path to use (A / B / C / D)
3. Execute the appropriate commands (unzip / docker load / docker run / pip install / git clone)
4. Optionally restore the database backup
5. Open the browser to `http://localhost:5050`

Usage on the destination laptop:

```cmd
:: Windows
MIGRATE.bat
```

```bash
# macOS / Linux
chmod +x MIGRATE.sh   # only needed if copied from Windows
./MIGRATE.sh
```

---

## Step 0: Build the artifacts on the source laptop

```bash
cd path/to/SmartCampus_Portable
python tools/release.py
```

This creates three artifacts in `dist/` plus a `MANIFEST.txt`:
- `smartcampus-code-v1.1.0.zip` — source code only
- `smartcampus-data-v1.1.0.tar.gz` — current database (users, devices, telemetry)
- `smartcampus-v1.1.0-image.tar` — pre-built Docker image
- `MANIFEST.txt` — artifact manifest with MD5 / SHA-256 checksums and DB state at build time

Move these to the new laptop via USB, cloud drive, or scp.

---

## Pre-flight Check (recommended before any path)

On the **destination** laptop, before starting migration:

```bash
python tools/preflight.py
```

The pre-flight check verifies:
- Python >= 3.10
- pip availability (optional)
- Docker CLI + daemon reachable (optional — only needed for Paths A / B)
- Free disk space (>= 500 MB recommended)
- Port 5050 free
- All 3 dist artifacts present
- `MANIFEST.txt` checksums valid (artifacts intact after transfer)
- git installed (optional — only needed for Path D)
- curl available

Exit code 0 means all required checks passed; the script lists non-blocking optional warnings separately.

---

## Path A: Fastest — Pre-built Docker Image (recommended)

**Requirements on destination:** Docker Desktop (Windows / macOS / Linux)

```bash
# 1. Copy the image tar to the destination
# 2. Load it into Docker
docker load -i smartcampus-v1.1.0-image.tar

# 3. Start a new container (data is fresh, no DB)
docker run -d --name smartcampus -p 5050:5050 \
  -v smartcampus_data:/app/instance \
  -e DEVICE_API_KEY=replace-with-your-key \
  smartcampus:1.1.0

# 4. Restore your existing database (optional)
python tools/load_data.py smartcampus-data-v1.1.0.tar.gz

# 5. Open the app
# Browser: http://localhost:5050
```

---

## Path B: Standard — Code ZIP + docker compose

**Requirements on destination:** Docker Desktop + the project folder

```bash
# 1. Copy smartcampus-code-v1.1.0.zip to destination
# 2. Unzip
unzip smartcampus-code-v1.1.0.zip
cd smartcampus-code-v1.1.0

# 3. (macOS / Linux only) Make shell scripts executable
chmod +x start.sh stop.sh reset.sh

# 4. Start the container (builds image automatically)
./start.sh       # macOS / Linux
start.bat        # Windows

# 5. Open http://localhost:5050
```

The first run automatically:
- Builds the Docker image
- Runs `init_db.py` (creates 3 demo users + sample data)
- Starts the container

To restore your existing database on top of the seeded one:
```bash
python tools/load_data.py path/to/smartcampus-data-v1.1.0.tar.gz
```

---

## Path C: Bare Python (no Docker)

**Requirements on destination:** Python 3.12 + pip

```bash
# 1. Unzip code ZIP
unzip smartcampus-code-v1.1.0.zip
cd smartcampus-code-v1.1.0

# 2. Create virtual environment
python3 -m venv .venv
source .venv/bin/activate          # macOS / Linux
.venv\Scripts\activate             # Windows PowerShell

# 3. Install dependencies
pip install -r requirements.txt

# 4. Initialize the database
python init_db.py

# 5. Start the app
python app.py

# 6. Open http://localhost:5050
```

Notes:
- The data backup (`.tar.gz`) is intended for Docker volumes. For bare Python, you can manually place the SQLite DB at `instance/smart_campus.db` (extract from the tarball).
- The background simulator thread is disabled in `SENSOR_MODE != "simulator"`. Set the env var:
  ```bash
  export SENSOR_MODE=simulator
  export DEVICE_API_KEY=test-key-123
  ```

---

## Path D: Git Repository

For ongoing development on multiple laptops:

```bash
# 1. Initialize the local repo (if not done yet)
git init
git add .
git commit -m "Initial commit v1.1.0"

# 2. Add a remote and push (optional)
git remote add origin https://github.com/yourname/smartcampus.git
git push -u origin main

# 3. On the new laptop
git clone https://github.com/yourname/smartcampus.git
cd smartcampus
start.sh       # or start.bat
```

The database (`instance/*.db`) is excluded from git by `.gitignore`. Use `tools/load_data.py` or `dist/smartcampus-data-v1.1.0.tar.gz` to restore the DB.

---

## Restoring Data From a Backup

After starting the container, restore the data:

```bash
# Outside the container (recommended)
python tools/load_data.py dist/smartcampus-data-v1.1.0.tar.gz

# Or inside the container (if you docker exec'd in)
docker exec smartcampus python /app/tools/load_data.py /data-backup.tar.gz
```

This script:
1. Stops the running container
2. Replaces `/app/instance/smart_campus.db` inside the volume
3. Restarts the container

Your users, devices, equipment, and telemetry are preserved.

---

## First Run Checklist

After installing on the new laptop:

1. [ ] Open http://localhost:5050 — should show login page
2. [ ] Log in with **admin / Admin1234!** (shipped DB). Staff: `staff123`, dev: `dev123` (forced change on first login).
3. [ ] Admin is ready to use (no forced password change)
4. [ ] Try `staff` / `dev` — complete the prompted password change
5. [ ] Navigate: Dashboard / Telemetry / Equipment / Maintenance / Developer
6. [ ] Verify devices show as "Live" (the simulator runs every 30s)
7. [ ] Optional: VS Code path — see README-VSCODE.md (no Docker needed)

---

## Troubleshooting

### "Port 5050 is already in use"
Stop the conflicting process:
```bash
# Find what uses 5050
lsof -i :5050              # macOS / Linux
netstat -ano | findstr :5050   # Windows

# Or change the port
docker run -p 6060:5050 ...    # bind to 6060 instead
```

### "Cannot connect to Docker daemon"
Make sure Docker Desktop is running (Windows / macOS) or that your user is in the `docker` group (Linux).

### "Database is locked"
This is rare. If it happens:
```bash
docker restart smartcampus
```

### "Admin password is wrong"
Use the password reset helper:
```bash
# Outside the container
python tools/restore_admin.py

# Inside the container
docker exec smartcampus python /app/tools/restore_admin.py
```

### "I want to start completely fresh"
```bash
# Windows
reset.bat

# macOS / Linux
./reset.sh
```
This deletes all data and rebuilds from scratch.

### "I want to use a different SECRET_KEY"
Edit `docker-compose.yml`:
```yaml
environment:
  SECRET_KEY: "your-own-random-string-here"
```
Or set env var when running with `docker run -e SECRET_KEY=...`.

---

## Files Reference

| File | Purpose |
|---|---|
| `app.py` | Flask application |
| `init_db.py` | Database initialization + sample data |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container image definition |
| `docker-compose.yml` | Container orchestration |
| `.env.example` | Environment variable template |
| `start.bat` / `start.sh` | One-click start |
| `stop.bat` / `stop.sh` | One-click stop |
| `reset.bat` / `reset.sh` | One-click full reset |
| `MIGRATE.bat` / `MIGRATE.sh` | One-click migration helper for destination laptop |
| `tools/release.py` | Build migration artifacts into `dist/` |
| `tools/preflight.py` | Pre-flight check (Python, Docker, disk, port, checksums) |
| `tools/load_data.py` | Restore database from backup |
| `tools/restore_admin.py` | Reset admin password |
| `tools/seed_audit_real.py` | Seed real (non-fabricated) audit log entries via API |
| `tools/fake_iot_devices.py` | External IoT device simulator (optional) |
| `dist/smartcampus-code-v1.1.0.zip` | Source code only |
| `dist/smartcampus-data-v1.1.0.tar.gz` | Current database backup |
| `dist/smartcampus-v1.1.0-image.tar` | Pre-built Docker image |
| `dist/MANIFEST.txt` | Artifact manifest with MD5/SHA-256 checksums |
| `MOVE.md` | This file |

---

## Support

For issues or questions:
- Check `docs/` directory
- Read `README.md`
- See `docs/SENSOR_INTEGRATION.md` for IoT device integration

#!/usr/bin/env bash
# ============================================================
#   Smart Campus Migration Helper (macOS / Linux)
#   Version: 1.1.0
#   Run this script on the DESTINATION laptop.
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo
echo "============================================================"
echo "  Smart Campus Migration Helper v1.1.0"
echo "============================================================"
echo
echo "This script helps you move Smart Campus to a new laptop."
echo "Before continuing, copy the dist/ folder here (USB, cloud, etc.)."
echo

if [ ! -f "dist/MANIFEST.txt" ]; then
    echo "[ERROR] dist/MANIFEST.txt not found."
    echo "Please copy the entire dist/ folder into this directory first."
    exit 1
fi

echo "Pre-flight check:"
echo
python3 tools/preflight.py || {
    echo
    echo "[ERROR] Pre-flight failed. Resolve issues above before continuing."
    exit 1
}

echo
echo "Migration paths:"
echo "  [A] Docker image   (fastest, ~45 MB, no Python needed)"
echo "  [B] Code ZIP       (standard, ~124 KB, builds on site)"
echo "  [C] Bare Python    (no Docker, requires Python 3.12)"
echo "  [D] Git repository (for ongoing development)"
echo
read -r -p "Enter choice [A/B/C/D]: " CHOICE

CHOICE=$(echo "$CHOICE" | tr '[:lower:]' '[:upper:]')

case "$CHOICE" in
    A) script="path_a" ;;
    B) script="path_b" ;;
    C) script="path_c" ;;
    D) script="path_d" ;;
    *) echo "[ERROR] Invalid choice: $CHOICE"; exit 1 ;;
esac

# ============================================================
# Path A: Docker image
# ============================================================
if [ "$script" = "path_a" ]; then
    echo
    echo "============================================================"
    echo "  Path A: Docker image"
    echo "============================================================"
    docker load -i dist/smartcampus-v1.1.0-image.tar || {
        echo "[ERROR] docker load failed."; exit 1;
    }
    echo
    echo "Cleaning up any old container named 'smartcampus'..."
    docker rm -f smartcampus 2>/dev/null || true
    echo
    echo "Starting container..."
    docker run -d --name smartcampus -p 5050:5050 \
        -v smartcampus_data:/app/instance \
        -e SENSOR_MODE=simulator \
        -e DEVICE_API_KEY=test-key-123 \
        smartcampus:1.1.0 || {
        echo "[ERROR] docker run failed."; exit 1;
    }
    echo
    echo "Waiting for container healthcheck..."
    for i in $(seq 1 20); do
        HEALTH=$(docker inspect --format="{{.State.Health.Status}}" smartcampus 2>/dev/null || echo "")
        if [ "$HEALTH" = "healthy" ]; then
            echo "Container is healthy."
            break
        fi
        sleep 1
    done
    ACTION="docker"
fi

# ============================================================
# Path B: Code ZIP
# ============================================================
if [ "$script" = "path_b" ]; then
    echo
    echo "============================================================"
    echo "  Path B: Code ZIP"
    echo "============================================================"
    if [ -d "smartcampus-code-v1.1.0" ]; then
        echo "Code folder already exists."
    else
        echo "Unzipping dist/smartcampus-code-v1.1.0.zip..."
        which unzip >/dev/null 2>&1 || { echo "[ERROR] unzip not installed. Try: brew install unzip"; exit 1; }
        unzip -q -o dist/smartcampus-code-v1.1.0.zip || {
            echo "[ERROR] unzip failed."; exit 1;
        }
    fi
    echo
    echo "Building and starting..."
    cd smartcampus-code-v1.1.0
    chmod +x start.sh stop.sh reset.sh 2>/dev/null || true
    ./start.sh
    cd ..
    ACTION="bare"
fi

# ============================================================
# Path C: Bare Python
# ============================================================
if [ "$script" = "path_c" ]; then
    echo
    echo "============================================================"
    echo "  Path C: Bare Python"
    echo "============================================================"
    PYTHON=${PYTHON:-python3}
    $PYTHON --version
    if [ -d "smartcampus-code-v1.1.0" ]; then
        echo "Code folder already exists."
    else
        echo "Unzipping dist/smartcampus-code-v1.1.0.zip..."
        unzip -q -o dist/smartcampus-code-v1.1.0.zip
    fi
    cd smartcampus-code-v1.1.0
    $PYTHON -m venv .venv
    source .venv/bin/activate
    pip install -q -r requirements.txt
    python init_db.py
    export FLASK_APP=app.py
    nohup python app.py > /tmp/smartcampus.log 2>&1 &
    echo $! > /tmp/smartcampus.pid
    echo "App started in background. PID: $(cat /tmp/smartcampus.pid)"
    echo "Logs: tail -f /tmp/smartcampus.log"
    ACTION="bare"
    cd ..
fi

# ============================================================
# Path D: Git
# ============================================================
if [ "$script" = "path_d" ]; then
    echo
    echo "============================================================"
    echo "  Path D: Git"
    echo "============================================================"
    echo "Run 'git init' in the project folder if not already a git repo,"
    echo "then push to your remote. On the destination, 'git clone' and run start.sh."
    exit 0
fi

# ============================================================
# Restore data (optional)
# ============================================================
if [ -f "dist/smartcampus-data-v1.1.0.tar.gz" ] && [ "$ACTION" = "docker" ]; then
    echo
    echo "============================================================"
    echo "  Restore Data (optional)"
    echo "============================================================"
    read -r -p "Restore existing database from backup? [Y/N]: " RESTORE
    RESTORE=$(echo "$RESTORE" | tr '[:lower:]' '[:upper:]')
    if [ "$RESTORE" = "Y" ]; then
        echo "Restoring data..."
        python3 tools/load_data.py dist/smartcampus-data-v1.1.0.tar.gz || {
            echo "[WARNING] Data restore failed. Container has fresh DB."
        }
    fi
else
    echo
    echo "No data backup found - container will use fresh seed data."
fi

echo
echo "============================================================"
echo "  Smart Campus started successfully!"
echo "============================================================"
echo
echo "  URL: http://localhost:5050"
echo
echo "  Credentials (from the SOURCE laptop's current state):"
echo "    admin / Admin1234!"
echo "    staff / staff123   (will be prompted to change password on first login)"
echo "    dev   / dev123     (will be prompted to change password on first login)"
echo
echo "  Note: if you skipped data restore, reset admin with:"
echo "    docker exec smartcampus python /app/tools/restore_admin.py Admin1234!"
echo

# Open browser (platform-specific)
if command -v open >/dev/null 2>&1; then
    open "http://localhost:5050" 2>/dev/null &
elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:5050" 2>/dev/null &
elif command -v wslview >/dev/null 2>&1; then
    wslview "http://localhost:5050" 2>/dev/null &
else
    echo "Please open http://localhost:5050 in your browser."
fi

echo "Browser opened."
echo
echo "Container is running. Stop it later with:"
echo "  docker stop smartcampus"
echo
echo "Press Enter to close (the app will keep running)..."
read

(function() {
  const feed = document.getElementById('eventFeed');
  const connStatus = document.getElementById('connStatus');
  const liveDot = document.getElementById('liveDot');
  const MAX_FEED = 30;

  function appendFeed(r) {
    if (!feed) return;
    const li = document.createElement('li');
    li.innerHTML =
      '<small class="text-muted">' + (r.timestamp || '').slice(11, 19) + '</small> ' +
      '<span class="badge bg-info text-dark">' + escapeHtml(r.sensor_type || '') + '</span> ' +
      '<strong>' + (r.reading_value != null ? Number(r.reading_value).toFixed(2) : '?') + ' ' + escapeHtml(r.unit || '') + '</strong> ' +
      '<small class="font-monospace text-muted">' + escapeHtml(r.sensor_id || 'simulator') + '</small>';
    feed.prepend(li);
    while (feed.children.length > MAX_FEED) feed.removeChild(feed.lastChild);
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function cssEscape(s) {
    if (window.CSS && CSS.escape) return CSS.escape(s);
    return String(s).replace(/"/g, '\\"');
  }

  function updateRow(r) {
    const row = document.querySelector(
      'tr[data-sensor-id="' + cssEscape(r.sensor_id || '') + '"]' +
      '[data-sensor-type="' + cssEscape(r.sensor_type || '') + '"]'
    );
    if (!row) return;
    const cells = row.cells;
    // Column map (admin view, 9 cells):
    //   0=Sensor ID, 1=Type, 2=Location, 3=Interval,
    //   4=Last Reading, 5=Last Seen (data-ts), 6=Next Expected (data-cd + data-ts),
    //   7=Status, 8=Actions
    // Non-admin view drops col 8 (Actions).
    if (cells[4]) {
      cells[4].innerHTML = '<span class="fw-bold">' +
        Number(r.reading_value).toFixed(2) + ' ' + escapeHtml(r.unit || '') + '</span>';
    }
    if (cells[5] && r.timestamp) {
      cells[5].textContent = 'just now';
      cells[5].setAttribute('data-ts', r.timestamp);
    }
    if (cells[6] && r.last_expected_at) {
      cells[6].setAttribute('data-ts', r.last_expected_at);
      const expDt = new Date(r.last_expected_at.replace(' ', 'T') + 'Z');
      const sec = Math.round((expDt.getTime() - Date.now()) / 1000);
      if (sec > 0) cells[6].textContent = 'in ' + sec + 's';
      else cells[6].innerHTML = '<span class="text-warning">overdue ' + (-sec) + 's</span>';
    }
    if (cells[7]) {
      cells[7].innerHTML = '<span class="badge bg-success"><span class="pulse-dot"></span> Live</span>';
    }
  }

  function refreshAges() {
    document.querySelectorAll('.last-seen-cell').forEach(cell => {
      const ts = cell.getAttribute('data-ts');
      const row = cell.closest('tr');
      const isDisabled = row && row.querySelector('.device-toggle:not(:checked)') !== null;
      if (!ts || isDisabled) {
        cell.textContent = '-';
        return;
      }
      const dt = new Date(ts.replace(' ', 'T') + 'Z');
      if (isNaN(dt)) return;
      const sec = Math.max(0, Math.floor((Date.now() - dt.getTime()) / 1000));
      if (sec < 1) cell.textContent = 'just now';
      else if (sec < 60) cell.textContent = sec + 's ago';
      else if (sec < 3600) cell.textContent = Math.floor(sec / 60) + 'm ago';
      else cell.textContent = Math.floor(sec / 3600) + 'h ago';

      const statusCell = row && row.cells[7];
      if (!statusCell) return;
      const intervalCell = row.cells[3];
      const intervalMatch = intervalCell ? intervalCell.textContent.match(/(\d+)/) : null;
      const interval = intervalMatch ? parseInt(intervalMatch[1]) : 30;
      const liveThresh = Math.max(30, Math.ceil(interval * 1.5));
      const staleThresh = Math.max(300, interval * 10);
      if (sec < liveThresh) statusCell.innerHTML = '<span class="badge bg-success"><span class="pulse-dot"></span> Live</span>';
      else if (sec < staleThresh) statusCell.innerHTML = '<span class="badge bg-warning text-dark">Stale</span>';
      else statusCell.innerHTML = '<span class="badge bg-danger">Offline</span>';
    });
    // Update countdown cells
    document.querySelectorAll('.countdown-cell').forEach(cell => {
      const expTs = cell.getAttribute('data-ts');
      const row = cell.closest('tr');
      const isDisabled = row && row.querySelector('.device-toggle:not(:checked)') !== null;
      if (!expTs || isDisabled) { cell.textContent = '-'; return; }
      const expDt = new Date(expTs.replace(' ', 'T') + 'Z');
      if (isNaN(expDt)) return;
      const seconds = Math.round((expDt.getTime() - Date.now()) / 1000);
      if (seconds > 0) cell.innerHTML = 'in ' + seconds + 's';
      else cell.innerHTML = '<span class="text-warning">overdue ' + (-seconds) + 's</span>';
    });
  }
  setInterval(refreshAges, 1000);

  // Toggle
  document.querySelectorAll('.device-toggle').forEach(sw => {
    sw.addEventListener('change', async () => {
      const id = sw.dataset.id;
      const sid = sw.dataset.sid;
      const newState = sw.checked ? 1 : 0;
      sw.disabled = true;
      try {
        const res = await fetch('/api/devices/' + id + '/toggle', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ enabled: !!newState })
        });
        const d = await res.json();
        if (res.ok && d.ok) {
          injectAlert(d.type || 'success', d.message);
          // Update row cells if we just disabled
          if (!newState) {
            const row = sw.closest('tr');
            if (row) {
              // Column indices: 4=Last Reading, 5=Last Seen, 6=Next Expected, 7=Status
              if (row.cells[4]) row.cells[4].textContent = '-';
              if (row.cells[5]) row.cells[5].textContent = '-';
              if (row.cells[6]) row.cells[6].textContent = '-';
              if (row.cells[7]) row.cells[7].innerHTML = '<span class="badge bg-dark">Disabled</span>';
            }
          }
        } else {
          sw.checked = !newState;
          injectAlert(d.type || 'danger', d.message || 'Failed.');
        }
      } catch (e) {
        sw.checked = !newState;
        injectAlert('danger', 'Network error.');
      } finally {
        sw.disabled = false;
      }
    });
  });

  // Edit
  const editModal = document.getElementById('editDeviceModal');
  if (editModal) {
    const modal = new bootstrap.Modal(editModal);
    if (window.CascadeLocation) window.CascadeLocation.wireCascade('edit');
    document.querySelectorAll('.edit-device').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        const row = btn.closest('tr');
        document.getElementById('editDeviceId').value = id;
        document.getElementById('editSensorId').value = row.dataset.sensorId || '';
        const nameTxt = row.querySelector('.display-name-text');
        document.getElementById('editDisplayName').value =
          nameTxt && nameTxt.textContent !== '—' ? nameTxt.textContent : '';
        if (window.CascadeLocation) {
          await window.CascadeLocation.prefillCascade(
            'edit',
            row.dataset.building || '',
            row.dataset.floorNumber || '',
            row.dataset.roomId || '',
            row.dataset.locationDetail || ''
          );
        }
        modal.show();
      });
    });
    document.getElementById('editDeviceForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('editDeviceId').value;
      const display_name = document.getElementById('editDisplayName').value.trim();
      const loc = window.CascadeLocation ? window.CascadeLocation.buildCanonicalLocation('edit') : null;
      if (loc && loc.error) {
        injectAlert('danger', loc.error);
        return;
      }
      try {
        const payload = { display_name };
        if (loc) {
          payload.location = loc.location;
          payload.building_code = loc.building_code;
          payload.floor_number = loc.floor_number;
          payload.room_id = loc.room_id;
          payload.location_detail = loc.location_detail;
          document.getElementById('editLocation').value = loc.location;
        }
        const res = await fetch('/api/devices/' + id, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const d = await res.json();
        if (res.ok && d.ok) {
          injectAlert('success', d.message);
          modal.hide();
          setTimeout(() => location.reload(), 300);
        } else {
          injectAlert('danger', d.message || 'Failed.');
        }
      } catch (err) {
        injectAlert('danger', 'Network error.');
      }
    });
  }

  // Delete
  document.querySelectorAll('.delete-device').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const sid = btn.dataset.sid;
      if (!window.confirm("Remove device '" + sid + "' from registry?\n\nTelemetry history will be preserved.")) return;
      fetch('/api/devices/' + id, { method: 'DELETE' })
        .then(r => r.json())
        .then(d => {
          if (d.ok) {
            injectAlert('success', d.message);
            const row = btn.closest('tr');
            if (row) row.remove();
          } else {
            injectAlert('danger', d.message || 'Failed.');
          }
        })
        .catch(() => injectAlert('danger', 'Network error.'));
    });
  });

  function injectAlert(kind, msg) {
    const a = document.createElement('div');
    a.className = 'alert alert-' + kind + ' alert-dismissible fade show m-2 shadow-sm';
    a.setAttribute('role', 'alert');
    a.innerHTML = '<strong>' + (kind === 'danger' ? 'Error' : 'OK') + ':</strong> ' + msg +
      '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    (document.body || document.documentElement).prepend(a);
    setTimeout(() => { try { a.remove(); } catch (e) {} }, 4000);
  }

  // SSE
  if (typeof EventSource === 'undefined') {
    if (connStatus) connStatus.textContent = 'EventSource not supported';
    return;
  }
  const es = new EventSource('/api/telemetry/stream');
  es.addEventListener('hello', () => {
    if (connStatus) connStatus.textContent = 'Connected - live updates';
    if (liveDot) liveDot.classList.remove('disconnected');
  });
  es.addEventListener('reading', e => {
    try {
      const r = JSON.parse(e.data);
      if (r.sensor_id) updateRow(r);
      appendFeed(r);
    } catch (err) {}
  });
  es.addEventListener('device_added', e => {
    try {
      const ev = JSON.parse(e.data);
      injectAlert('success',
        'New device auto-registered: ' + (ev.sensor_id || '') +
        ' (' + (ev.sensor_type || '') + ')');
      // Reload after a moment so the new row appears
      setTimeout(() => location.reload(), 1500);
    } catch (err) {}
  });
  es.onerror = () => {
    if (connStatus) connStatus.textContent = 'Disconnected - retrying...';
    if (liveDot) liveDot.classList.add('disconnected');
  };
})();

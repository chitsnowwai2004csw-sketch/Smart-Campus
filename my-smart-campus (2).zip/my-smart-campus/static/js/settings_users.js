// Defensive fallback for /settings?tab=users
// Renders users from INLINE server data first (bypasses ALL caching),
// falls back to API fetch only if inline data is missing.

(function() {
  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  function renderRow(u) {
    const roleCls = {Admin:'danger', User:'primary', Developer:'info'}[u.role] || 'secondary';
    const statusBadge = u.is_active
      ? '<span class="enabled-state-text">Enabled</span>'
      : '<span class="enabled-state-text">Disabled</span>';

    const selfDisabled = u.id === window.SESSION_USER_ID;
    const toggleAttrs = selfDisabled
      ? 'data-self-disabled="1" disabled title="You cannot disable your own account"'
      : '';
    const checked = u.is_active ? 'checked' : '';

    const lastPw = u.last_password_change || '—';

    const pwResetBadge = u.must_change_password
      ? '<span class="badge bg-warning text-dark ms-1" title="Must change password on next login">PW Reset</span>'
      : '';

    return '<tr id="urow-' + u.id + '"' +
      ' data-id="' + u.id + '"' +
      ' data-username="' + escapeHtml(u.username) + '"' +
      ' data-full-name="' + escapeHtml(u.full_name || '') + '"' +
      ' data-role="' + escapeHtml(u.role) + '"' +
      ' data-active="' + (u.is_active ? '1' : '0') + '">' +
      '<td>' + u.id + '</td>' +
      '<td class="fw-semibold">' +
        escapeHtml(u.username) + ' ' + pwResetBadge +
      '</td>' +
      '<td>' + escapeHtml(u.full_name || '') + '</td>' +
      '<td><span class="badge bg-' + roleCls + '">' + escapeHtml(u.role) + '</span></td>' +
      '<td>' +
        '<div class="form-check form-switch form-switch-lg d-inline-block align-middle m-0">' +
          '<input class="form-check-input enabled-toggle" type="checkbox" role="switch"' +
                 ' id="enabledSwitch-' + u.id + '"' +
                 ' data-id="' + u.id + '"' +
                 ' data-username="' + escapeHtml(u.username) + '"' +
                 ' data-full-name="' + escapeHtml(u.full_name || '') + '"' +
                 ' data-role="' + escapeHtml(u.role) + '"' +
                 ' ' + toggleAttrs + ' ' + checked + '>' +
          '<label class="form-check-label small ms-2 align-middle" for="enabledSwitch-' + u.id + '">' +
            statusBadge +
          '</label>' +
        '</div>' +
      '</td>' +
      '<td class="small text-muted">' + escapeHtml(lastPw) + '</td>' +
      '<td>' +
        '<div class="d-flex gap-2">' +
          '<button class="btn btn-sm rounded-pill edit-user border border-2 border-primary text-primary"' +
                  ' data-id="' + u.id + '" type="button">' +
            '<i class="bi bi-pencil-square me-1"></i> Edit' +
          '</button>' +
          '<button class="btn btn-sm rounded-pill reset-pw border border-2 border-warning text-warning"' +
                  ' data-id="' + u.id + '" data-username="' + escapeHtml(u.username) + '" type="button">' +
            '<i class="bi bi-key-fill me-1"></i> Reset Password' +
          '</button>' +
        '</div>' +
      '</td>' +
    '</tr>';
  }

  async function fetchAndRender(tbody, statusBanner) {
    try {
      const r = await fetch('/api/users', { credentials: 'same-origin' });
      if (!r.ok) {
        statusBanner.textContent = 'Failed to load users (' + r.status + '). Reload to try again.';
        statusBanner.className = 'alert alert-danger small mb-2';
        return false;
      }
      const data = await r.json();
      const users = data.users || [];
      const activeUsers = users.filter(u => u.status !== 'pending');

      if (activeUsers.length === 0) {
        statusBanner.textContent = 'No users found.';
        statusBanner.className = 'alert alert-warning small mb-2';
        return false;
      }

      tbody.innerHTML = activeUsers.map(renderRow).join('');
      statusBanner.textContent = 'Loaded ' + activeUsers.length + ' user(s) via fallback API.';
      statusBanner.className = 'alert alert-success small mb-2';
      document.dispatchEvent(new CustomEvent('users:table-updated'));
      return true;
    } catch (e) {
      statusBanner.textContent = 'Network error loading users: ' + e.message;
      statusBanner.className = 'alert alert-danger small mb-2';
      return false;
    }
  }

  function renderFromInline(tbody, statusBanner) {
    const inlineUsers = window.SERVER_USERS || [];
    const activeUsers = inlineUsers.filter(u => u.status !== 'pending');
    if (activeUsers.length === 0) {
      return false;
    }
    tbody.innerHTML = activeUsers.map(renderRow).join('');
    statusBanner.textContent = 'Loaded ' + activeUsers.length + ' user(s) from server inline data.';
    statusBanner.className = 'alert alert-success small mb-2';
    document.dispatchEvent(new CustomEvent('users:table-updated'));
    return true;
  }

  document.addEventListener('DOMContentLoaded', function() {
    const tbody = document.getElementById('userTable');
    if (!tbody) return;

    // Insert status banner above the table
    let statusBanner = document.getElementById('usersFallbackStatus');
    if (!statusBanner) {
      statusBanner = document.createElement('div');
      statusBanner.id = 'usersFallbackStatus';
      statusBanner.className = 'alert alert-info small mb-2';
      const cardBody = tbody.closest('.card-body') || tbody.parentElement;
      cardBody.insertBefore(statusBanner, tbody);
    }

    // Check if tbody has rows
    const hasRows = tbody.querySelectorAll('tr').length > 0;

    if (!hasRows) {
      // Try INLINE data first (no network, no cache, always works)
      if (renderFromInline(tbody, statusBanner)) {
        return;  // success
      }
      // Fallback to API fetch
      fetchAndRender(tbody, statusBanner).then(ok => {
        if (!ok) {
          statusBanner.innerHTML =
            '<strong>Failed to load users.</strong> ' +
            'This may be a browser cache issue. ' +
            '<button class="btn btn-sm btn-primary mt-2" onclick="location.reload(true)">' +
            'Force Reload (Clear Cache)' +
            '</button>';
          statusBanner.className = 'alert alert-danger small mb-2';
        }
      });
    }
  });
})();

// Developer profile page - edit modals (profile + about)
function injectAlert(type, message) {
  const wrap = document.getElementById('alerts');
  if (!wrap) return;
  const div = document.createElement('div');
  div.className = 'alert alert-' + type + ' alert-dismissible fade show alert-inline';
  div.innerHTML = message + '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
  wrap.prepend(div);
  setTimeout(() => {
    div.classList.remove('show');
    setTimeout(() => div.remove(), 200);
  }, 4000);
}

function getSelectedSkills() {
  const sel = document.getElementById('devProfileSkills');
  if (!sel) return '';
  return Array.from(sel.selectedOptions).map(o => o.value).join(',');
}

function setSelectedSkills(skillsStr) {
  const sel = document.getElementById('devProfileSkills');
  if (!sel) return;
  const wanted = (skillsStr || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  Array.from(sel.options).forEach(opt => {
    opt.selected = wanted.indexOf(opt.value.toLowerCase()) !== -1;
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // === Edit Developer Profile ===
  const editBtn = document.getElementById('editProfileBtn');
  const profileForm = document.getElementById('editDevProfileForm');
  if (editBtn && profileForm) {
    const modalEl = document.getElementById('editDevProfileModal');
    editBtn.addEventListener('click', async () => {
      try {
        const res = await fetch('/api/developer/profile/me', {
          headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) {
          injectAlert('danger', data.message || 'Failed to load profile.');
          return;
        }
        const p = data.profile || {};
        document.getElementById('devProfileName').value = p.full_name || '';
        document.getElementById('devProfileTitle').value = p.title || '';
        document.getElementById('devProfileRoleLabel').value = p.role_label || '';
        document.getElementById('devProfileBio').value = p.bio || '';
        setSelectedSkills(p.skills || '');
        document.getElementById('devProfileInitials').value = p.avatar_initials || '';
        document.getElementById('devProfileAccent').value = p.accent_color || 'primary';
        document.getElementById('devProfilePhone').value = p.phone_number || '';
        document.getElementById('devProfileViber').value = p.viber_number || '';
        document.getElementById('devProfileEmail').value = p.email || '';
        new bootstrap.Modal(modalEl).show();
      } catch (e) {
        injectAlert('danger', 'Network error while loading profile.');
      }
    });

    profileForm.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const btn = document.getElementById('devProfileSubmitBtn');
      const fd = new FormData(profileForm);
      const payload = Object.fromEntries(fd.entries());
      // Override skills with the multi-select values
      payload.skills = getSelectedSkills();
      if (!payload.full_name || !payload.full_name.trim()) {
        injectAlert('danger', 'Full name is required.');
        return;
      }
      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Saving...';
      try {
        const res = await fetch('/api/developer/profile/me', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
          },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          injectAlert('success', data.message || 'Profile updated.');
          bootstrap.Modal.getInstance(modalEl)?.hide();
          setTimeout(() => location.reload(), 500);
        } else {
          injectAlert(data.type || 'danger', data.message || 'Failed to update profile.');
        }
      } catch (e) {
        injectAlert('danger', 'Network error while updating profile.');
      } finally {
        btn.disabled = false;
        btn.innerHTML = original;
      }
    });
  }

  // === Edit About App ===
  const aboutBtn = document.getElementById('editAboutBtn');
  const aboutForm = document.getElementById('editAboutForm');
  if (aboutBtn && aboutForm) {
    const modalEl = document.getElementById('editAboutModal');
    aboutBtn.addEventListener('click', async () => {
      try {
        const res = await fetch('/api/developer/app-about', {
          headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) {
          injectAlert('danger', data.message || 'Failed to load About description.');
          return;
        }
        const a = data.app_about || {};
        document.getElementById('appAboutTagline').value = a.tagline || '';
        document.getElementById('appAboutDescription').value = a.description || '';
        new bootstrap.Modal(modalEl).show();
      } catch (e) {
        injectAlert('danger', 'Network error while loading About.');
      }
    });

    aboutForm.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const btn = document.getElementById('appAboutSubmitBtn');
      const fd = new FormData(aboutForm);
      const payload = Object.fromEntries(fd.entries());
      if (!payload.description || !payload.description.trim()) {
        injectAlert('danger', 'App description is required.');
        return;
      }
      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Saving...';
      try {
        const res = await fetch('/api/developer/app-about', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
          },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          injectAlert('success', data.message || 'About description updated.');
          bootstrap.Modal.getInstance(modalEl)?.hide();
          setTimeout(() => location.reload(), 500);
        } else {
          injectAlert(data.type || 'danger', data.message || 'Failed to update About description.');
        }
      } catch (e) {
        injectAlert('danger', 'Network error while updating About.');
      } finally {
        btn.disabled = false;
        btn.innerHTML = original;
      }
    });
  }
});

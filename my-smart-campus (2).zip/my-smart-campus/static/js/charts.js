const charts = {};
const MAX_POINTS = 24;

// Color palette keyed by sensor_type
const COLOR_MAP = {
  'Temperature': '#EF4444',
  'Humidity':    '#3B82F6',
  'Air Quality': '#10B981',
  'Energy':      '#F59E0B',
  'CO2':         '#6B7280',
  'simulator':   '#9CA3AF'
};

function canvasKey(canvas) {
  return (canvas.dataset.sensorId || 'sim') + '|' + (canvas.dataset.sensorType || '');
}

function buildDeviceChart(d) {
  if (!d || !d.sensor_type) return;
  const canvas = document.querySelector(
    'canvas[data-sensor-id="' + cssEscape(d.sensor_id || '__simulator__') + '"]' +
    '[data-sensor-type="' + cssEscape(d.sensor_type) + '"]'
  );
  if (!canvas) return;
  const color = COLOR_MAP[d.sensor_type] || COLOR_MAP.simulator;
  const key = canvasKey(canvas);
  const label = (d.display_name || d.sensor_id || d.sensor_type) +
                ' (' + (d.unit || '') + ')';
  const latestId = canvas.id.replace('chart-', 'latest-');

  if (charts[key]) {
    const c = charts[key];
    c.data.labels = d.labels || [];
    c.data.datasets[0].data = d.values || [];
    c.update('none');
    setLatest(latestId, d.latest, d.unit);
    return;
  }

  const ctx = canvas.getContext('2d');
  charts[key] = new Chart(ctx, {
    type: 'line',
    data: {
      labels: d.labels || [],
      datasets: [{
        label: label,
        data: d.values || [],
        borderColor: color,
        backgroundColor: color + '20',
        tension: 0.35,
        fill: true,
        pointRadius: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      plugins: {
        legend: { display: true },
        tooltip: { mode: 'index', intersect: false }
      },
      interaction: { mode: 'nearest', intersect: false },
      scales: {
        x: { ticks: { autoSkip: true, maxRotation: 0, maxTicksLimit: 8 } },
        y: { beginAtZero: false }
      }
    }
  });

  setLatest(latestId, d.latest, d.unit);
}

function setLatest(latestId, val, unit) {
  const el = document.getElementById(latestId);
  if (el && val != null) el.textContent = Number(val).toFixed(2) + (unit || '');
}

function cssEscape(s) {
  if (window.CSS && CSS.escape) return CSS.escape(s);
  return String(s).replace(/"/g, '\\"');
}

async function loadInitial() {
  try {
    const data = await fetch('/api/telemetry/latest').then(r => r.json());
    (data.devices || []).forEach(buildDeviceChart);
  } catch (e) {
    console.error('Initial chart load failed', e);
  }
}

function appendReading(reading) {
  if (!reading) return;
  const sid = reading.sensor_id || '__simulator__';
  const stype = reading.sensor_type || 'simulator';
  const canvas = document.querySelector(
    'canvas[data-sensor-id="' + cssEscape(sid) + '"]' +
    '[data-sensor-type="' + cssEscape(stype) + '"]'
  );
  if (!canvas) {
    // Unknown canvas → device must be new → page will reload after toast
    return;
  }
  const key = canvasKey(canvas);
  const chart = charts[key];
  if (!chart) return;

  const ds = chart.data.datasets[0].data;
  const labels = chart.data.labels;
  const labelStr = (reading.timestamp || '').slice(11, 19);
  const val = Number(reading.reading_value);

  labels.push(labelStr);
  ds.push(val);
  while (labels.length > MAX_POINTS) {
    labels.shift();
    ds.shift();
  }
  chart.update('none');

  const latestId = canvas.id.replace('chart-', 'latest-');
  setLatest(latestId, val, canvas.dataset.unit || '');
}

function setConnStatus(text, ok) {
  const el = document.getElementById('connStatus');
  const dot = document.getElementById('liveDot');
  if (el) el.textContent = text;
  if (dot) dot.classList.toggle('disconnected', !ok);
}

function showNewDeviceToast(sensorId) {
  const el = document.getElementById('newDeviceId');
  if (el) el.textContent = sensorId;
  const toastEl = document.getElementById('newDeviceToast');
  if (!toastEl || typeof bootstrap === 'undefined') return;
  const toast = new bootstrap.Toast(toastEl, { delay: 1500 });
  toast.show();
}

document.addEventListener('DOMContentLoaded', () => {
  loadInitial();

  if (typeof EventSource === 'undefined') {
    setConnStatus('EventSource not supported', false);
    return;
  }

  const es = new EventSource('/api/telemetry/stream');

  es.addEventListener('hello', () => setConnStatus('LIVE - receiving updates', true));

  es.addEventListener('reading', e => {
    try { appendReading(JSON.parse(e.data)); } catch (err) { /* ignore */ }
  });

  es.addEventListener('device_added', e => {
    try {
      const ev = JSON.parse(e.data);
      showNewDeviceToast(ev.sensor_id || 'unknown');
      setTimeout(() => location.reload(), 1800);
    } catch (err) { /* ignore */ }
  });

  es.onerror = () => setConnStatus('Disconnected - retrying...', false);
});




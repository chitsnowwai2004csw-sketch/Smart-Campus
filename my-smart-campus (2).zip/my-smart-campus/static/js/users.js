function injectAlert(type, message) {
  const wrap = document.getElementById('alerts');
  if (!wrap) return;
  const div = document.createElement('div');
  div.className = `alert alert-${type} alert-dismissible fade show alert-inline`;
  div.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;
  wrap.prepend(div);
  setTimeout(() => {
    div.classList.remove('show');
    setTimeout(() => div.remove(), 200);
  }, 4000);
}

function escapeHtml(s) {
  return (s == null ? '' : String(s)).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function bindUserRowHandlers() {
  // Edit button
  document.querySelectorAll('.edit-user').forEach(btn => {
    if (btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => {
      const row = document.getElementById(`urow-${btn.dataset.id}`);
      if (!row) return;
      document.getElementById('userIdField').value = row.dataset.id;
      document.getElementById('userUsernameField').value = row.dataset.username;
      document.getElementById('userUsernameField').readOnly = true;
      document.getElementById('userFullNameField').value = row.dataset.fullName;
      document.getElementById('userRoleField').value = row.dataset.role;
      document.getElementById('userActiveField').checked = row.dataset.active === '1';
      document.getElementById('userPasswordField').value = '';
      document.getElementById('userPasswordField').required = false;
      document.getElementById('userModalTitle').textContent = `Edit User #${row.dataset.id}`;
      document.getElementById('userSubmitLabel').textContent = 'Update User';
      document.getElementById('userModalHelp').innerHTML = 'Editing <strong>' + escapeHtml(row.dataset.username) + '</strong>. Password cannot be changed here; use the Reset Password button instead.';
      new bootstrap.Modal(document.getElementById('userModal')).show();
    });
  });

  // Reset password button
  document.querySelectorAll('.reset-pw').forEach(btn => {
    if (btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => {
      document.getElementById('resetPwUserId').value = btn.dataset.id;
      document.getElementById('resetPwUsername').textContent = btn.dataset.username;
      document.getElementById('resetPwField').value = '';
      new bootstrap.Modal(document.getElementById('resetPwModal')).show();
    });
  });

  // Enable toggle switch
  document.querySelectorAll('.enabled-toggle').forEach(sw => {
    if (sw.dataset.bound) return;
    sw.dataset.bound = '1';
    sw.addEventListener('change', async () => {
      const id = sw.dataset.id;
      const username = sw.dataset.username;
      const newState = sw.checked ? 1 : 0;
      const originalState = newState === 1 ? 0 : 1;
      const isSelfRow = sw.hasAttribute('data-self-disabled');
      sw.disabled = true;
      try {
        const res = await fetch(`/api/users/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            full_name: sw.dataset.fullName,
            role: sw.dataset.role,
            is_active: newState
          })
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          const label = sw.parentElement.querySelector('.enabled-state-text');
          if (label) label.textContent = newState ? 'Enabled' : 'Disabled';
          injectAlert(data.type || 'success',
            newState ? `User '${username}' enabled.` : `User '${username}' disabled.`);
        } else {
          sw.checked = !!originalState;
          injectAlert(data.type || 'danger', data.message || 'Failed to update status.');
        }
      } catch (e) {
        sw.checked = !!originalState;
        injectAlert('danger', 'Network error while updating status.');
      } finally {
        sw.disabled = isSelfRow;
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Initial bind + listen for table-updated event (fired by settings_users.js
  // fallback when it populates the table client-side).
  bindUserRowHandlers();
  document.addEventListener('users:table-updated', bindUserRowHandlers);

  const addBtn = document.getElementById('addUserBtn');
  const form = document.getElementById('userForm');

  if (addBtn && form) {
    addBtn.addEventListener('click', () => {
      document.getElementById('userIdField').value = '';
      form.reset();
      document.getElementById('userModalTitle').textContent = 'Add New User';
      document.getElementById('userSubmitLabel').textContent = 'Create User';
      document.getElementById('userModalHelp').innerHTML = 'New user must change this password on first login.';
      document.getElementById('userPasswordField').required = true;
      document.getElementById('userUsernameField').readOnly = false;
    });
  }

  if (form) {
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const btn = document.getElementById('userSubmitBtn');
      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Working...';
      const fd = new FormData(form);
      const payload = Object.fromEntries(fd.entries());
      const uid = payload.user_id;
      const isEdit = !!uid;
      delete payload.user_id;
      if (isEdit) {
        payload.is_active = document.getElementById('userActiveField').checked ? 1 : 0;
      }
      const url = isEdit ? `/api/users/${uid}` : '/api/users';
      const method = isEdit ? 'PUT' : 'POST';
      try {
        const res = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          injectAlert(data.type || 'success', data.message);
          bootstrap.Modal.getInstance(document.getElementById('userModal')).hide();
          setTimeout(() => location.reload(), 400);
        } else {
          injectAlert(data.type || 'danger', data.message || (isEdit ? 'Failed to update user.' : 'Failed to create user.'));
        }
      } catch (e) {
        injectAlert('danger', 'Network error while saving user.');
      } finally {
        btn.disabled = false;
        btn.innerHTML = original;
      }
    });
  }

  document.querySelectorAll('.edit-user').forEach(btn => {
    if (btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => {
      const row = document.getElementById(`urow-${btn.dataset.id}`);
      if (!row) return;
      document.getElementById('userIdField').value = row.dataset.id;
      document.getElementById('userUsernameField').value = row.dataset.username;
      document.getElementById('userUsernameField').readOnly = true;
      document.getElementById('userFullNameField').value = row.dataset.fullName;
      document.getElementById('userRoleField').value = row.dataset.role;
      document.getElementById('userActiveField').checked = row.dataset.active === '1';
      document.getElementById('userPasswordField').value = '';
      document.getElementById('userPasswordField').required = false;
      document.getElementById('userModalTitle').textContent = `Edit User #${row.dataset.id}`;
      document.getElementById('userSubmitLabel').textContent = 'Update User';
      document.getElementById('userModalHelp').innerHTML = 'Editing <strong>' + escapeHtml(row.dataset.username) + '</strong>. Password cannot be changed here; use the Reset Password button instead.';
      new bootstrap.Modal(document.getElementById('userModal')).show();
    });
  });

  document.querySelectorAll('.reset-pw').forEach(btn => {
    if (btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => {
      document.getElementById('resetPwUserId').value = btn.dataset.id;
      document.getElementById('resetPwUsername').textContent = btn.dataset.username;
      document.getElementById('resetPwField').value = '';
      new bootstrap.Modal(document.getElementById('resetPwModal')).show();
    });
  });

  const resetForm = document.getElementById('resetPwForm');
  if (resetForm) {
    resetForm.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const uid = document.getElementById('resetPwUserId').value;
      const pw = document.getElementById('resetPwField').value;
      const btn = document.getElementById('resetPwSubmitBtn');
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
      try {
        const res = await fetch(`/api/users/${uid}/password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ password: pw })
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          injectAlert(data.type || 'success', data.message);
          bootstrap.Modal.getInstance(document.getElementById('resetPwModal')).hide();
          setTimeout(() => location.reload(), 400);
        } else {
          injectAlert(data.type || 'danger', data.message || 'Failed to reset password.');
        }
      } catch (e) {
        injectAlert('danger', 'Network error while resetting password.');
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-key"></i> Reset Password';
      }
    });
  }

  document.querySelectorAll('.deactivate-user').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const name = btn.dataset.username;
      if (!window.confirm(`Deactivate user "${name}"? They will no longer be able to log in. (Reversible.)`)) return;
      btn.disabled = true;
      const original = btn.innerHTML;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
      try {
        const res = await fetch(`/api/users/${id}`, { method: 'DELETE' });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          injectAlert(data.type || 'success', data.message);
          setTimeout(() => location.reload(), 400);
        } else {
          injectAlert(data.type || 'danger', data.message || 'Failed to deactivate user.');
          btn.disabled = false;
          btn.innerHTML = original;
        }
      } catch (e) {
        injectAlert('danger', 'Network error while deactivating user.');
        btn.disabled = false;
        btn.innerHTML = original;
      }
    });
  });

  document.querySelectorAll('.enabled-toggle').forEach(sw => {
    if (sw.dataset.bound) return;
    sw.dataset.bound = '1';
    sw.addEventListener('change', async () => {
      const id = sw.dataset.id;
      const username = sw.dataset.username;
      const newState = sw.checked ? 1 : 0;
      const originalState = newState === 1 ? 0 : 1;
      const isSelfRow = sw.hasAttribute('data-self-disabled');
      sw.disabled = true;
      try {
        const res = await fetch(`/api/users/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            full_name: sw.dataset.fullName,
            role: sw.dataset.role,
            is_active: newState
          })
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          const label = sw.parentElement.querySelector('.enabled-state-text');
          if (label) label.textContent = newState ? 'Enabled' : 'Disabled';
          injectAlert(data.type || 'success',
            newState ? `User '${username}' enabled.` : `User '${username}' disabled.`);
        } else {
          sw.checked = !!originalState;
          injectAlert(data.type || 'danger', data.message || 'Failed to update status.');
        }
      } catch (e) {
        sw.checked = !!originalState;
        injectAlert('danger', 'Network error while updating status.');
      } finally {
        sw.disabled = isSelfRow;
      }
    });
  });

  document.querySelectorAll('.approve-user').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const username = btn.dataset.username;
      const confirmBtn = document.getElementById('confirmActionBtn');
      const extra = document.getElementById('confirmActionExtra');
      const roleSelect = document.getElementById('confirmActionRole');
      document.getElementById('confirmActionTitle').textContent = 'Approve User';
      document.getElementById('confirmActionBody').innerHTML =
        'Approve <strong>' + escapeHtml(username) + '</strong> and assign a role. They will be able to sign in immediately.';
      // Show role dropdown for approval flow
      if (extra) extra.classList.remove('d-none');
      if (roleSelect) roleSelect.value = 'User';
      confirmBtn.className = 'btn btn-success';
      confirmBtn.textContent = 'Approve';
      const modal = new bootstrap.Modal(document.getElementById('confirmActionModal'));
      confirmBtn.onclick = () => {
        modal.hide();
        if (extra) extra.classList.add('d-none');
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        const selectedRole = roleSelect ? roleSelect.value : 'User';
        fetch('/api/users/' + id + '/approve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ role: selectedRole })
        })
        .then(r => r.json())
        .then(d => {
          if (d.ok) {
            injectAlert(d.type || 'success', d.message);
            setTimeout(() => location.reload(), 500);
          } else {
            injectAlert(d.type || 'danger', d.message || 'Failed to approve.');
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-check2-circle me-1"></i> Approve';
          }
        })
        .catch(() => {
          injectAlert('danger', 'Network error.');
          btn.disabled = false;
          btn.innerHTML = '<i class="bi bi-check2-circle me-1"></i> Approve';
        });
      };
      modal.show();
    });
  });

  document.querySelectorAll('.reject-user').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const username = btn.dataset.username;
      const confirmBtn = document.getElementById('confirmActionBtn');
      const extra = document.getElementById('confirmActionExtra');
      document.getElementById('confirmActionTitle').textContent = 'Reject Signup';
      document.getElementById('confirmActionBody').innerHTML =
        'Reject and delete the signup for <strong>' + escapeHtml(username) + '</strong>? This cannot be undone.';
      // Hide role dropdown (only shown for approve)
      if (extra) extra.classList.add('d-none');
      confirmBtn.className = 'btn btn-danger';
      confirmBtn.textContent = 'Reject';
      const modal = new bootstrap.Modal(document.getElementById('confirmActionModal'));
      confirmBtn.onclick = () => {
        modal.hide();
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        fetch('/api/users/' + id + '/reject', { method: 'POST' })
        .then(r => r.json())
        .then(d => {
          if (d.ok) {
            injectAlert(d.type || 'success', d.message);
            setTimeout(() => location.reload(), 500);
          } else {
            injectAlert(d.type || 'danger', d.message || 'Failed to reject.');
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-x-circle me-1"></i> Reject';
          }
        })
        .catch(() => {
          injectAlert('danger', 'Network error.');
          btn.disabled = false;
          btn.innerHTML = '<i class="bi bi-x-circle me-1"></i> Reject';
        });
      };
      modal.show();
    });
  });
});

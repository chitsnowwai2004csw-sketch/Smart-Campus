// Convert all [data-utc-ts] elements from server-stored UTC to viewer's local time.
function localizeAll() {
  document.querySelectorAll('[data-utc-ts]').forEach(function (el) {
    const raw = el.getAttribute('data-utc-ts');
    if (!raw) return;
    if (el.dataset.utcLocalized === '1') return;
    let d;
    try {
      const iso = raw.includes('T') ? raw : raw.replace(' ', 'T') + 'Z';
      d = new Date(iso);
    } catch (e) {
      return;
    }
    if (isNaN(d.getTime())) return;
    let localized;
    try {
      localized = d.toLocaleString();
    } catch (e) {
      localized = d.toString();
    }
    el.textContent = localized;
    el.dataset.utcLocalized = '1';
    el.title = 'Server UTC: ' + raw;
  });
}
document.addEventListener('DOMContentLoaded', localizeAll);

(function() {
  var username = window.PENDING_USERNAME || '';
  if (!username) return;

  var attempts = 0;
  var maxAttempts = 60;
  var statusEl = document.getElementById('pollStatus');

  var poll = setInterval(function() {
    attempts++;
    if (attempts > maxAttempts) {
      clearInterval(poll);
      if (statusEl) statusEl.innerHTML = '<i class="bi bi-clock"></i> Stopped checking. Please refresh manually.';
      return;
    }

    fetch('/api/check-approval?username=' + encodeURIComponent(username))
      .then(function(r) { return r.json().then(function(d) { return { ok: r.ok, status: r.status, data: d }; }).catch(function() { return { ok: r.ok, status: r.status, data: {} }; }); })
      .then(function(res) {
        if (res.data.approved) {
          clearInterval(poll);
          if (statusEl) {
            statusEl.innerHTML = '<span class="text-success"><i class="bi bi-check-circle-fill"></i> Account approved! Redirecting to sign in...</span>';
          }
          setTimeout(function() {
            window.location.href = '/login?approved=1';
          }, 1500);
        } else if (res.data.reason === 'rejected') {
          clearInterval(poll);
          if (statusEl) {
            statusEl.innerHTML = '<span class="text-danger"><i class="bi bi-x-circle-fill"></i> Your signup request was declined. Redirecting...</span>';
          }
          setTimeout(function() {
            window.location.href = '/signup-rejected?username=' + encodeURIComponent(username);
          }, 1500);
        }
      })
      .catch(function() {});
  }, 5000);
})();
function injectAlert(type, message) {
  const wrap = document.getElementById('alerts');
  if (!wrap) return;
  const div = document.createElement('div');
  div.className = `alert alert-${type} alert-dismissible fade show alert-inline`;
  div.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;
  wrap.prepend(div);
  setTimeout(() => {
    div.classList.remove('show');
    setTimeout(() => div.remove(), 200);
  }, 4000);
}

function escapeHtml(s) {
  return (s == null ? '' : String(s)).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

const STATUS_META = {
  'Operational':         { cls: 'bg-success',                icon: 'check-circle-fill' },
  'Maintenance Required':{ cls: 'bg-warning text-dark',      icon: 'exclamation-triangle-fill' },
  'Offline':            { cls: 'bg-danger',                 icon: 'record-circle-fill' }
};

function renderBadge(badge, status) {
  const meta = STATUS_META[status];
  if (!meta) return;
  badge.className = `badge ${meta.cls} status-badge d-inline-flex align-items-center gap-1`;
  badge.dataset.id = badge.dataset.id;
  const isOffline = status === 'Offline';
  badge.innerHTML =
    `<i class="bi bi-${meta.icon}${isOffline ? ' pulse' : ''}"></i> ${escapeHtml(status)}`;
}

function renderRow(e, isAdmin) {
  const meta = STATUS_META[e.status] || STATUS_META['Operational'];
  const isOffline = e.status === 'Offline';
  const tr = document.createElement('tr');
  tr.id = `row-${e.id}`;
  tr.dataset.id = e.id;
  tr.dataset.name = e.name;
  tr.dataset.location = e.location;
  tr.dataset.building = e.building || '';
  tr.dataset.category = e.category;
  tr.dataset.status = e.status;
  tr.dataset.lastInspected = e.last_inspected || '';
  tr.dataset.search = `${e.name} ${e.location} ${e.category}`.toLowerCase();

  const adminCell = isAdmin
    ? `<td>
        <div class="input-group input-group-sm">
          <select class="form-select status-select" data-id="${e.id}" aria-label="Change status">
            ${['Operational','Maintenance Required','Offline']
              .map(s => `<option value="${s}" ${s===e.status?'selected':''}>${escapeHtml(s)}</option>`).join('')}
          </select>
          <button class="btn btn-primary save-status" data-id="${e.id}" type="button" title="Save status">
            <i class="bi bi-save"></i>
          </button>
          <button class="btn btn-warning edit-equip" data-id="${e.id}" type="button" title="Edit equipment">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-danger delete-equip" data-id="${e.id}" data-name="${escapeHtml(e.name)}" type="button" title="Delete equipment">
            <i class="bi bi-trash"></i>
          </button>
        </div>
      </td>`
    : '<td class="text-center"><span class="badge bg-secondary">Read Only</span></td>';

  const buildingHtml = e.building
    ? `<span class="badge bg-primary">Block ${escapeHtml(e.building)}</span>`
    : '<span class="text-muted">—</span>';

  tr.innerHTML = `
    <td>${e.id}</td>
    <td class="fw-semibold">${escapeHtml(e.name)}</td>
    <td>${buildingHtml}</td>
    <td>${escapeHtml(e.location)}</td>
    <td><span class="badge bg-light text-dark border">${escapeHtml(e.category)}</span></td>
    <td>
      <span class="badge ${meta.cls} status-badge d-inline-flex align-items-center gap-1" data-id="${e.id}">
        <i class="bi bi-${meta.icon}${isOffline ? ' pulse' : ''}"></i> ${escapeHtml(e.status)}
      </span>
    </td>
    <td class="small text-muted">${escapeHtml(e.last_inspected || '')}</td>
    ${adminCell}
  `;
  const saveBtn = tr.querySelector('.save-status');
  if (saveBtn) wireSaveStatus(saveBtn);
  const editBtn = tr.querySelector('.edit-equip');
  if (editBtn) wireEditEquip(editBtn);
  const delBtn = tr.querySelector('.delete-equip');
  if (delBtn) wireDeleteEquip(delBtn);
  return tr;
}

function wireSaveStatus(btn) {
  btn.addEventListener('click', async () => {
    const id = btn.dataset.id;
    const select = document.querySelector(`.status-select[data-id="${id}"]`);
    if (!select) return;
    const status = select.value;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
    try {
      const res = await fetch(`/api/equipment/${id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        const badge = document.querySelector(`.status-badge[data-id="${id}"]`);
        if (badge) renderBadge(badge, status);
        const row = document.getElementById(`row-${id}`);
        if (row) row.dataset.status = status;
        applyFilters();
        injectAlert(data.type || 'success', data.message || 'Equipment status updated.');
      } else {
        injectAlert(data.type || 'danger', data.message || 'Failed to update equipment status.');
      }
    } catch (e) {
      injectAlert('danger', 'Network error while updating equipment.');
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-save"></i>';
    }
  });
}

function wireEditEquip(btn) {
  btn.addEventListener('click', async () => {
    const row = document.getElementById(`row-${btn.dataset.id}`);
    if (!row) return;
    const modalEl = document.getElementById('equipModal');
    document.getElementById('equipIdField').value = row.dataset.id;
    document.getElementById('equipNameField').value = row.dataset.name;
    document.getElementById('equipCategoryField').value = row.dataset.category;
    document.getElementById('equipStatusField').value = row.dataset.status;
    document.getElementById('equipDateField').value = row.dataset.lastInspected || '';
    document.getElementById('equipModalTitle').textContent = `Edit Equipment #${row.dataset.id}`;
    document.getElementById('equipSubmitLabel').textContent = 'Update Equipment';
    document.getElementById('equipModalHelp').innerHTML = 'Editing <strong>' + escapeHtml(row.dataset.name) + '</strong>. Save to apply changes.';
    // Pre-populate structured location fields
    await prefillLocationDropdowns(
      row.dataset.building || '',
      row.dataset.floorNumber || '',
      row.dataset.roomId || ''
    );
    new bootstrap.Modal(modalEl).show();
  });
}

// Cascading dropdowns ================================================
async function loadFloorsForBuilding(code, targetSelect) {
  targetSelect.innerHTML = '<option value="">Loading…</option>';
  targetSelect.disabled = true;
  try {
    const res = await fetch(`/api/buildings/${encodeURIComponent(code)}/floors`);
    const data = await res.json().catch(() => ({}));
    const floors = data.floors || [];
    targetSelect.innerHTML = '<option value="">— Select floor —</option>' +
      floors.map(f => `<option value="${f.floor_number}">${escapeHtml(f.label)}</option>`).join('');
    targetSelect.disabled = false;
  } catch (e) {
    targetSelect.innerHTML = '<option value="">Failed to load floors</option>';
    targetSelect.disabled = true;
  }
  return targetSelect;
}

async function loadRoomsForFloor(code, floorNumber, targetSelect) {
  targetSelect.innerHTML = '<option value="">Loading…</option>';
  targetSelect.disabled = true;
  try {
    const res = await fetch(`/api/buildings/${encodeURIComponent(code)}/floors/${floorNumber}/rooms`);
    const data = await res.json().catch(() => ({}));
    const rooms = data.rooms || [];
    targetSelect.innerHTML = '<option value="">— Select room —</option>' +
      rooms.map(r => `<option value="${r.id}">${escapeHtml(r.name)}</option>`).join('');
    targetSelect.disabled = false;
  } catch (e) {
    targetSelect.innerHTML = '<option value="">Failed to load rooms</option>';
    targetSelect.disabled = true;
  }
  return targetSelect;
}

function updateLocationPreview(buildingSelect, floorSelect, roomSelect, targetEl) {
  if (!targetEl) return;
  const b = buildingSelect.options[buildingSelect.selectedIndex];
  const f = floorSelect.options[floorSelect.selectedIndex];
  const r = roomSelect.options[roomSelect.selectedIndex];
  const parts = [];
  if (b && b.value) parts.push(b.text);
  if (f && f.value) parts.push(f.text);
  if (r && r.value) parts.push(r.text);
  targetEl.textContent = parts.length ? parts.join(' - ') : '—';
}

function wireLocationSelectors() {
  const building = document.getElementById('equipBuildingField');
  const floor = document.getElementById('equipFloorField');
  const room = document.getElementById('equipRoomField');
  const preview = document.getElementById('equipLocationPreview');
  if (!building || !floor || !room) return;
  if (building._wired) return;
  building._wired = true;

  building.addEventListener('change', async () => {
    floor.innerHTML = '<option value="">— Select floor —</option>';
    floor.disabled = true;
    room.innerHTML = '<option value="">— Select floor first —</option>';
    room.disabled = true;
    updateLocationPreview(building, floor, room, preview);
    if (building.value) {
      await loadFloorsForBuilding(building.value, floor);
    }
  });
  floor.addEventListener('change', async () => {
    room.innerHTML = '<option value="">— Select room —</option>';
    room.disabled = true;
    updateLocationPreview(building, floor, room, preview);
    if (building.value && floor.value !== '') {
      await loadRoomsForFloor(building.value, parseInt(floor.value, 10), room);
    }
  });
  room.addEventListener('change', () => updateLocationPreview(building, floor, room, preview));
}

async function prefillLocationDropdowns(buildingCode, floorNumber, roomId) {
  const building = document.getElementById('equipBuildingField');
  const floor = document.getElementById('equipFloorField');
  const room = document.getElementById('equipRoomField');
  const preview = document.getElementById('equipLocationPreview');
  if (!building || !floor || !room) return;
  building.value = buildingCode || '';
  if (buildingCode) {
    await loadFloorsForBuilding(buildingCode, floor);
    if (floorNumber !== '' && floorNumber !== null && floorNumber !== undefined && !isNaN(parseInt(floorNumber, 10))) {
      floor.value = floorNumber;
      await loadRoomsForFloor(buildingCode, parseInt(floorNumber, 10), room);
      if (roomId) room.value = roomId;
    }
  } else {
    floor.innerHTML = '<option value="">— Select building first —</option>';
    floor.disabled = true;
    room.innerHTML = '<option value="">— Select floor first —</option>';
    room.disabled = true;
  }
  updateLocationPreview(building, floor, room, preview);
}

function resetLocationDropdowns() {
  const building = document.getElementById('equipBuildingField');
  const floor = document.getElementById('equipFloorField');
  const room = document.getElementById('equipRoomField');
  const preview = document.getElementById('equipLocationPreview');
  if (building) {
    building.value = '';
    building.dispatchEvent(new Event('change'));
  }
  if (floor) {
    floor.innerHTML = '<option value="">— Select building first —</option>';
    floor.disabled = true;
  }
  if (room) {
    room.innerHTML = '<option value="">— Select floor first —</option>';
    room.disabled = true;
  }
  if (preview) preview.textContent = '—';
}

function wireDeleteEquip(btn) {
  btn.addEventListener('click', async () => {
    const id = btn.dataset.id;
    const name = btn.dataset.name || ('#' + id);
    if (!window.confirm(`Delete equipment "${name}"? This cannot be undone.`)) return;
    btn.disabled = true;
    const original = btn.innerHTML;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
    try {
      const res = await fetch(`/api/equipment/${id}`, { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        injectAlert(data.type || 'success', data.message || 'Equipment deleted.');
        location.reload();
      } else {
        injectAlert(data.type || 'danger', data.message || 'Failed to delete equipment.');
        btn.disabled = false;
        btn.innerHTML = original;
      }
    } catch (e) {
      injectAlert('danger', 'Network error while deleting equipment.');
      btn.disabled = false;
      btn.innerHTML = original;
    }
  });
}

function applyFilters() {
  const q = (document.getElementById('equipSearch')?.value || '').toLowerCase().trim();
  const f = document.getElementById('statusFilter')?.value || 'All';
  const c = document.getElementById('categoryFilter')?.value || 'All';
  const b = document.getElementById('buildingFilter')?.value || 'All';
  const rows = document.querySelectorAll('#equipTable tr[id^="row-"]');
  let visible = 0;
  rows.forEach(r => {
    const matchesText = !q || (r.dataset.search || '').includes(q);
    const matchesStatus = f === 'All' || r.dataset.status === f;
    const matchesCategory = c === 'All' || r.dataset.category === c;
    const matchesBuilding = b === 'All' || (r.dataset.building || '') === b;
    const show = matchesText && matchesStatus && matchesCategory && matchesBuilding;
    r.classList.toggle('row-hidden', !show);
    if (show) visible++;
  });
  const counter = document.getElementById('equipCount');
  if (counter) counter.textContent = visible;
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.save-status').forEach(wireSaveStatus);
  document.querySelectorAll('.edit-equip').forEach(wireEditEquip);
  document.querySelectorAll('.delete-equip').forEach(wireDeleteEquip);

  const search = document.getElementById('equipSearch');
  const filter = document.getElementById('statusFilter');
  const cat = document.getElementById('categoryFilter');
  const bld = document.getElementById('buildingFilter');
  if (search) {
    let timer = null;
    search.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(applyFilters, 150);
    });
  }
  if (filter) filter.addEventListener('change', applyFilters);
  if (cat) cat.addEventListener('change', applyFilters);
  if (bld) bld.addEventListener('change', applyFilters);
  applyFilters();

  const addBtn = document.getElementById('addEquipBtn');
  const form = document.getElementById('equipForm');
  if (addBtn && form) {
    addBtn.addEventListener('click', () => {
      document.getElementById('equipIdField').value = '';
      form.reset();
      resetLocationDropdowns();
      document.getElementById('equipModalTitle').textContent = 'Add New Equipment';
      document.getElementById('equipSubmitLabel').textContent = 'Save Equipment';
      document.getElementById('equipModalHelp').innerHTML = 'New equipment defaults to today for <strong>Last Inspected</strong> if left blank.';
    });
  }

  // Wire cascading location dropdowns
  wireLocationSelectors();

  if (form) {
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const btn = document.getElementById('equipSubmitBtn');
      const originalBtn = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Working...';
      const fd = new FormData(form);
      const payload = Object.fromEntries(fd.entries());
      const eid = payload.equipment_id;
      delete payload.equipment_id;
      const isEdit = !!eid;
      const url = isEdit ? `/api/equipment/${eid}` : '/api/equipment';
      const method = isEdit ? 'PUT' : 'POST';
      try {
        const res = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok) {
          injectAlert(data.type || 'success', data.message || (isEdit ? 'Equipment updated.' : 'Equipment added.'));
          const modalEl = document.getElementById('equipModal');
          bootstrap.Modal.getInstance(modalEl)?.hide();
          location.reload();
        } else {
          injectAlert(data.type || 'danger', data.message || (isEdit ? 'Failed to update equipment.' : 'Failed to add equipment.'));
        }
      } catch (e) {
        injectAlert('danger', 'Network error while saving equipment.');
      } finally {
        btn.disabled = false;
        btn.innerHTML = originalBtn;
      }
    });
  }
});

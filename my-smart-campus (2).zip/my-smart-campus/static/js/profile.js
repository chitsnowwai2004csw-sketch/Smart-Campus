// Profile page - rename form + change password form

function injectAlert(type, message) {
  const wrap = document.getElementById('alerts');
  if (!wrap) return;
  const div = document.createElement('div');
  div.className = 'alert alert-' + type + ' alert-dismissible fade show alert-inline';
  div.innerHTML = message + '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
  wrap.prepend(div);
  setTimeout(() => {
    div.classList.remove('show');
    setTimeout(() => div.remove(), 200);
  }, 4000);
}

function scorePassword(pw) {
  if (!pw) return 0;
  let score = 0;
  if (pw.length >= 8) score += 20;
  if (pw.length >= 12) score += 10;
  if (/[A-Z]/.test(pw)) score += 15;
  if (/[a-z]/.test(pw)) score += 15;
  if (/\d/.test(pw)) score += 15;
  if (/[^A-Za-z0-9]/.test(pw)) score += 15;
  const commons = ['password','password1','password123','qwerty','qwerty123','admin','admin123','letmein','welcome','iloveyou','abc123','111111','123123','000000','654321','master','hello','charlie','dragon','monkey','sunshine','trustno1'];
  if (commons.includes(pw.toLowerCase())) score = Math.max(0, score - 60);
  const unique = new Set(pw).size;
  if (unique >= 8) score += 10;
  return Math.min(100, score);
}

function strengthLabel(s) {
  if (s === 0) return '—';
  if (s < 40) return 'Weak';
  if (s < 70) return 'Fair';
  return 'Strong';
}

document.addEventListener('DOMContentLoaded', () => {
  // Profile edit toggle
  const readView = document.getElementById('profileReadView');
  const editView = document.getElementById('profileEditView');
  const editBtn = document.getElementById('editProfileBtn');
  const cancelBtn = document.getElementById('cancelEditBtn');

  if (editBtn && readView && editView) {
    editBtn.addEventListener('click', () => {
      readView.style.display = 'none';
      editView.style.display = '';
    });
  }
  if (cancelBtn && readView && editView) {
    cancelBtn.addEventListener('click', () => {
      editView.style.display = 'none';
      readView.style.display = '';
    });
  }

  // Profile edit form (full name + username)
  const profileEditForm = document.getElementById('profileEditForm');
  const usernameMsg = document.getElementById('usernameMsg');
  if (profileEditForm) {
    profileEditForm.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const btn = profileEditForm.querySelector('button[type="submit"]');
      const fullName = document.getElementById('renameField').value.trim();
      const newUsername = document.getElementById('newUsernameField').value.trim();
      if (!fullName) { alert('Full name is required.'); return; }
      if (!newUsername) { if (usernameMsg) { usernameMsg.textContent = 'Username required.'; usernameMsg.className = 'form-text text-danger'; } return; }
      btn.disabled = true;
      const original = btn.innerHTML;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
      if (usernameMsg) { usernameMsg.innerHTML = '&nbsp;'; usernameMsg.className = 'form-text'; }
      try {
        // Save full name (JSON response, no redirect bail)
        const nameRes = await fetch('/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
          body: new URLSearchParams({ full_name: fullName }).toString()
        });
        const nameData = await nameRes.json().catch(() => ({}));
        // Save username
        const userRes = await fetch('/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
          body: new URLSearchParams({ change_username: '1', new_username: newUsername }).toString()
        });
        const userData = await userRes.json().catch(() => ({}));
        if (userData.ok) {
          injectAlert('success', 'Profile updated.');
          setTimeout(() => location.reload(), 400);
        } else if (nameData.ok) {
          if (usernameMsg) { usernameMsg.textContent = userData.message || 'Username update failed.'; usernameMsg.className = 'form-text text-danger'; }
          injectAlert('danger', userData.message || 'Username update failed.');
          setTimeout(() => location.reload(), 1500);
        } else {
          const msg = [nameData.message, userData.message].filter(Boolean).join(' ') || 'Profile update failed.';
          if (usernameMsg) { usernameMsg.textContent = msg; usernameMsg.className = 'form-text text-danger'; }
          injectAlert('danger', msg);
        }
      } catch (e) {
        injectAlert('danger', 'Network error.');
      } finally {
        btn.disabled = false;
        btn.innerHTML = original;
      }
    });
  }

  // Change password form
  const newPw = document.getElementById('newPwField');
  const bar = document.getElementById('pwStrengthBar');
  const label = document.getElementById('pwStrengthLabel');
  const confirm = document.getElementById('confirmPwField');
  const matchLabel = document.getElementById('pwMatchLabel');

  function refreshStrength() {
    if (!newPw || !bar || !label) return;
    const s = scorePassword(newPw.value);
    bar.style.width = s + '%';
    bar.classList.remove('weak', 'fair', 'strong');
    if (s < 40) bar.classList.add('weak');
    else if (s < 70) bar.classList.add('fair');
    else bar.classList.add('strong');
    label.textContent = 'Strength: ' + strengthLabel(s) + ' (' + s + '%)';
  }

  function refreshMatch() {
    if (!confirm || !matchLabel) return;
    if (!confirm.value) { matchLabel.innerHTML = '&nbsp;'; return; }
    if (confirm.value === newPw.value) {
      matchLabel.textContent = 'Passwords match.';
      matchLabel.className = 'form-text text-success';
    } else {
      matchLabel.textContent = 'Passwords do not match.';
      matchLabel.className = 'form-text text-danger';
    }
  }

  if (newPw) {
    newPw.addEventListener('input', () => { refreshStrength(); refreshMatch(); });
    refreshStrength();
  }
  if (confirm) {
    confirm.addEventListener('input', refreshMatch);
  }

  const form = document.getElementById('changePwForm');
  if (form) {
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const fd = new FormData(form);
      const payload = Object.fromEntries(fd.entries());
      if (payload.new_password !== payload.confirm_password) {
        injectAlert('danger', 'Passwords do not match.');
        return;
      }
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Updating...';
      try {
        const res = await fetch('/profile', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
          },
          body: new URLSearchParams(payload).toString()
        });
        if (res.redirected) { location.reload(); return; }
        const data = await res.json().catch(() => ({}));
        if (data.ok) {
          injectAlert('success', data.message || 'Password updated.');
          form.reset();
          refreshStrength();
          matchLabel.innerHTML = '&nbsp;';
          setTimeout(() => location.reload(), 600);
        } else {
          injectAlert(data.type || 'danger', data.message || 'Failed to update password.');
        }
      } catch (e) {
        injectAlert('danger', 'Network error while updating password.');
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-save"></i> Update Password';
      }
    });
  }
});

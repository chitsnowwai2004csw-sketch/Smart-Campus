function injectAlert(type, message) {
  const wrap = document.getElementById('alerts');
  if (!wrap) return;
  const div = document.createElement('div');
  div.className = `alert alert-${type} alert-dismissible fade show alert-inline`;
  div.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;
  wrap.prepend(div);
  setTimeout(() => {
    div.classList.remove('show');
    setTimeout(() => div.remove(), 200);
  }, 4000);
}

const TICKET_STATUS_META = {
  'Pending':     { cls: 'bg-warning text-dark', icon: 'hourglass-split' },
  'In Progress': { cls: 'bg-info',              icon: 'arrow-repeat' },
  'Resolved':    { cls: 'bg-success',           icon: 'check2-circle' },
  'Rejected':    { cls: 'bg-danger',            icon: 'x-circle' }
};

function renderTicketBadge(badge, status) {
  const meta = TICKET_STATUS_META[status];
  if (!meta) return;
  badge.className = `badge ${meta.cls} tstatus d-inline-flex align-items-center gap-1`;
  badge.innerHTML = `<i class="bi bi-${meta.icon}"></i> ${status}`;
}

document.querySelectorAll('.save-ticket').forEach(btn => {
  btn.addEventListener('click', async () => {
    const id = btn.dataset.id;
    const select = document.querySelector(`.ticket-status[data-id="${id}"]`);
    if (!select) return;
    const status = select.value;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
    try {
      const res = await fetch(`/api/tickets/${id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        const badge = document.querySelector(`.tstatus[data-id="${id}"]`);
        if (badge) renderTicketBadge(badge, status);
        injectAlert(data.type || 'success', data.message || 'Ticket updated.');
      } else {
        injectAlert(data.type || 'danger', data.message || 'Failed to update ticket.');
      }
    } catch (e) {
      injectAlert('danger', 'Network error while updating ticket.');
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-save"></i> Save';
    }
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const eqSel  = document.getElementById('ticketEquipmentSelect');
  const locF   = document.getElementById('ticketLocationField');
  const catF   = document.getElementById('ticketCategoryField');
  const titleF = document.getElementById('ticketTitleField');
  const modal  = document.getElementById('ticketModal');

  function syncFromEquipment() {
    const opt = eqSel && eqSel.selectedIndex >= 0 ? eqSel.options[eqSel.selectedIndex] : null;
    if (!opt || !opt.value) {
      if (locF) locF.value = '';
      if (catF) catF.value = '';
      return;
    }
    if (locF) locF.value = opt.dataset.location || '';
    if (catF) catF.value = opt.dataset.category || '';
    if (titleF && !titleF.value.trim()) {
      titleF.value = 'Issue with ' + (opt.dataset.name || '');
    }
  }
  if (eqSel) eqSel.addEventListener('change', syncFromEquipment);

  if (modal) {
    modal.addEventListener('hidden.bs.modal', () => {
      if (eqSel) eqSel.value = '';
      if (locF) locF.value = '';
      if (catF) catF.value = '';
      if (titleF) titleF.value = '';
    });
  }
});

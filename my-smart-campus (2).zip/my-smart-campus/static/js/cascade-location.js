// Shared cascading Building -> Floor -> Room helper.
// Used by sensors.js (register + edit) and devices.js (edit).
(function (global) {
  function escapeHtml(s) {
    return (s == null ? '' : String(s)).replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  async function loadFloors(code, targetSelect) {
    targetSelect.innerHTML = '<option value="">Loading…</option>';
    targetSelect.disabled = true;
    try {
      const res = await fetch('/api/buildings/' + encodeURIComponent(code) + '/floors');
      const data = await res.json().catch(() => ({}));
      const floors = data.floors || [];
      targetSelect.innerHTML = '<option value="">— Select floor —</option>' +
        floors.map(f => '<option value="' + f.floor_number + '">' + escapeHtml(f.label) + '</option>').join('');
      targetSelect.disabled = false;
    } catch (e) {
      targetSelect.innerHTML = '<option value="">Failed to load floors</option>';
      targetSelect.disabled = true;
    }
  }

  async function loadRooms(code, floorNumber, targetSelect) {
    targetSelect.innerHTML = '<option value="">Loading…</option>';
    targetSelect.disabled = true;
    try {
      const res = await fetch('/api/buildings/' + encodeURIComponent(code) + '/floors/' + floorNumber + '/rooms');
      const data = await res.json().catch(() => ({}));
      const rooms = data.rooms || [];
      targetSelect.innerHTML = '<option value="">— Select room —</option>' +
        rooms.map(r => '<option value="' + r.id + '">' + escapeHtml(r.name) + '</option>').join('');
      targetSelect.disabled = false;
    } catch (e) {
      targetSelect.innerHTML = '<option value="">Failed to load rooms</option>';
      targetSelect.disabled = true;
    }
  }

  function updatePreview(buildingSel, floorSel, roomSel, detailInput, previewEl) {
    if (!previewEl) return;
    const b = buildingSel.options[buildingSel.selectedIndex];
    const f = floorSel.options[floorSel.selectedIndex];
    const r = roomSel.options[roomSel.selectedIndex];
    const parts = [];
    if (b && b.value) parts.push(b.text);
    if (f && f.value) parts.push(f.text);
    if (r && r.value) parts.push(r.text);
    let preview = parts.length ? parts.join(' - ') : '—';
    if (detailInput && detailInput.value && parts.length) {
      preview += ', ' + detailInput.value;
    }
    previewEl.textContent = preview;
  }

  function wireCascade(prefix) {
    const building = document.getElementById(prefix + 'Building');
    const floor = document.getElementById(prefix + 'FloorField');
    const room = document.getElementById(prefix + 'RoomField');
    const detail = document.getElementById(prefix + 'LocationDetail');
    const preview = document.getElementById(prefix + 'LocationPreview');
    if (!building || !floor || !room) return false;
    if (building._cascadeWired) return true;
    building._cascadeWired = true;

    building.addEventListener('change', async () => {
      floor.innerHTML = '<option value="">— Select floor —</option>';
      floor.disabled = true;
      room.innerHTML = '<option value="">— Select floor first —</option>';
      room.disabled = true;
      updatePreview(building, floor, room, detail, preview);
      if (building.value) {
        await loadFloors(building.value, floor);
      }
    });
    floor.addEventListener('change', async () => {
      room.innerHTML = '<option value="">— Select room —</option>';
      room.disabled = true;
      updatePreview(building, floor, room, detail, preview);
      if (building.value && floor.value !== '') {
        await loadRooms(building.value, parseInt(floor.value, 10), room);
      }
    });
    room.addEventListener('change', () => updatePreview(building, floor, room, detail, preview));
    if (detail) detail.addEventListener('input', () => updatePreview(building, floor, room, detail, preview));
    return true;
  }

  async function prefillCascade(prefix, buildingCode, floorNumber, roomId, locationDetail) {
    const building = document.getElementById(prefix + 'Building');
    const floor = document.getElementById(prefix + 'FloorField');
    const room = document.getElementById(prefix + 'RoomField');
    const detail = document.getElementById(prefix + 'LocationDetail');
    const preview = document.getElementById(prefix + 'LocationPreview');
    if (!building || !floor || !room) return;
    building.value = buildingCode || '';
    if (buildingCode) {
      await loadFloors(buildingCode, floor);
      if (floorNumber !== '' && floorNumber !== null && floorNumber !== undefined && !isNaN(parseInt(floorNumber, 10))) {
        floor.value = floorNumber;
        await loadRooms(buildingCode, parseInt(floorNumber, 10), room);
        if (roomId) room.value = roomId;
      }
    } else {
      floor.innerHTML = '<option value="">— Building first —</option>';
      floor.disabled = true;
      room.innerHTML = '<option value="">— Floor first —</option>';
      room.disabled = true;
    }
    if (detail) detail.value = locationDetail || '';
    updatePreview(building, floor, room, detail, preview);
  }

  function resetCascade(prefix) {
    const building = document.getElementById(prefix + 'Building');
    const floor = document.getElementById(prefix + 'FloorField');
    const room = document.getElementById(prefix + 'RoomField');
    const detail = document.getElementById(prefix + 'LocationDetail');
    const preview = document.getElementById(prefix + 'LocationPreview');
    if (building) {
      building.value = '';
      building.dispatchEvent(new Event('change'));
    }
    if (floor) {
      floor.innerHTML = '<option value="">— Building first —</option>';
      floor.disabled = true;
    }
    if (room) {
      room.innerHTML = '<option value="">— Floor first —</option>';
      room.disabled = true;
    }
    if (detail) detail.value = '';
    if (preview) preview.textContent = '—';
  }

  function buildCanonicalLocation(prefix) {
    const building = document.getElementById(prefix + 'Building');
    const floor = document.getElementById(prefix + 'FloorField');
    const room = document.getElementById(prefix + 'RoomField');
    const detail = document.getElementById(prefix + 'LocationDetail');
    if (!building || !floor || !room) return null;
    const b = building.options[building.selectedIndex];
    const f = floor.options[floor.selectedIndex];
    const r = room.options[room.selectedIndex];
    if (!b || !b.value) return { error: 'Building is required.' };
    if (!f || f.value === '') return { error: 'Floor is required.' };
    if (!r || !r.value) return { error: 'Room is required.' };
    let loc = b.text + ' - ' + f.text + ' - ' + r.text;
    if (detail && detail.value.trim()) loc += ', ' + detail.value.trim();
    return {
      location: loc,
      building_code: building.value,
      floor_number: floor.value,
      room_id: room.value,
      location_detail: detail ? detail.value.trim() : ''
    };
  }

  global.CascadeLocation = {
    loadFloors: loadFloors,
    loadRooms: loadRooms,
    updatePreview: updatePreview,
    wireCascade: wireCascade,
    prefillCascade: prefillCascade,
    resetCascade: resetCascade,
    buildCanonicalLocation: buildCanonicalLocation,
    escapeHtml: escapeHtml
  };
})(window);

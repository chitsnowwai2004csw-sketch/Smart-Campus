// Sensors page: test send, register device, interval change, delete device

function selectSensorType(type) {
  var icons = {Temperature:'bi-thermometer-half',Humidity:'bi-droplet-half','Air Quality':'bi-wind',Energy:'bi-lightning-charge-fill',CO2:'bi-cloud-fog2'};
  var colors = {Temperature:'danger',Humidity:'primary','Air Quality':'success',Energy:'warning',CO2:'secondary'};
  var tints = {Temperature:'#fee2e2',Humidity:'#dbeafe','Air Quality':'#d1fae5',Energy:'#fef3c7',CO2:'#e2e8f0'};
  localStorage.setItem('sensorType', type);
  document.querySelectorAll('.type-row').forEach(function(c) {
    c.classList.toggle('active', c.dataset.sensorType === type);
  });
  document.querySelectorAll('.type-devices-panel').forEach(function(p) {
    p.style.display = (p.dataset.sensorType === type) ? '' : 'none';
  });
  var header = document.getElementById('activeTypeHeader');
  var badge = document.getElementById('activeDeviceCount');
  if (header) header.textContent = type + ' Devices';
  var iconWrap = document.querySelector('.devices-header .type-icon-wrap');
  var icon = iconWrap ? iconWrap.querySelector('i') : null;
  if (icon) icon.className = 'bi ' + (icons[type]||'') + ' text-' + (colors[type]||'secondary');
  if (iconWrap) iconWrap.style.background = tints[type] || '#e2e8f0';
  var headerCard = document.getElementById('devicesCardHeader');
  if (headerCard) headerCard.style.background = 'linear-gradient(135deg, ' + (tints[type]||'#e2e8f0') + ', #ffffff)';
  if (badge) {
    var countText = type + ' device';
    var activeRow = document.querySelector('.type-row[data-sensor-type="' + type + '"]');
    if (activeRow) {
      var countEl = activeRow.querySelector('.type-count');
      if (countEl) countText = countEl.textContent;
    }
    badge.textContent = countText;
    badge.className = 'badge bg-' + (colors[type]||'secondary') + ' bg-opacity-10 text-' + (colors[type]||'secondary') + ' fs-6 fw-normal';
  }
}
(function() {
  var rows = document.querySelectorAll('.type-row');
  if (!rows.length) return;
  var saved = localStorage.getItem('sensorType');
  var validTypes = [];
  rows.forEach(function(r) { validTypes.push(r.dataset.sensorType); });
  var initial = (saved && validTypes.indexOf(saved) !== -1) ? saved : rows[0].dataset.sensorType;
  selectSensorType(initial);
  rows.forEach(function(r) {
    r.addEventListener('click', function() { selectSensorType(r.dataset.sensorType); });
  });
})();

// Sensor type-level toggle (legacy)
document.querySelectorAll('.sensor-toggle').forEach(function(sw) {
  sw.addEventListener('change', function() {
    var sensorType = sw.dataset.sensor;
    var newState = sw.checked ? 1 : 0;
    sw.disabled = true;
    fetch('/api/sensors/' + encodeURIComponent(sensorType) + '/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled: !!newState })
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.ok) {
        var label = sw.parentElement.querySelector('.form-check-label span');
        if (label) label.textContent = newState ? 'ON' : 'OFF';
      } else {
        sw.checked = !newState;
        alert(d.message || 'Failed.');
      }
    })
    .catch(function() { sw.checked = !newState; })
    .finally(function() { sw.disabled = false; });
  });
});

// Register Device (admin)
(function() {
  var modalEl = document.getElementById('registerDeviceModal');
  if (!modalEl) return;
  var modal = new bootstrap.Modal(modalEl);

  document.querySelectorAll('.add-device-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var stype = btn.dataset.sensorType;
      document.getElementById('regSensorType').value = stype;
      document.getElementById('regSensorTypeDisplay').value = stype;
      document.getElementById('regSensorId').value = '';
      document.getElementById('regDisplayName').value = '';
      document.getElementById('regInterval').value = '30';
      window.CascadeLocation.resetCascade('reg');
      modal.show();
    });
  });

  document.getElementById('registerDeviceForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var stype = document.getElementById('regSensorType').value;
    var sid = document.getElementById('regSensorId').value.trim();
    var dname = document.getElementById('regDisplayName').value.trim();
    var sel = document.getElementById('regIntervalSelect');
    var customInput = document.getElementById('regIntervalCustom');
    var interval;
    if (sel.value === 'custom') {
      interval = parseInt(customInput.value);
      if (!interval || interval < 5 || interval > 3600) {
        alert('Custom interval must be between 5 and 3600 seconds.');
        return;
      }
    } else {
      interval = parseInt(sel.value);
    }
    document.getElementById('regInterval').value = interval;
    if (!sid) { alert('Sensor ID required'); return; }
    var loc = window.CascadeLocation.buildCanonicalLocation('reg');
    if (loc.error) { alert(loc.error); return; }
    document.getElementById('regLocation').value = loc.location;
    fetch('/api/sensors/' + encodeURIComponent(stype) + '/devices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sensor_id: sid,
        location: loc.location,
        building_code: loc.building_code,
        floor_number: loc.floor_number,
        room_id: loc.room_id,
        location_detail: loc.location_detail,
        display_name: dname,
        update_interval_seconds: interval,
        enabled: true
      })
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.ok) {
        modal.hide();
        location.reload();
      } else {
        alert(d.message || 'Failed.');
      }
    })
    .catch(function() { alert('Network error.'); });
  });

  // Custom interval toggle
  var regSel = document.getElementById('regIntervalSelect');
  var regCustom = document.getElementById('regIntervalCustom');
  if (regSel && regCustom) {
    regSel.addEventListener('change', function() {
      if (regSel.value === 'custom') {
        regCustom.classList.remove('d-none');
      } else {
        regCustom.classList.add('d-none');
      }
    });
  }
})();

// Interval change (admin) with custom support
document.querySelectorAll('.interval-select').forEach(function(sel) {
  sel.addEventListener('change', function() {
    var id = sel.dataset.id;
    var interval;
    if (sel.value === 'custom') {
      var inp = prompt('Enter custom interval in seconds (5-3600):', '60');
      if (!inp) {
        // Reload to restore previous selection
        location.reload();
        return;
      }
      interval = parseInt(inp);
      if (!interval || interval < 5 || interval > 3600) {
        alert('Must be between 5 and 3600 seconds.');
        location.reload();
        return;
      }
    } else {
      interval = parseInt(sel.value);
    }
    sel.disabled = true;
    fetch('/api/devices/' + id + '/interval', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ update_interval_seconds: interval })
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (!d.ok) {
        alert(d.message || 'Failed.');
        location.reload();
      } else {
        // Reload to update the dropdown's selected option correctly
        location.reload();
      }
    })
    .catch(function() { alert('Network error.'); location.reload(); })
    .finally(function() { sel.disabled = false; });
  });
});

// Delete device (admin)
document.querySelectorAll('.delete-device-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var id = btn.dataset.id;
    var sid = btn.dataset.sid;
    if (!confirm("Remove device '" + sid + "' from registry? Telemetry history is preserved.")) return;
    fetch('/api/devices/' + id, { method: 'DELETE' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.ok) {
        var row = btn.closest('tr');
        if (row) row.remove();
      } else {
        alert(d.message || 'Failed.');
      }
    })
    .catch(function() { alert('Network error.'); });
  });
});

// Edit device (admin)
(function() {
  var modalEl = document.getElementById('editDeviceModal');
  if (!modalEl) return;
  var modal = new bootstrap.Modal(modalEl);
  var editSel = document.getElementById('editIntervalSelect');
  var editCustom = document.getElementById('editIntervalCustom');
  if (editSel && editCustom) {
    editSel.addEventListener('change', function() {
      editCustom.classList.toggle('d-none', editSel.value !== 'custom');
    });
  }

  document.querySelectorAll('.edit-device-btn').forEach(function(btn) {
    btn.addEventListener('click', async function() {
      document.getElementById('editDeviceId').value = btn.dataset.id;
      document.getElementById('editSensorId').value = btn.dataset.sid;
      var typeSel = document.getElementById('editSensorType');
      typeSel.value = btn.dataset.type;
      document.getElementById('editIntervalCustom').classList.add('d-none');
      document.getElementById('editDeviceError').classList.add('d-none');
      var interval = parseInt(btn.dataset.interval) || 30;
      var optExists = false;
      for (var i = 0; i < editSel.options.length; i++) {
        if (parseInt(editSel.options[i].value) === interval) { optExists = true; break; }
      }
      if (optExists) {
        editSel.value = String(interval);
      } else {
        editSel.value = 'custom';
        editCustom.classList.remove('d-none');
        editCustom.value = interval;
      }
      await window.CascadeLocation.prefillCascade(
        'edit',
        btn.dataset.building || '',
        btn.dataset.floorNumber || '',
        btn.dataset.roomId || '',
        btn.dataset.locationDetail || ''
      );
      modal.show();
    });
  });

  document.getElementById('editDeviceForm').addEventListener('submit', function(e) {
    e.preventDefault();
    var did = document.getElementById('editDeviceId').value;
    var newType = document.getElementById('editSensorType').value;
    var errDiv = document.getElementById('editDeviceError');
    errDiv.classList.add('d-none');
    var interval;
    if (editSel.value === 'custom') {
      interval = parseInt(editCustom.value);
      if (!interval || interval < 5 || interval > 3600) {
        errDiv.textContent = 'Custom interval must be between 5 and 3600 seconds.';
        errDiv.classList.remove('d-none');
        return;
      }
    } else {
      interval = parseInt(editSel.value);
    }
    var loc = window.CascadeLocation.buildCanonicalLocation('edit');
    if (loc.error) {
      errDiv.textContent = loc.error;
      errDiv.classList.remove('d-none');
      return;
    }
    document.getElementById('editLocation').value = loc.location;
    fetch('/api/devices/' + did + '/type', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sensor_type: newType,
        update_interval_seconds: interval,
        location: loc.location,
        building_code: loc.building_code,
        floor_number: loc.floor_number,
        room_id: loc.room_id,
        location_detail: loc.location_detail
      })
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.ok) {
        modal.hide();
        location.reload();
      } else {
        errDiv.textContent = d.message || 'Failed to update device.';
        errDiv.classList.remove('d-none');
      }
    })
    .catch(function() {
      errDiv.textContent = 'Network error.';
      errDiv.classList.remove('d-none');
    });
  });

  // Wire cascading location dropdowns (Register + Edit modals)
  if (window.CascadeLocation) {
    window.CascadeLocation.wireCascade('reg');
    window.CascadeLocation.wireCascade('edit');
  }
})();

// Audit Log Session v2.18: fixed filters + user background tints

(function(){
  // Click any audit data row to toggle its sibling detail row
  document.querySelectorAll('.audit-data-row').forEach(function(row){
    row.addEventListener('click', function(){
      row.classList.toggle('open');
      var detail = row.nextElementSibling;
      if (detail && detail.classList.contains('audit-detail-row')) {
        detail.classList.toggle('show');
      }
    });
  });

  // Filter panel toggle (Filters button)
  var filtersBtn = document.getElementById('auditFiltersBtn');
  var filterPanel = document.getElementById('auditFilterPanel');
  if (filtersBtn && filterPanel) {
    filtersBtn.addEventListener('click', function(){
      filterPanel.classList.toggle('show');
    });
  }

  // Search: type-to-submit (debounced 400ms) using header input
  var form = document.getElementById('auditFilterForm');
  var search = document.getElementById('auditSearch');
  function submitSearch() {
    // Build URL preserving current date/limit, with updated q
    var url = new URL(window.location.href);
    url.searchParams.set('q', search.value);
    window.location.href = url.toString();
  }
  if (search) {
    var t = null;
    search.addEventListener('input', function(){
      if (t) clearTimeout(t);
      t = setTimeout(submitSearch, 400);
    });
    // Press Enter to submit immediately
    search.addEventListener('keydown', function(e){
      if (e.key === 'Enter') {
        e.preventDefault();
        submitSearch();
      }
    });
  }

  // Date select: change preserves other current URL params
  var dateBtn = document.getElementById('auditDateBtn');
  if (dateBtn) {
    dateBtn.addEventListener('change', function(){
      var url = new URL(window.location.href);
      url.searchParams.set('date', this.value);
      window.location.href = url.toString();
    });
  }
})();

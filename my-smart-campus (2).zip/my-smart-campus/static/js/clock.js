// Live UTC clock + viewer-local clock. Renders into <span id="liveClock"> in base footer.
function updateClock() {
  const el = document.getElementById('liveClock');
  if (!el) return;
  const now = new Date();
  const utc = now.toISOString().slice(11, 19);
  let localStr;
  try {
    localStr = now.toLocaleString();
  } catch (e) {
    localStr = now.toString();
  }
  el.innerHTML = '<i class="bi bi-clock-history"></i> ' + utc + ' UTC &middot; ' + localStr;
}
document.addEventListener('DOMContentLoaded', () => {
  updateClock();
  setInterval(updateClock, 1000);
});

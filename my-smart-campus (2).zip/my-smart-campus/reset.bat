@echo off
REM Smart Campus - Full reset (Windows)
REM Wipes the database volume and rebuilds the container from scratch.
REM WARNING: This deletes all users, devices, equipment, and telemetry.

setlocal

echo ============================================
echo  Smart Campus - Full Reset (Windows)
echo ============================================
echo.
echo WARNING: This will DELETE all data (users, devices, equipment, telemetry).
echo.
set /p confirm=Type 'yes' to confirm: 
if /i not "%confirm%"=="yes" (
    echo Aborted.
    exit /b 0
)

echo.
where docker >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker is not installed or not in PATH.
    exit /b 1
)

echo Removing container and volume...
docker compose down -v

if errorlevel 1 (
    echo [ERROR] docker compose down -v failed.
    exit /b 1
)

echo Rebuilding from scratch...
call start.bat
endlocal

#!/usr/bin/env bash
# Smart Campus - Full reset (macOS / Linux)
# Wipes the database volume and rebuilds the container from scratch.
# WARNING: This deletes all users, devices, equipment, and telemetry.

set -e

echo "============================================"
echo " Smart Campus - Full Reset (macOS/Linux)"
echo "============================================"
echo
echo "WARNING: This will DELETE all data (users, devices, equipment, telemetry)."
echo
read -p "Type 'yes' to confirm: " confirm
if [ "$confirm" != "yes" ]; then
    echo "Aborted."
    exit 0
fi

echo
if ! command -v docker >/dev/null 2>&1; then
    echo "[ERROR] Docker is not installed."
    exit 1
fi

echo "Removing container and volume..."
docker compose down -v

echo "Rebuilding from scratch..."
exec "$(dirname "$0")/start.sh"

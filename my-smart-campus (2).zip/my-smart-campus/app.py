import os
import re
import sys
import sqlite3
import random
import hmac
import hashlib
import queue
import threading
import time
import bcrypt
from datetime import datetime, timedelta
from functools import wraps

# Ensure project root is importable (portable Python / odd cwd / VS Code F5).
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)
os.chdir(_PROJECT_ROOT)

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    jsonify,
    flash,
    Response,
    stream_with_context,
)

DB_PATH = os.path.join("instance", "smart_campus.db")

SENSOR_MODE = os.environ.get("SENSOR_MODE", "simulator")  # "simulator" | "real"
DEVICE_API_KEY = os.environ.get("DEVICE_API_KEY", "")

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-in-production-9f3a2b7c"
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 3600  # 1h browser cache for /static/*


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def ensure_schema():
    """Create tables if missing so the app stays servable before init_db.py runs."""
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash BLOB NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('Admin','User','Developer')),
            full_name TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS equipment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            location TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT 'Other'
                      CHECK(category IN ('HVAC','Lighting','Security','Plumbing','Electrical','Other')),
            status TEXT NOT NULL CHECK(status IN ('Operational','Maintenance Required','Offline')),
            last_inspected TEXT
        );
        CREATE TABLE IF NOT EXISTS telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sensor_type TEXT NOT NULL CHECK(sensor_type IN ('Temperature','Humidity','Air Quality','Energy','CO2')),
            reading_value REAL NOT NULL,
            unit TEXT NOT NULL,
            timestamp TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS maintenance_tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            priority TEXT NOT NULL CHECK(priority IN ('Low','Medium','High')),
            status TEXT NOT NULL CHECK(status IN ('Pending','In Progress','Resolved','Rejected')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        """
    )
    cols = [r[1] for r in conn.execute("PRAGMA table_info(equipment)").fetchall()]
    if "category" not in cols:
        conn.execute("ALTER TABLE equipment ADD COLUMN category TEXT NOT NULL DEFAULT 'Other'")
    tcols = [r[1] for r in conn.execute("PRAGMA table_info(maintenance_tickets)").fetchall()]
    if "equipment_id" not in tcols:
        conn.execute("ALTER TABLE maintenance_tickets ADD COLUMN equipment_id INTEGER REFERENCES equipment(id)")
    ucols = [r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()]
    if "is_active" not in ucols:
        conn.execute("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1")
    if "must_change_password" not in ucols:
        conn.execute("ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0")
    if "last_password_change" not in ucols:
        conn.execute("ALTER TABLE users ADD COLUMN last_password_change TEXT")
    if "status" not in ucols:
        conn.execute("ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'")
        conn.execute("UPDATE users SET status = 'active' WHERE status IS NULL")
    # Migration: allow 'rejected' status value (rebuilt table to update CHECK constraint)
    cur = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'")
    sql_text = cur.fetchone()[0] if cur else ""
    # Drop any leftover tmp tables from a previous botched migration run
    for leftover in ("users__old_rejected_migration",
                     "users__rejected_migration_tmp",
                     "users__fk_recovery_tmp"):
        conn.execute(f"DROP TABLE IF EXISTS {leftover}")
    if "CHECK(status IN ('active','pending','disabled','rejected'))" not in sql_text:
        # Rebuild table with updated CHECK constraint while preserving all rows.
        # Use PRAGMA legacy_alter_table = 1 to prevent SQLite from rewriting FK references
        # in dependent tables (maintenance_tickets.user_id, developer_profile.user_id) during
        # the rename. Strategy: rename old users -> tmp, CREATE new users with new CHECK,
        # copy data, DROP the tmp (so the new table with the right CHECK stays).
        try:
            conn.execute("PRAGMA foreign_keys=OFF")
            conn.execute("PRAGMA legacy_alter_table = 1")
            conn.execute("ALTER TABLE users RENAME TO users__rejected_migration_tmp")
            conn.execute("""
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash BLOB NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('Admin','User','Developer')),
                    full_name TEXT,
                    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','pending','disabled','rejected')),
                    is_active INTEGER NOT NULL DEFAULT 1,
                    must_change_password INTEGER NOT NULL DEFAULT 0,
                    last_password_change TEXT,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            """)
            # Copy data back into the NEW users table
            conn.execute("""
                INSERT INTO users (id, username, password_hash, role, full_name, status,
                                   is_active, must_change_password, last_password_change, created_at)
                SELECT id, username, password_hash, role, full_name, status,
                       is_active, must_change_password, last_password_change, created_at
                FROM users__rejected_migration_tmp
            """)
            # Drop the tmp (which has OLD schema); keep the new users (with new CHECK)
            conn.execute("DROP TABLE users__rejected_migration_tmp")
            conn.commit()
        except Exception as e:
            conn.rollback()
            print(f"[WARN] users rejected-status migration failed: {e}")
        finally:
            conn.execute("PRAGMA legacy_alter_table = 0")
            conn.execute("PRAGMA foreign_keys=ON")

    # Recovery: fix any FK references in other tables that were left pointing to a dropped/orphan
    # table name (can happen if a previous run of this migration used DROP TABLE instead of rename back).
    # Snapshot table names FIRST to avoid iterating over renamed tables.
    tables_to_check = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()]
    for tname in tables_to_check:
        if tname == "users" or "__fk_recovery_tmp" in tname:
            continue
        fk_rows = conn.execute(
            f"PRAGMA foreign_key_list({tname})"
        ).fetchall()
        # FK row: (id, seq, table, from, to, on_update, on_delete, match)
        bad = [fk for fk in fk_rows
               if fk[2] not in ("users", "equipment", "rooms", "buildings")
               or "users__" in fk[2]]
        if not bad:
            continue
        # Rebuild this table to fix its FK references
        try:
            conn.execute("PRAGMA foreign_keys=OFF")
            conn.execute("PRAGMA legacy_alter_table = 1")
            tmp_name = tname + "__fk_recovery_tmp"
            conn.execute(f"ALTER TABLE {tname} RENAME TO {tmp_name}")
            orig_sql = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (tmp_name,)
            ).fetchone()[0]
            new_sql = (orig_sql
                       .replace(f'"{tmp_name}"', f'"{tname}"')
                       .replace("users__old_rejected_migration", "users")
                       .replace("users__rejected_migration_tmp", "users"))
            conn.execute(new_sql)
            conn.execute(f"INSERT INTO {tname} SELECT * FROM {tmp_name}")
            conn.execute(f"ALTER TABLE {tmp_name} RENAME TO {tname}")
            conn.commit()
        finally:
            conn.execute("PRAGMA legacy_alter_table = 0")
            conn.execute("PRAGMA foreign_keys=ON")
    tcols2 = [r[1] for r in conn.execute("PRAGMA table_info(telemetry)").fetchall()]
    if "sensor_id" not in tcols2:
        conn.execute("ALTER TABLE telemetry ADD COLUMN sensor_id TEXT DEFAULT NULL")
    if "location" not in tcols2:
        conn.execute("ALTER TABLE telemetry ADD COLUMN location TEXT DEFAULT NULL")
    if "source" not in tcols2:
        conn.execute("ALTER TABLE telemetry ADD COLUMN source TEXT DEFAULT 'simulator'")
    if "received_at" not in tcols2:
        conn.execute("ALTER TABLE telemetry ADD COLUMN received_at TEXT DEFAULT NULL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS sensor_config (
            sensor_type TEXT PRIMARY KEY,
            enabled INTEGER NOT NULL DEFAULT 1,
            last_toggle_by TEXT,
            last_toggle_at TEXT
        );
    """)
    for stype in VALID_TYPES:
        exists = conn.execute("SELECT 1 FROM sensor_config WHERE sensor_type = ?", (stype,)).fetchone()
        if not exists:
            conn.execute("INSERT INTO sensor_config (sensor_type, enabled) VALUES (?, 1)", (stype,))

    conn.executescript("""
        CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sensor_id TEXT NOT NULL,
            sensor_type TEXT NOT NULL,
            location TEXT,
            display_name TEXT,
            enabled INTEGER NOT NULL DEFAULT 1,
            first_seen TEXT,
            last_seen TEXT,
            last_value REAL,
            last_unit TEXT,
            created_by TEXT,
            UNIQUE(sensor_id, sensor_type)
        );
    """)
    # Backfill: copy any (sensor_id, sensor_type) pairs already seen in telemetry
    conn.execute("""
        INSERT OR IGNORE INTO devices (sensor_id, sensor_type, location, first_seen, enabled)
        SELECT sensor_id, sensor_type,
               (SELECT location FROM telemetry t2
                WHERE t2.sensor_id = t1.sensor_id AND t2.sensor_type = t1.sensor_type
                ORDER BY t2.timestamp DESC LIMIT 1) AS location,
               MIN(timestamp), 1
        FROM telemetry t1
        WHERE sensor_id IS NOT NULL AND sensor_id != ''
        GROUP BY sensor_id, sensor_type
    """)
    # Update last_seen / last_value / last_unit / location from latest telemetry
    conn.execute("""
        UPDATE devices
        SET last_seen = (SELECT MAX(t2.timestamp) FROM telemetry t2
                         WHERE t2.sensor_id = devices.sensor_id
                           AND t2.sensor_type = devices.sensor_type),
            last_value = (SELECT reading_value FROM telemetry t2
                          WHERE t2.sensor_id = devices.sensor_id
                            AND t2.sensor_type = devices.sensor_type
                          ORDER BY timestamp DESC LIMIT 1),
            last_unit  = (SELECT unit FROM telemetry t2
                          WHERE t2.sensor_id = devices.sensor_id
                            AND t2.sensor_type = devices.sensor_type
                          ORDER BY timestamp DESC LIMIT 1),
            location   = COALESCE(
                (SELECT location FROM telemetry t2
                 WHERE t2.sensor_id = devices.sensor_id
                   AND t2.sensor_type = devices.sensor_type
                 ORDER BY timestamp DESC LIMIT 1),
                location
            )
        WHERE last_seen IS NULL
    """)
    conn.commit()
    conn.close()

    # New tables / columns: buildings, devices (building + interval), equipment (building)
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS buildings (
            code TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            floors INTEGER NOT NULL DEFAULT 5
        );
    """)
    for b in [("A", "Block A", 5), ("B", "Block B", 5), ("C", "Block C", 5)]:
        if not conn.execute("SELECT 1 FROM buildings WHERE code = ?", (b[0],)).fetchone():
            conn.execute("INSERT INTO buildings (code, name, floors) VALUES (?, ?, ?)", b)

    # === Floors + Rooms catalog (university campus) ===
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS floors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            building_code TEXT NOT NULL REFERENCES buildings(code),
            floor_number INTEGER NOT NULL,
            label TEXT NOT NULL,
            UNIQUE(building_code, floor_number)
        );
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            building_code TEXT NOT NULL REFERENCES buildings(code),
            floor_number INTEGER NOT NULL,
            name TEXT NOT NULL,
            UNIQUE(building_code, floor_number, name)
        );
    """)
    # Idempotent seed via shared catalog module (lazy import to keep top-level clean)
    from campus_catalog import UNIVERSITY_FLOORS, UNIVERSITY_ROOMS
    for code, floor_number, label in UNIVERSITY_FLOORS:
        if not conn.execute(
            "SELECT 1 FROM floors WHERE building_code=? AND floor_number=?",
            (code, floor_number),
        ).fetchone():
            conn.execute(
                "INSERT INTO floors (building_code, floor_number, label) VALUES (?, ?, ?)",
                (code, floor_number, label),
            )
    for code, floor_number, name in UNIVERSITY_ROOMS:
        if not conn.execute(
            "SELECT 1 FROM rooms WHERE building_code=? AND floor_number=? AND name=?",
            (code, floor_number, name),
        ).fetchone():
            conn.execute(
                "INSERT INTO rooms (building_code, floor_number, name) VALUES (?, ?, ?)",
                (code, floor_number, name),
            )

    dcols = [r[1] for r in conn.execute("PRAGMA table_info(devices)").fetchall()]
    if "building" not in dcols:
        conn.execute("ALTER TABLE devices ADD COLUMN building TEXT DEFAULT NULL")
    if "update_interval_seconds" not in dcols:
        conn.execute("ALTER TABLE devices ADD COLUMN update_interval_seconds INTEGER NOT NULL DEFAULT 30")
    if "last_expected_at" not in dcols:
        conn.execute("ALTER TABLE devices ADD COLUMN last_expected_at TEXT DEFAULT NULL")
    if "floor_number" not in dcols:
        conn.execute("ALTER TABLE devices ADD COLUMN floor_number INTEGER DEFAULT NULL")
    if "room_id" not in dcols:
        conn.execute("ALTER TABLE devices ADD COLUMN room_id INTEGER DEFAULT NULL REFERENCES rooms(id)")
    if "location_detail" not in dcols:
        conn.execute("ALTER TABLE devices ADD COLUMN location_detail TEXT DEFAULT NULL")

    # Backfill floor_number + room_id for existing devices from best-fit map (idempotent)
    DEVICE_LOCATION_BACKFILL = {
        "library 3f, block a - floor 2": ("A",  2, "Library"),
        "lab 3, block b - floor 1":     ("B",  1, "Lab 1 (Physics)"),
        "gym, block c - floor 1":       ("C",  2, "Gym"),
        "server room, block a - basement": ("A", -1, "Mechanical Room"),
        "cafeteria, block c - floor 2": ("C",  1, "Cafeteria"),
    }
    for needle, (b_code, f_num, r_name) in DEVICE_LOCATION_BACKFILL.items():
        room_row = conn.execute(
            "SELECT id FROM rooms WHERE building_code=? AND floor_number=? AND name=?",
            (b_code, f_num, r_name),
        ).fetchone()
        if not room_row:
            continue
        room_id = room_row["id"] if isinstance(room_row, sqlite3.Row) else room_row[0]
        conn.execute(
            "UPDATE devices SET floor_number=?, room_id=? "
            "WHERE (floor_number IS NULL OR room_id IS NULL) "
            "  AND lower(location) = ?",
            (f_num, room_id, needle),
        )

    ecols = [r[1] for r in conn.execute("PRAGMA table_info(equipment)").fetchall()]
    if "building" not in ecols:
        conn.execute("ALTER TABLE equipment ADD COLUMN building TEXT DEFAULT NULL")
    if "floor_number" not in ecols:
        conn.execute("ALTER TABLE equipment ADD COLUMN floor_number INTEGER DEFAULT NULL")
    if "room_id" not in ecols:
        conn.execute("ALTER TABLE equipment ADD COLUMN room_id INTEGER DEFAULT NULL REFERENCES rooms(id)")

    # Backfill building for equipment inserted before _extract_building existed
    conn.execute("""
        UPDATE equipment
        SET building = CASE
            WHEN lower(location) LIKE '%block a%' OR lower(location) LIKE '%block-a%' OR lower(location) LIKE '%block a-%' OR lower(location) LIKE '%-block a%' THEN 'A'
            WHEN lower(location) LIKE '%block b%' OR lower(location) LIKE '%block-b%' OR lower(location) LIKE '%block b-%' OR lower(location) LIKE '%-block b%' THEN 'B'
            WHEN lower(location) LIKE '%block c%' OR lower(location) LIKE '%block-c%' OR lower(location) LIKE '%block c-%' OR lower(location) LIKE '%-block c%' THEN 'C'
            ELSE building
        END
        WHERE building IS NULL
    """)

    # Backfill floor_number + room_id from catalog best-fit map (idempotent)
    from campus_catalog import EQUIPMENT_LOCATION_BACKFILL
    for needle, (b_code, f_num, r_name) in EQUIPMENT_LOCATION_BACKFILL.items():
        room_row = conn.execute(
            "SELECT id FROM rooms WHERE building_code=? AND floor_number=? AND name=?",
            (b_code, f_num, r_name),
        ).fetchone()
        if not room_row:
            continue
        room_id = room_row["id"] if isinstance(room_row, sqlite3.Row) else room_row[0]
        conn.execute(
            "UPDATE equipment SET floor_number=?, room_id=? "
            "WHERE (floor_number IS NULL OR room_id IS NULL) "
            "  AND lower(location) = ?",
            (f_num, room_id, needle),
        )

    # Audit log table
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            username TEXT NOT NULL DEFAULT 'system',
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT,
            details TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log(timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity_type, entity_id);
    """)

    # Developer profile (per-developer; one row per Developer user)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS developer_profile (
            user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
            full_name TEXT NOT NULL DEFAULT '',
            title TEXT NOT NULL DEFAULT '',
            role_label TEXT NOT NULL DEFAULT '',
            bio TEXT NOT NULL DEFAULT '',
            avatar_initials TEXT NOT NULL DEFAULT '',
            accent_color TEXT NOT NULL DEFAULT 'primary',
            updated_at TEXT
        );
    """)
    # Idempotent column adds for fields added after initial schema
    devcols = [r[1] for r in conn.execute("PRAGMA table_info(developer_profile)").fetchall()]
    # Add new contact fields (phone_number + viber_number + email)
    for col, default in [
        ("skills", "''"),
        ("phone_number", "''"),
        ("viber_number", "''"),
        ("email", "''"),
    ]:
        if col not in devcols:
            conn.execute(f"ALTER TABLE developer_profile ADD COLUMN {col} TEXT NOT NULL DEFAULT {default}")
    # Drop the 3 old contact URL fields (SQLite >= 3.35 supports DROP COLUMN)
    for col in ("github_url", "portfolio_url", "linkedin_url"):
        if col in devcols:
            try:
                conn.execute(f"ALTER TABLE developer_profile DROP COLUMN {col}")
            except Exception:
                # Old SQLite without DROP COLUMN support — silently keep the column.
                # Code paths no longer reference it; data is harmlessly ignored.
                pass

    # App About (singleton row; editable by Developer role)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS app_about (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            tagline TEXT NOT NULL DEFAULT '',
            description TEXT NOT NULL DEFAULT '',
            updated_by TEXT,
            updated_at TEXT
        );
    """)
    if not conn.execute("SELECT 1 FROM app_about WHERE id = 1").fetchone():
        conn.execute(
            "INSERT INTO app_about (id, tagline, description, updated_by, updated_at) "
            "VALUES (1, ?, ?, NULL, NULL)",
            (
                "Information about the development team and the web stack",
                "Smart Campus Monitoring System is a Flask + SQLite application "
                "designed to collect, visualize, and manage IoT telemetry for campus facilities.",
            ),
        )

    conn.commit()
    conn.close()


def hash_pw(pw: str) -> bytes:
    return bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt(rounds=12))


# Real action names emitted by all API endpoints (RBAC-validated).
# _audit_log() rejects any action not in this set — prevents fabricated entries
# from being inserted directly into the DB.
_KNOWN_AUDIT_ACTIONS = {
    # Equipment
    "add_equipment", "update_equipment", "delete_equipment",
    "change_equipment_status",
    # Devices
    "register_device", "delete_device", "update_device",
    "change_device_interval", "change_device_type", "toggle_device",
    # Sensor types
    "toggle_sensor_type",
    # Telemetry
    "inject_reading",
    # Tickets
    "create_ticket", "change_ticket_status",
    # Users
    "add_user", "update_user", "delete_user",
    "reset_password", "approve_user", "reject_user",
    # Auth (reserved for future)
    "login", "logout",
    # Developer profile
    "update_developer_profile",
    # App About
    "update_app_about",
}


def _audit_log(action, entity_type, entity_id=None, details=None, username=None):
    """Record an audit log entry. Never raises — audit must not block business logic."""
    try:
        import json as _json
        import sys as _sys
        if action not in _KNOWN_AUDIT_ACTIONS:
            # Fabricated / unknown action name detected — refuse to insert.
            # This protects against future scripts that bypass real API endpoints.
            print(
                "[AUDIT WARNING] Refusing to log unknown action: %r "
                "(entity_type=%r, entity_id=%r, username=%r)"
                % (action, entity_type, entity_id, username or session.get("username")),
                file=_sys.stderr,
            )
            return
        uname = username or session.get("username") or "system"
        details_str = _json.dumps(details, default=str) if details else None
        conn = get_db()
        conn.execute(
            "INSERT INTO audit_log (username, action, entity_type, entity_id, details) "
            "VALUES (?, ?, ?, ?, ?)",
            (uname, action, entity_type,
             str(entity_id) if entity_id is not None else None, details_str)
        )
        conn.commit()
        conn.close()
    except Exception:
        pass  # never let audit break the main flow


# Sensor type slug mapping for typed ingest endpoints
SENSOR_TYPE_SLUGS = {
    "temperature": "Temperature",
    "humidity": "Humidity",
    "air-quality": "Air Quality",
    "energy": "Energy",
    "co2": "CO2",
}

# Allowed update intervals for devices (in seconds)
ALLOWED_INTERVALS = [5, 10, 30, 60, 120, 300]
MIN_INTERVAL = 5
MAX_INTERVAL = 3600


def _validate_interval(value) -> tuple[bool, int | None, str]:
    """Returns (ok, interval_seconds, error_message)."""
    try:
        v = int(value)
    except (TypeError, ValueError):
        return False, None, "update_interval_seconds must be an integer."
    if v < MIN_INTERVAL:
        return False, None, f"update_interval_seconds must be at least {MIN_INTERVAL}s."
    if v > MAX_INTERVAL:
        return False, None, f"update_interval_seconds must be at most {MAX_INTERVAL}s."
    return True, v, ""


def _extract_building(location: str) -> str | None:
    """Returns 'A'/'B'/'C' if location mentions Block X, else None."""
    if not location:
        return None
    low = location.lower()
    for code in ("A", "B", "C"):
        if f"block {code.lower()}" in low or f"block-{code.lower()}" in low:
            return code
    return None


def _get_buildings() -> list[dict]:
    conn = get_db()
    rows = conn.execute("SELECT code, name, floors FROM buildings ORDER BY code").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _get_floors_for_building(code: str) -> list[dict]:
    conn = get_db()
    rows = conn.execute(
        "SELECT floor_number, label FROM floors WHERE building_code=? ORDER BY floor_number",
        (code,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _get_rooms_for_floor(code: str, floor_number: int) -> list[dict]:
    conn = get_db()
    rows = conn.execute(
        "SELECT id, name FROM rooms WHERE building_code=? AND floor_number=? ORDER BY name",
        (code, floor_number),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _get_room(room_id: int):
    conn = get_db()
    row = conn.execute(
        "SELECT rooms.id, rooms.building_code, rooms.floor_number, rooms.name, "
        "       buildings.name AS building_name, floors.label AS floor_label "
        "FROM rooms "
        "JOIN buildings ON buildings.code = rooms.building_code "
        "JOIN floors ON floors.building_code = rooms.building_code "
        "             AND floors.floor_number = rooms.floor_number "
        "WHERE rooms.id = ?",
        (room_id,),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def _get_floors_by_building() -> dict:
    """Returns {code: [{floor_number, label}, ...], ...}"""
    conn = get_db()
    out = {}
    for r in conn.execute(
        "SELECT building_code, floor_number, label FROM floors ORDER BY building_code, floor_number"
    ).fetchall():
        out.setdefault(r["building_code"], []).append(
            {"floor_number": r["floor_number"], "label": r["label"]}
        )
    conn.close()
    return out


def _get_rooms_by_floor() -> dict:
    """Returns {(code, floor_number): [{id, name}, ...], ...}"""
    conn = get_db()
    out = {}
    for r in conn.execute(
        "SELECT building_code, floor_number, id, name FROM rooms ORDER BY building_code, floor_number, name"
    ).fetchall():
        out.setdefault((r["building_code"], r["floor_number"]), []).append(
            {"id": r["id"], "name": r["name"]}
        )
    conn.close()
    return out


def verify_pw(pw: str, hashed: bytes) -> bool:
    try:
        return bcrypt.checkpw(pw.encode("utf-8"), hashed)
    except Exception:
        return False


COMMON_PASSWORDS = {
    "password", "password1", "password123", "qwerty", "qwerty123", "12345678",
    "123456789", "letmein", "welcome", "admin", "admin123", "iloveyou", "monkey",
    "dragon", "baseball", "football", "sunshine", "princess", "trustno1", "abc123",
    "111111", "123123", "000000", "654321", "superman", "batman", "starwars",
    "passw0rd", "master", "hello", "charlie", "asdf1234", "qwer1234", "zxcvbnm",
}


def validate_password(pw: str, username: str = "") -> tuple[bool, str]:
    """Moderate policy: min 8 chars + upper + lower + digit; block common; block username."""
    if not pw or len(pw) < 8:
        return False, "Password must be at least 8 characters."
    if len(pw) > 128:
        return False, "Password too long (max 128 chars)."
    if not any(c.isupper() for c in pw):
        return False, "Password must contain at least one uppercase letter."
    if not any(c.islower() for c in pw):
        return False, "Password must contain at least one lowercase letter."
    if not any(c.isdigit() for c in pw):
        return False, "Password must contain at least one digit."
    if pw.lower() in COMMON_PASSWORDS:
        return False, "That password is too common. Choose a stronger one."
    if username and pw.lower() == username.lower():
        return False, "Password cannot equal your username."
    return True, ""


def last_admin_guard(conn, exclude_user_id=None):
    """Returns True if operation is allowed (i.e., another active admin remains)."""
    if exclude_user_id is None:
        n = conn.execute(
            "SELECT COUNT(*) c FROM users WHERE role='Admin' AND is_active=1"
        ).fetchone()["c"]
    else:
        n = conn.execute(
            "SELECT COUNT(*) c FROM users WHERE role='Admin' AND is_active=1 AND id != ?",
            (exclude_user_id,),
        ).fetchone()["c"]
    return n >= 1


def password_strength_score(pw: str) -> int:
    """Returns 0-100 score for live strength meter."""
    if not pw:
        return 0
    score = 0
    if len(pw) >= 8:
        score += 20
    if len(pw) >= 12:
        score += 10
    if any(c.isupper() for c in pw):
        score += 15
    if any(c.islower() for c in pw):
        score += 15
    if any(c.isdigit() for c in pw):
        score += 15
    if any(not c.isalnum() for c in pw):
        score += 15
    if pw.lower() in COMMON_PASSWORDS:
        score = max(0, score - 60)
    if len(set(pw)) >= 8:
        score += 10
    return min(100, score)


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please sign in to continue.", "warning")
            return redirect(url_for("login"))
        conn = get_db()
        row = conn.execute(
            "SELECT is_active, must_change_password, status FROM users WHERE id = ?",
            (session["user_id"],),
        ).fetchone()
        conn.close()
        if not row or not row["is_active"]:
            session.clear()
            if row and row.get("status") == "pending":
                flash("Account pending approval. Contact an administrator.", "warning")
            else:
                flash("Account deactivated. Contact an administrator.", "danger")
            return redirect(url_for("login"))
        return f(*args, **kwargs)

    return wrapper


def role_required(*roles):
    def deco(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("Access denied: insufficient privileges.", "danger")
                return redirect(url_for("dashboard"))
            return f(*args, **kwargs)

        return wrapper

    return deco


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please sign in to continue.", "warning")
            return redirect(url_for("login"))
        if session.get("role") != "Admin":
            flash("Admin privileges required.", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)

    return wrapper


def developer_required(f):
    """Requires the logged-in user to have role='Developer'. Returns 403 if not."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"ok": False, "message": "Authentication required."}), 401
        if session.get("role") != "Developer":
            return jsonify({"ok": False, "message": "Developer privileges required."}), 403
        return f(*args, **kwargs)
    return wrapper


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.args.get("approved") == "1":
        flash("Your account has been approved! You can now sign in.", "success")
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        conn = get_db()
        row = conn.execute("SELECT * FROM users WHERE username = ?", (u,)).fetchone()
        if not row:
            conn.close()
            flash("Invalid credentials.", "danger")
            return render_template("login.html")
        if not row["is_active"]:
            conn.close()
            status_val = row["status"] if "status" in row.keys() else None
            if status_val == "pending":
                flash("Your account is pending admin approval. Please contact an administrator.", "warning")
            elif status_val == "rejected":
                return redirect(url_for("signup_rejected", username=row["username"]))
            else:
                flash("Account is deactivated. Contact an administrator.", "danger")
            return render_template("login.html")
        if not verify_pw(p, row["password_hash"]):
            conn.close()
            flash("Invalid credentials.", "danger")
            return render_template("login.html")
        session["user_id"] = row["id"]
        session["username"] = row["username"]
        session["role"] = row["role"]
        session["full_name"] = row["full_name"]
        conn.close()
        flash(f"Welcome back, {row['full_name']}!", "success")
        if row["must_change_password"]:
            flash("Please change your password to continue.", "warning")
            return redirect(url_for("profile"))
        return redirect(url_for("dashboard"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Signed out successfully.", "info")
    return redirect(url_for("login"))


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip().lower()
        full_name = (request.form.get("full_name") or "").strip()
        email = (request.form.get("email") or "").strip()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""

        if not username or len(username) > 60 or not all(c.isalnum() or c in "._" for c in username):
            flash("Username must be alphanumeric (._ allowed), max 60 chars.", "danger")
            return render_template("signup.html", username=username, full_name=full_name, email=email)

        if not full_name or len(full_name) > 120:
            flash("Full name is required (max 120 chars).", "danger")
            return render_template("signup.html", username=username, full_name=full_name, email=email)

        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("signup.html", username=username, full_name=full_name, email=email)

        ok, msg = validate_password(password, username=username)
        if not ok:
            flash(msg, "danger")
            return render_template("signup.html", username=username, full_name=full_name, email=email)

        conn = get_db()
        exists = conn.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone()
        if exists:
            conn.close()
            flash(f"Username '{username}' already exists.", "danger")
            return render_template("signup.html", username=username, full_name=full_name, email=email)

        conn.execute(
            "INSERT INTO users (username, password_hash, role, full_name, status, is_active, must_change_password) "
            "VALUES (?, ?, 'User', ?, 'pending', 0, 0)",
            (username, hash_pw(password), full_name),
        )
        conn.commit()
        conn.close()
        return redirect(url_for("pending_approval", username=username))
    return render_template("signup.html")


@app.route("/pending-approval")
def pending_approval():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    username = request.args.get("username", "")
    return render_template("pending.html", username=username)


@app.route("/signup-rejected")
def signup_rejected():
    username = request.args.get("username", "").strip()
    return render_template("signup_rejected.html", username=username)


@app.route("/api/check-approval")
def api_check_approval():
    username = request.args.get("username", "").strip().lower()
    if not username:
        return jsonify({"approved": False}), 400
    conn = get_db()
    row = conn.execute(
        "SELECT status, is_active FROM users WHERE username = ?", (username,)
    ).fetchone()
    conn.close()
    if not row:
        return jsonify({"approved": False, "reason": "not_found"}), 404
    if row["status"] == "rejected":
        return jsonify({"approved": False, "reason": "rejected"}), 403
    return jsonify({"approved": row["status"] == "active" and bool(row["is_active"])})


@app.route("/")
@login_required
def dashboard():
    conn = get_db()
    stats = {
        "equipment_total": conn.execute("SELECT COUNT(*) c FROM equipment").fetchone()[
            "c"
        ],
        "active_alerts": conn.execute(
            "SELECT COUNT(*) c FROM equipment WHERE status != 'Operational'"
        ).fetchone()["c"],
        "open_tickets": conn.execute(
            "SELECT COUNT(*) c FROM maintenance_tickets WHERE status IN ('Pending','In Progress')"
        ).fetchone()["c"],
    }
    recent = conn.execute("""
        SELECT t.id, t.title, t.priority, t.status, t.created_at, u.full_name
        FROM maintenance_tickets t JOIN users u ON u.id = t.user_id
        ORDER BY t.id DESC LIMIT 5
    """).fetchall()
    by_building = {}
    for r in conn.execute("SELECT building, COUNT(*) c FROM equipment GROUP BY building").fetchall():
        by_building[r["building"] or "Unassigned"] = r["c"]
    by_building_devices = {}
    for r in conn.execute("SELECT building, COUNT(*) c FROM devices GROUP BY building").fetchall():
        by_building_devices[r["building"] or "Unassigned"] = r["c"]
    pending_users_count = conn.execute(
        "SELECT COUNT(*) c FROM users WHERE status = 'pending'"
    ).fetchone()["c"] if session.get("role") == "Admin" else 0
    is_admin = (session.get("role") == "Admin")
    enabled_types = set(_get_enabled_sensors())
    devices = conn.execute("""
        SELECT id, sensor_id, sensor_type, location, display_name, building,
               last_value, last_unit, last_seen
        FROM devices
        WHERE enabled = 1 AND sensor_type IN ({})
        ORDER BY building NULLS LAST, location, sensor_type, sensor_id
    """.format(",".join("?" for _ in enabled_types)), tuple(enabled_types)).fetchall()
    devices = [dict(d) for d in devices]
    block_map = {
        "A": "Temperature",
        "B": "Air Quality",
        "C": "Energy",
    }
    dashboard_representative = {}
    for code, stype in block_map.items():
        row = conn.execute("""
            SELECT id, sensor_id, sensor_type, location, display_name, building,
                   last_value, last_unit
            FROM devices
            WHERE enabled = 1 AND building = ? AND sensor_type = ?
            ORDER BY id LIMIT 1
        """, (code, stype)).fetchone()
        if row:
            dashboard_representative[code] = dict(row)
    has_simulator = conn.execute(
        "SELECT 1 FROM telemetry WHERE (sensor_id IS NULL OR sensor_id = '') "
        "AND source = 'simulator' LIMIT 1"
    ).fetchone() is not None
    conn.close()
    return render_template(
        "dashboard.html",
        stats=stats,
        recent=recent,
        buildings=_get_buildings(),
        by_building=by_building,
        by_building_devices=by_building_devices,
        pending_users_count=pending_users_count,
        is_admin=is_admin,
        devices=devices,
        dashboard_representative=dashboard_representative,
        has_simulator=has_simulator,
    )


@app.route("/telemetry")
@login_required
def telemetry():
    conn = get_db()
    enabled_types = set(_get_enabled_sensors())
    devices = conn.execute("""
        SELECT id, sensor_id, sensor_type, location, display_name, building,
               last_value, last_unit, last_seen
        FROM devices
        WHERE enabled = 1 AND sensor_type IN ({})
        ORDER BY building NULLS LAST, location, sensor_type, sensor_id
    """.format(",".join("?" for _ in enabled_types)), tuple(enabled_types)).fetchall()
    devices = [dict(d) for d in devices]

    has_simulator = conn.execute(
        "SELECT 1 FROM telemetry WHERE (sensor_id IS NULL OR sensor_id = '') "
        "AND source = 'simulator' LIMIT 1"
    ).fetchone() is not None
    conn.close()

    return render_template(
        "telemetry.html",
        devices=devices,
        enabled_types=enabled_types,
        has_simulator=has_simulator,
        buildings=_get_buildings(),
    )


@app.route("/equipment")
@login_required
def equipment():
    conn = get_db()
    items = conn.execute("SELECT * FROM equipment ORDER BY building NULLS LAST, id").fetchall()

    total_assets = len(items)
    active_outages = conn.execute(
        "SELECT COUNT(*) c FROM equipment WHERE status='Offline'"
    ).fetchone()["c"]
    operational = conn.execute(
        "SELECT COUNT(*) c FROM equipment WHERE status='Operational'"
    ).fetchone()["c"]
    pending_tickets = conn.execute(
        "SELECT COUNT(*) c FROM maintenance_tickets WHERE status='Pending'"
    ).fetchone()["c"]
    maintenance_required = conn.execute(
        "SELECT COUNT(*) c FROM equipment WHERE status='Maintenance Required'"
    ).fetchone()["c"]
    op_score = (
        round((operational / total_assets) * 100, 1) if total_assets else 0.0
    )

    by_building = {}
    for r in conn.execute("SELECT building, COUNT(*) c FROM equipment GROUP BY building").fetchall():
        by_building[r["building"] or "Unassigned"] = r["c"]

    kpis = {
        "total_assets": total_assets,
        "active_outages": active_outages,
        "pending_tickets": pending_tickets,
        "maintenance_required": maintenance_required,
        "operational_score": op_score,
    }
    conn.close()
    return render_template(
        "equipment.html",
        items=items,
        kpis=kpis,
        is_admin=session.get("role") == "Admin",
        buildings=_get_buildings(),
        floors_by_building=_get_floors_by_building(),
        rooms_by_floor=_get_rooms_by_floor(),
        by_building=by_building,
    )


VALID_CATEGORIES = ("HVAC", "Lighting", "Security", "Plumbing", "Electrical", "Other")


def _validate_equipment_payload(payload):
    """Returns (cleaned_dict, error_response_or_None).

    Accepts either:
    - structured: building_code + floor_number + room_id  (preferred, current UI)
    - legacy: free-text location  (only honored if no structured fields supplied,
      for backward compat with any external callers)
    """
    name = (payload.get("name") or "").strip()
    category = (payload.get("category") or "Other").strip()
    status = (payload.get("status") or "Operational").strip()
    last_inspected = (payload.get("last_inspected") or "").strip()

    building_code = (payload.get("building_code") or "").strip()
    floor_number_raw = payload.get("floor_number")
    room_id_raw = payload.get("room_id")
    location_in = (payload.get("location") or "").strip()

    if not name or len(name) > 120:
        return None, (jsonify({"ok": False, "type": "danger",
                               "message": "Name is required (max 120 chars)."}), 400)
    if category not in VALID_CATEGORIES:
        return None, (jsonify({"ok": False, "type": "danger",
                               "message": "Invalid category."}), 400)
    if status not in ("Operational", "Maintenance Required", "Offline"):
        return None, (jsonify({"ok": False, "type": "danger",
                               "message": "Invalid status value."}), 400)

    use_structured = bool(building_code or floor_number_raw is not None or room_id_raw)
    if use_structured:
        if not building_code:
            return None, (jsonify({"ok": False, "type": "danger",
                                   "message": "Building is required."}), 400)
        try:
            floor_number = int(floor_number_raw)
        except (TypeError, ValueError):
            return None, (jsonify({"ok": False, "type": "danger",
                                   "message": "Floor is required."}), 400)
        try:
            room_id = int(room_id_raw)
        except (TypeError, ValueError):
            return None, (jsonify({"ok": False, "type": "danger",
                                   "message": "Room is required."}), 400)

        room = _get_room(room_id)
        if not room or room["building_code"] != building_code or room["floor_number"] != floor_number:
            return None, (jsonify({"ok": False, "type": "danger",
                                   "message": "Selected room does not exist in the chosen building/floor."}), 400)
        location = f"{room['building_name']} - {room['floor_label']} - {room['name']}"
        building = room["building_code"]
        floor_number_out = floor_number
        room_id_out = room["id"]
    else:
        # Legacy free-text fallback
        if not location_in or len(location_in) > 120:
            return None, (jsonify({"ok": False, "type": "danger",
                                   "message": "Location is required (max 120 chars)."}), 400)
        location = location_in
        building = _extract_building(location)
        floor_number_out = None
        room_id_out = None

    if not last_inspected:
        last_inspected = datetime.utcnow().strftime("%Y-%m-%d")
    return {
        "name": name,
        "location": location,
        "category": category,
        "status": status,
        "last_inspected": last_inspected,
        "building": building,
        "floor_number": floor_number_out,
        "room_id": room_id_out,
    }, None


def _validate_register_device_payload(payload):
    """Validates a device registration/update payload.

    Accepts either structured (building_code + floor_number + room_id + location_detail)
    or legacy free-text location for backward compat. Returns
    (cleaned_dict, error_response_or_None).
    """
    building_code = (payload.get("building_code") or "").strip()
    floor_number_raw = payload.get("floor_number")
    room_id_raw = payload.get("room_id")
    location_detail = (payload.get("location_detail") or "").strip()[:64]
    location_in = (payload.get("location") or "").strip()[:128]

    use_structured = bool(building_code or floor_number_raw is not None or room_id_raw)
    if use_structured:
        if not building_code:
            return None, (jsonify({"ok": False, "message": "Building is required."}), 400)
        try:
            floor_number = int(floor_number_raw)
        except (TypeError, ValueError):
            return None, (jsonify({"ok": False, "message": "Floor is required."}), 400)
        try:
            room_id = int(room_id_raw)
        except (TypeError, ValueError):
            return None, (jsonify({"ok": False, "message": "Room is required."}), 400)
        room = _get_room(room_id)
        if not room or room["building_code"] != building_code or room["floor_number"] != floor_number:
            return None, (jsonify({"ok": False,
                                   "message": "Selected room does not exist in the chosen building/floor."}), 400)
        location = f"{room['building_name']} - {room['floor_label']} - {room['name']}"
        if location_detail:
            location += f", {location_detail}"
        building = room["building_code"]
        floor_number_out = floor_number
        room_id_out = room["id"]
    else:
        if not location_in:
            return None, (jsonify({"ok": False, "message": "Location is required."}), 400)
        location = location_in
        building = _extract_building(location)
        floor_number_out = None
        room_id_out = None
    return {
        "location": location,
        "location_detail": location_detail if use_structured else None,
        "building": building,
        "floor_number": floor_number_out,
        "room_id": room_id_out,
    }, None


@app.route("/api/equipment", methods=["POST"])
@admin_required
def api_equipment_create():
    payload = request.get_json(silent=True) or request.form
    cleaned, err = _validate_equipment_payload(payload)
    if err:
        return err
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO equipment (name, location, category, status, last_inspected, building, floor_number, room_id) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (cleaned["name"], cleaned["location"], cleaned["category"],
         cleaned["status"], cleaned["last_inspected"], cleaned["building"],
         cleaned["floor_number"], cleaned["room_id"]),
    )
    new_id = cur.lastrowid
    conn.commit()
    conn.close()
    _audit_log("add_equipment", "equipment", new_id,
               {"name": cleaned["name"], "location": cleaned["location"],
                "category": cleaned["category"], "status": cleaned["status"]})
    return jsonify({
        "ok": True,
        "type": "success",
        "message": f"Equipment '{cleaned['name']}' added successfully.",
        "equipment": {"id": new_id, **cleaned},
    })


@app.route("/api/equipment/<int:eid>", methods=["PUT"])
@admin_required
def api_equipment_update(eid):
    payload = request.get_json(silent=True) or {}
    cleaned, err = _validate_equipment_payload(payload)
    if err:
        return err
    conn = get_db()
    row = conn.execute("SELECT name FROM equipment WHERE id = ?", (eid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "Equipment not found."}), 404
    conn.execute(
        "UPDATE equipment SET name=?, location=?, category=?, status=?, last_inspected=?, "
        "building=?, floor_number=?, room_id=? WHERE id=?",
        (cleaned["name"], cleaned["location"], cleaned["category"],
         cleaned["status"], cleaned["last_inspected"], cleaned["building"],
         cleaned["floor_number"], cleaned["room_id"], eid),
    )
    conn.commit()
    conn.close()
    _audit_log("update_equipment", "equipment", eid,
               {"name": cleaned["name"], "location": cleaned["location"],
                "category": cleaned["category"], "status": cleaned["status"]})
    return jsonify({
        "ok": True,
        "type": "success",
        "message": f"Equipment #{eid} ('{row['name']}') updated.",
        "equipment": {"id": eid, **cleaned},
    })


@app.route("/api/equipment/<int:eid>", methods=["DELETE"])
@admin_required
def api_equipment_delete(eid):
    conn = get_db()
    row = conn.execute("SELECT name FROM equipment WHERE id = ?", (eid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "Equipment not found."}), 404
    linked = conn.execute(
        "SELECT COUNT(*) c FROM maintenance_tickets WHERE equipment_id = ?", (eid,)
    ).fetchone()["c"]
    if linked > 0:
        conn.close()
        return jsonify({
            "ok": False,
            "type": "danger",
            "message": f"Cannot delete: {linked} ticket(s) reference this equipment. Resolve them first.",
        }), 409
    conn.execute("DELETE FROM equipment WHERE id = ?", (eid,))
    conn.commit()
    conn.close()
    _audit_log("delete_equipment", "equipment", eid, {"name": row["name"]})
    return jsonify({
        "ok": True,
        "type": "success",
        "message": f"Equipment '{row['name']}' deleted.",
    })


@app.route("/maintenance")
@login_required
def maintenance():
    conn = get_db()
    tickets = conn.execute("""
        SELECT t.*, u.full_name,
               e.name AS eq_name, e.location AS eq_location,
               e.category AS eq_category, e.status AS eq_status
        FROM maintenance_tickets t
        JOIN users u ON u.id = t.user_id
        LEFT JOIN equipment e ON e.id = t.equipment_id
        ORDER BY t.id DESC
    """).fetchall()
    equipments = conn.execute("""
        SELECT id, name, location, category, status FROM equipment ORDER BY name
    """).fetchall()
    counts = {
        "pending": conn.execute(
            "SELECT COUNT(*) c FROM maintenance_tickets WHERE status='Pending'"
        ).fetchone()["c"],
        "in_progress": conn.execute(
            "SELECT COUNT(*) c FROM maintenance_tickets WHERE status='In Progress'"
        ).fetchone()["c"],
        "resolved": conn.execute(
            "SELECT COUNT(*) c FROM maintenance_tickets WHERE status='Resolved'"
        ).fetchone()["c"],
        "rejected": conn.execute(
            "SELECT COUNT(*) c FROM maintenance_tickets WHERE status='Rejected'"
        ).fetchone()["c"],
    }
    conn.close()
    return render_template(
        "maintenance.html",
        tickets=tickets,
        counts=counts,
        equipments=equipments,
        is_admin=session.get("role") == "Admin",
    )


@app.route("/developer")
@login_required
def developer():
    """Developer profile page. Visible to all logged-in users.

    Each user with role='Developer' has their own `developer_profile` row.
    Any developer can edit their own profile via /api/developer/profile/me.
    The /developer page shows one card per developer.
    """
    conn = get_db()
    # Auto-create profile rows for any developer users that don't have one yet
    devs_without_profile = conn.execute(
        "SELECT u.id, u.full_name FROM users u "
        "LEFT JOIN developer_profile dp ON dp.user_id = u.id "
        "WHERE u.role = 'Developer' AND u.is_active = 1 AND dp.user_id IS NULL"
    ).fetchall()
    now_iso = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    for row in devs_without_profile:
        initials = "".join(part[0] for part in (row["full_name"] or "Dev").split()[:3]).upper()[:3] or "DV"
        conn.execute(
            "INSERT INTO developer_profile (user_id, full_name, title, role_label, bio, "
            "avatar_initials, accent_color, updated_at) "
            "VALUES (?, ?, '', '', '', ?, 'primary', ?)",
            (row["id"], row["full_name"], initials, now_iso),
        )
    conn.commit()

    # Fetch all developer profiles with their user info
    profiles_rows = conn.execute(
        "SELECT dp.user_id, dp.full_name, dp.title, dp.role_label, dp.bio, "
        "       dp.avatar_initials, dp.accent_color, dp.updated_at, "
        "       dp.skills, dp.phone_number, dp.viber_number, dp.email, "
        "       u.username, u.is_active, u.status "
        "FROM developer_profile dp "
        "JOIN users u ON u.id = dp.user_id "
        "WHERE u.role = 'Developer' AND u.is_active = 1 "
        "ORDER BY u.id"
    ).fetchall()
    profiles = [dict(r) for r in profiles_rows]

    # Fetch app_about (singleton)
    app_about_row = conn.execute(
        "SELECT tagline, description, updated_by, updated_at FROM app_about WHERE id = 1"
    ).fetchone()
    app_about = dict(app_about_row) if app_about_row else {
        "tagline": "Information about the development team and the web stack",
        "description": "Smart Campus Monitoring System is a Flask + SQLite application "
                       "designed to collect, visualize, and manage IoT telemetry for campus facilities.",
        "updated_by": None,
        "updated_at": None,
    }

    conn.close()

    # Pass skills catalog for the multi-select dropdown
    from campus_catalog import SKILLS_CATALOG

    return render_template(
        "developer.html",
        build_version="1.1.0",
        stack=[
            "Python 3.12",
            "Flask 3.0",
            "SQLite 3",
            "Bootstrap 5.3",
            "Chart.js 4.4",
            "bcrypt 4.2",
        ],
        profiles=profiles,
        app_about=app_about,
        skills_catalog=SKILLS_CATALOG,
        current_user_id=session.get("user_id"),
        current_user_role=session.get("role"),
    )


VALID_ACCENT_COLORS = ("primary", "info", "success", "warning", "danger", "secondary")


def _validate_url(url):
    """Return the URL trimmed to <=200 chars, or empty string if not a valid http(s) URL.
    Empty input is allowed (optional field)."""
    if not url:
        return ""
    url = url.strip()[:200]
    if not url:
        return ""
    if not (url.startswith("http://") or url.startswith("https://")):
        return ""  # silently reject — frontend will still submit; backend treats as empty
    return url


def _ensure_dev_profile_row(user_id, full_name):
    """Make sure a `developer_profile` row exists for this developer user.
    Returns the row as a dict."""
    conn = get_db()
    row = conn.execute("SELECT * FROM developer_profile WHERE user_id = ?", (user_id,)).fetchone()
    if not row:
        initials = "".join(part[0] for part in (full_name or "Dev").split()[:3]).upper()[:3] or "DV"
        now_iso = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        conn.execute(
            "INSERT INTO developer_profile (user_id, full_name, title, role_label, bio, "
            "avatar_initials, accent_color, updated_at) "
            "VALUES (?, ?, '', '', '', ?, 'primary', ?)",
            (user_id, full_name, initials, now_iso),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM developer_profile WHERE user_id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


@app.route("/api/developer/profile/me", methods=["GET"])
@developer_required
def api_developer_profile_me_get():
    """Return the logged-in developer's editable profile."""
    user_id = session["user_id"]
    conn = get_db()
    user_row = conn.execute(
        "SELECT full_name, username FROM users WHERE id = ?", (user_id,)
    ).fetchone()
    conn.close()
    if not user_row:
        return jsonify({"ok": False, "message": "User not found."}), 404
    profile = _ensure_dev_profile_row(user_id, user_row["full_name"])
    # full_name in developer_profile tracks users.full_name; expose both
    profile["full_name"] = user_row["full_name"]
    return jsonify({"ok": True, "profile": profile})


@app.route("/api/developer/profile/me", methods=["PUT"])
@developer_required
def api_developer_profile_me_put():
    """Update the logged-in developer's profile.

    Body (all optional except full_name):
      full_name, title, role_label, bio, avatar_initials, accent_color,
      skills (comma-separated; must be from SKILLS_CATALOG),
      phone_number (used by SMS/Phone/Viber buttons),
      email (used by Email button)
    """
    from campus_catalog import SKILLS_CATALOG
    payload = request.get_json(silent=True) or {}
    full_name_in = (payload.get("full_name") or "").strip()[:120]
    title_in = (payload.get("title") or "").strip()[:120]
    role_label_in = (payload.get("role_label") or "").strip()[:120]
    bio_in = (payload.get("bio") or "").strip()[:500]
    initials_in = (payload.get("avatar_initials") or "").strip()[:3].upper()
    accent_in = (payload.get("accent_color") or "primary").strip().lower()
    skills_raw = (payload.get("skills") or "").strip()
    phone_in = (payload.get("phone_number") or "").strip()[:32]
    viber_in = (payload.get("viber_number") or "").strip()[:32]
    email_in = (payload.get("email") or "").strip()[:120]

    if not full_name_in:
        return jsonify({"ok": False, "message": "Full name is required."}), 400
    if accent_in not in VALID_ACCENT_COLORS:
        accent_in = "primary"

    # Validate skills against catalog
    skills_normalized = [s.strip() for s in skills_raw.split(",") if s.strip()]
    catalog_lower = {s.lower(): s for s in SKILLS_CATALOG}
    skills_clean = []
    for s in skills_normalized:
        canonical = catalog_lower.get(s.lower())
        if canonical and canonical not in skills_clean:
            skills_clean.append(canonical)
        elif not canonical:
            return jsonify({"ok": False,
                            "message": f"Unknown skill: '{s}'. Pick from the list."}), 400
    skills_in = ", ".join(skills_clean)[:500]

    # Validate phone numbers (digits, +, -, (, ), spaces; min 4)
    phone_re = r"^[\d+\-\(\)\s]{4,32}$"
    if phone_in and not re.match(phone_re, phone_in):
        return jsonify({"ok": False,
                        "message": "Phone number must contain digits and optional + - ( ) spaces."}), 400
    if viber_in and not re.match(phone_re, viber_in):
        return jsonify({"ok": False,
                        "message": "Viber number must contain digits and optional + - ( ) spaces."}), 400

    # Validate email (basic regex)
    if email_in and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email_in):
        return jsonify({"ok": False,
                        "message": "Email address is not valid."}), 400

    user_id = session["user_id"]
    conn = get_db()
    user_row = conn.execute("SELECT username, full_name FROM users WHERE id = ?", (user_id,)).fetchone()
    if not user_row:
        conn.close()
        return jsonify({"ok": False, "message": "User not found."}), 404

    # Make sure a profile row exists
    _ensure_dev_profile_row(user_id, user_row["full_name"])

    now_iso = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    conn.execute(
        "UPDATE developer_profile SET full_name=?, title=?, role_label=?, bio=?, "
        "avatar_initials=?, accent_color=?, skills=?, phone_number=?, viber_number=?, email=?, "
        "updated_at=? WHERE user_id=?",
        (full_name_in, title_in, role_label_in, bio_in, initials_in, accent_in,
         skills_in, phone_in, viber_in, email_in, now_iso, user_id),
    )
    # Also sync users.full_name so any "Hi, <full_name>" greeting stays current
    conn.execute("UPDATE users SET full_name=? WHERE id=?", (full_name_in, user_id))
    session["full_name"] = full_name_in
    conn.commit()
    conn.close()

    _audit_log("update_developer_profile", "developer_profile", user_id,
               {"username": user_row["username"], "full_name": full_name_in})

    return jsonify({
        "ok": True,
        "message": "Developer profile updated.",
        "profile": {
            "user_id": user_id,
            "full_name": full_name_in,
            "title": title_in,
            "role_label": role_label_in,
            "bio": bio_in,
            "avatar_initials": initials_in,
            "accent_color": accent_in,
            "skills": skills_in,
            "phone_number": phone_in,
            "viber_number": viber_in,
            "email": email_in,
            "updated_at": now_iso,
        }
    })


@app.route("/api/developer/app-about", methods=["GET"])
@login_required
def api_app_about_get():
    """Return the singleton app_about row. Auto-creates default if missing."""
    conn = get_db()
    row = conn.execute("SELECT tagline, description, updated_by, updated_at FROM app_about WHERE id = 1").fetchone()
    if not row:
        # Create with defaults
        conn.execute(
            "INSERT INTO app_about (id, tagline, description, updated_by, updated_at) "
            "VALUES (1, ?, ?, NULL, NULL)",
            (
                "Information about the development team and the web stack",
                "Smart Campus Monitoring System is a Flask + SQLite application "
                "designed to collect, visualize, and manage IoT telemetry for campus facilities.",
            ),
        )
        conn.commit()
        row = conn.execute("SELECT tagline, description, updated_by, updated_at FROM app_about WHERE id = 1").fetchone()
    conn.close()
    return jsonify({"ok": True, "app_about": dict(row)})


@app.route("/api/developer/app-about", methods=["PUT"])
@developer_required
def api_app_about_put():
    """Update the singleton app_about row.

    Body:
      tagline (optional, max 200 chars)
      description (required, max 1000 chars)
    """
    payload = request.get_json(silent=True) or {}
    tagline_in = (payload.get("tagline") or "").strip()[:200]
    description_in = (payload.get("description") or "").strip()[:1000]
    if not description_in:
        return jsonify({"ok": False, "message": "App description is required."}), 400

    user_id = session["user_id"]
    now_iso = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    username = session.get("username", "")
    conn = get_db()
    # Make sure the row exists
    if not conn.execute("SELECT 1 FROM app_about WHERE id = 1").fetchone():
        conn.execute(
            "INSERT INTO app_about (id, tagline, description, updated_by, updated_at) "
            "VALUES (1, ?, ?, ?, ?)",
            (tagline_in, description_in, username, now_iso),
        )
    else:
        conn.execute(
            "UPDATE app_about SET tagline=?, description=?, updated_by=?, updated_at=? WHERE id = 1",
            (tagline_in, description_in, username, now_iso),
        )
    conn.commit()
    conn.close()

    _audit_log("update_app_about", "app_about", 1,
               {"by": username, "tagline": tagline_in})

    return jsonify({
        "ok": True,
        "message": "App About description updated.",
        "app_about": {
            "id": 1,
            "tagline": tagline_in,
            "description": description_in,
            "updated_by": username,
            "updated_at": now_iso,
        }
    })


def _humanize_action(action: str, parsed: dict) -> tuple[str, str]:
    """Convert action code + parsed details into (human_summary, category).

    Only handles the real action names emitted by API endpoints (see
    _KNOWN_AUDIT_ACTIONS). Unknown actions fall back to a generic
    capitalized summary so the page never crashes.
    """
    name = ""
    if isinstance(parsed, dict):
        for k in ("name", "sensor_id", "username", "target_username", "sensor_type"):
            v = parsed.get(k)
            if v:
                name = str(v)
                break

    # Default fallback (used when action isn't mapped below).
    summary = action.replace("_", " ").capitalize() if action else "Unknown action"
    category = "System"

    # ---- Equipment ----
    if action == "add_equipment":
        summary = "Added equipment" + (": " + name if name else "")
        category = "Equipment"
    elif action == "update_equipment":
        summary = "Updated equipment" + (": " + name if name else "")
        category = "Equipment"
    elif action == "delete_equipment":
        summary = "Deleted equipment" + (": " + name if name else "")
        category = "Equipment"
    elif action == "change_equipment_status":
        new_status = parsed.get("new_status", "") if isinstance(parsed, dict) else ""
        summary = "Updated equipment status" + (" to " + str(new_status) if new_status else "")
        category = "Equipment"

    # ---- Devices ----
    elif action == "register_device":
        summary = "Registered device" + (": " + name if name else "")
        category = "Devices"
    elif action == "delete_device":
        summary = "Removed device" + (": " + name if name else "")
        category = "Devices"
    elif action == "update_device":
        summary = "Updated device" + (": " + name if name else "")
        category = "Devices"
    elif action == "change_device_interval":
        new_int = parsed.get("update_interval_seconds", "") if isinstance(parsed, dict) else ""
        summary = "Changed device update interval" + (" to " + str(new_int) + "s" if new_int else "")
        category = "Devices"
    elif action == "change_device_type":
        new_type = parsed.get("new_sensor_type", parsed.get("sensor_type", "")) if isinstance(parsed, dict) else ""
        summary = "Changed device type" + (" to " + str(new_type) if new_type else "")
        category = "Devices"
    elif action == "toggle_device":
        enabled = parsed.get("enabled", "") if isinstance(parsed, dict) else ""
        prefix = "Enabled" if enabled else "Disabled"
        summary = prefix + " device" + (": " + name if name else "")
        category = "Devices"

    # ---- Sensor types ----
    elif action == "toggle_sensor_type":
        enabled = parsed.get("enabled", "") if isinstance(parsed, dict) else ""
        prefix = "Enabled" if enabled else "Disabled"
        summary = prefix + " sensor type" + (": " + name if name else "")
        category = "Sensors"

    # ---- Telemetry ----
    elif action == "inject_reading":
        val = parsed.get("reading_value", "") if isinstance(parsed, dict) else ""
        summary = "Injected telemetry reading" + (" (" + str(val) + ")" if val != "" else "")
        category = "Telemetry"

    # ---- Tickets ----
    elif action == "create_ticket":
        summary = "Created maintenance ticket"
        category = "Tickets"
    elif action == "change_ticket_status":
        new_status = parsed.get("new_status", "") if isinstance(parsed, dict) else ""
        summary = "Updated ticket status" + (" to " + str(new_status) if new_status else "")
        category = "Tickets"

    # ---- Users ----
    elif action == "add_user":
        summary = "Created user" + (": " + name if name else "")
        category = "Users"
    elif action == "update_user":
        summary = "Updated user" + (": " + name if name else "")
        category = "Users"
    elif action == "delete_user":
        summary = "Deleted user" + (": " + name if name else "")
        category = "Users"
    elif action == "reset_password":
        summary = "Reset password" + (" for: " + name if name else "")
        category = "Users"
    elif action == "approve_user":
        summary = "Approved user signup" + (": " + name if name else "")
        category = "Users"
    elif action == "reject_user":
        summary = "Rejected user signup" + (": " + name if name else "")
        category = "Users"

    # ---- Developer profile ----
    elif action == "update_developer_profile":
        summary = "Updated developer profile" + (": " + name if name else "")
        category = "Developer"
    elif action == "update_app_about":
        summary = "Updated app About description"
        category = "System"

    # ---- Auth ----
    elif action == "login":
        summary = "Logged in"
        category = "Auth"
    elif action == "logout":
        summary = "Logged out"
        category = "Auth"

    return summary, category


_CATEGORY_BY_ENTITY = {
    "equipment": "Equipment",
    "device": "Devices",
    "user": "Users",
    "ticket": "Tickets",
    "sensor_type": "Sensors",
    "telemetry": "Telemetry",
}


@app.route("/audit")
@admin_required
def audit():
    """Audit Log Session: shows all system actions and changes (Admin only)."""
    conn = get_db()
    entity_filter = request.args.get("entity", "").strip()
    user_filter = request.args.get("user", "").strip()
    date_filter = request.args.get("date", "all").strip()
    q = request.args.get("q", "").strip()
    try:
        current_limit = int(request.args.get("limit", "100"))
    except (TypeError, ValueError):
        current_limit = 100
    current_limit = max(1, min(current_limit, 500))

    where = []
    params = []
    if entity_filter:
        where.append("entity_type = ?"); params.append(entity_filter)
    if user_filter:
        where.append("username = ?"); params.append(user_filter)
    if q:
        where.append("(username LIKE ? OR action LIKE ? OR entity_type LIKE ? OR entity_id LIKE ? OR details LIKE ?)")
        like = f"%{q}%"
        params.extend([like, like, like, like, like])
    if date_filter and date_filter != "all":
        days_map = {"24h": 1, "7d": 7, "30d": 30}
        days = days_map.get(date_filter)
        if days:
            from datetime import datetime, timedelta
            cutoff = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
            where.append("timestamp >= ?"); params.append(cutoff)

    where_sql = (" WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT * FROM audit_log{where_sql} ORDER BY timestamp DESC LIMIT ?",
        params + [current_limit],
    ).fetchall()
    logs = [dict(r) for r in rows]
    # Parse JSON details for template rendering
    import json as _json
    # Compute relative time (e.g. "2 min ago") for each log
    from datetime import datetime
    now = datetime.utcnow()
    for log in logs:
        raw = log.get("details")
        parsed = {}
        if raw:
            try:
                parsed = _json.loads(raw)
            except (TypeError, ValueError):
                parsed = {"_raw": raw}
        log["parsed_details"] = parsed
        ts_str = log.get("timestamp", "")
        try:
            ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
            delta = now - ts
            seconds = int(delta.total_seconds())
            if seconds < 0:
                log["relative"] = "just now"
            elif seconds < 60:
                log["relative"] = "%d sec ago" % seconds
            elif seconds < 3600:
                log["relative"] = "%d min ago" % (seconds // 60)
            elif seconds < 86400:
                log["relative"] = "%d hr ago" % (seconds // 3600)
            elif seconds < 604800:
                log["relative"] = "%d day%s ago" % (seconds // 86400, "" if seconds // 86400 == 1 else "s")
            else:
                log["relative"] = "%d week%s ago" % (seconds // 604800, "" if seconds // 604800 == 1 else "s")
        except (TypeError, ValueError):
            log["relative"] = ts_str

    # Build role lookup for usernames referenced in logs (for avatars)
    roles_map = {}
    for r in conn.execute("SELECT username, role FROM users").fetchall():
        roles_map[r["username"]] = r["role"]
    for log in logs:
        log["user_role"] = roles_map.get(log.get("username"), "User")
        # Build human-readable summary and category for the row
        summary, category = _humanize_action(log.get("action", ""), log.get("parsed_details") or {})
        log["summary"] = summary
        if category == "System":
            category = _CATEGORY_BY_ENTITY.get(log.get("entity_type", ""), "System")
        log["category"] = category

    counts = {
        "users": conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"],
        "equipment": conn.execute("SELECT COUNT(*) c FROM equipment").fetchone()["c"],
        "telemetry": conn.execute("SELECT COUNT(*) c FROM telemetry").fetchone()["c"],
        "tickets": conn.execute(
            "SELECT COUNT(*) c FROM maintenance_tickets"
        ).fetchone()["c"],
    }

    entity_types = [
        r["entity_type"] for r in
        conn.execute("SELECT DISTINCT entity_type FROM audit_log ORDER BY entity_type").fetchall()
    ]
    usernames = [
        r["username"] for r in
        conn.execute("SELECT DISTINCT username FROM audit_log ORDER BY username").fetchall()
    ]

    conn.close()
    return render_template(
        "audit.html",
        logs=logs, counts=counts,
        entity_types=entity_types, usernames=usernames,
        current_filter=entity_filter, current_user=user_filter,
        current_date=date_filter, current_q=q,
        current_limit=current_limit,
    )


@app.after_request
def disable_dev_caching(resp):
    # API + JS: always no-store (existing behavior)
    if request.path.endswith(".js") or "/api/" in request.path:
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
    # HTML pages: also no-store to prevent browser caching of stale data
    elif "text/html" in resp.headers.get("Content-Type", ""):
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
    # Vary on Cookie to prevent shared caches from serving wrong user's HTML
    existing_vary = resp.headers.get("Vary", "")
    if "Cookie" not in existing_vary:
        resp.headers["Vary"] = (existing_vary + ", Cookie").strip(", ")
    return resp


_telemetry_throttle = {}
_ingest_rate_limit = {}
_sse_subscribers = []
_sse_subscribers_lock = threading.Lock()


def _broadcast_reading(reading: dict):
    """Push a new reading to all SSE subscribers (non-blocking)."""
    _broadcast("reading", reading)


def _broadcast_event(event: dict):
    """Push a non-reading SSE event to all subscribers."""
    _broadcast("event", event)


def _broadcast(kind: str, payload: dict):
    """Push (kind, payload) to all SSE subscribers (non-blocking)."""
    with _sse_subscribers_lock:
        dead = []
        for q in _sse_subscribers:
            try:
                q.put_nowait((kind, payload))
            except queue.Full:
                dead.append(q)
        for q in dead:
            try:
                _sse_subscribers.remove(q)
            except ValueError:
                pass


def _verify_device_api_key(key: str) -> bool:
    """Constant-time comparison of device API key."""
    if not DEVICE_API_KEY or not key:
        return False
    return hmac.compare_digest(key, DEVICE_API_KEY)


def _is_sensor_enabled(sensor_type: str) -> bool:
    """Returns True if sensor is enabled (default: True if not in config)."""
    conn = get_db()
    row = conn.execute(
        "SELECT enabled FROM sensor_config WHERE sensor_type = ?", (sensor_type,)
    ).fetchone()
    conn.close()
    if row is None:
        return True
    return bool(row["enabled"])


def _get_enabled_sensors() -> list[str]:
    """Returns list of sensor_type strings that are enabled."""
    conn = get_db()
    rows = conn.execute(
        "SELECT sensor_type FROM sensor_config WHERE enabled = 1"
    ).fetchall()
    conn.close()
    return [r["sensor_type"] for r in rows]


def _is_device_enabled(sensor_id: str, sensor_type: str) -> bool:
    """Returns True if device row exists and is enabled."""
    conn = get_db()
    row = conn.execute(
        "SELECT enabled FROM devices WHERE sensor_id = ? AND sensor_type = ?",
        (sensor_id, sensor_type),
    ).fetchone()
    conn.close()
    return bool(row["enabled"]) if row else False


def _device_exists(sensor_id: str, sensor_type: str) -> bool:
    conn = get_db()
    row = conn.execute(
        "SELECT 1 FROM devices WHERE sensor_id = ? AND sensor_type = ?",
        (sensor_id, sensor_type),
    ).fetchone()
    conn.close()
    return row is not None


def _set_sensor_enabled(sensor_type: str, enabled: bool, by_user: str = ""):
    """Persists toggle state, records who + when."""
    conn = get_db()
    conn.execute(
        "UPDATE sensor_config SET enabled = ?, last_toggle_by = ?, last_toggle_at = ? WHERE sensor_type = ?",
        (1 if enabled else 0, by_user, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), sensor_type),
    )
    conn.commit()
    conn.close()


SENSOR_SPECS = [
    ("Temperature", "C", 22.0, 3.0),
    ("Humidity", "%", 55.0, 10.0),
    ("Air Quality", "AQI", 65.0, 20.0),
    ("Energy", "kW", 4.5, 1.2),
    ("CO2", "ppm", 650.0, 80.0),
]


def _run_simulator_tick():
    """Inserts one reading per enabled sensor type if 30s elapsed since last.
    Also generates readings for registered devices (respecting their
    update_interval_seconds) so devices show as Live.
    Shared by HTTP-triggered (/api/telemetry/latest) and background-thread paths.
    Uses its own DB connection for thread safety.
    """
    if SENSOR_MODE != "simulator":
        return
    now_dt = datetime.utcnow()
    conn = get_db()
    broadcast_payload = []
    try:
        enabled_types = set(_get_enabled_sensors())
        # 1) Ambient readings (one per sensor type) - unchanged from before
        for i, (s, unit, base, jitter) in enumerate(SENSOR_SPECS):
            if s not in enabled_types:
                continue
            sensor_now = now_dt + timedelta(seconds=i)
            last = _telemetry_throttle.get(s)
            if last is None or (sensor_now - last).total_seconds() >= 30:
                new_val = round(base + random.uniform(-jitter, jitter), 2)
                ts_str = sensor_now.strftime("%Y-%m-%d %H:%M:%S")
                cur = conn.execute(
                    "INSERT INTO telemetry (sensor_type, reading_value, unit, timestamp, source) "
                    "VALUES (?,?,?,?,?)",
                    (s, new_val, unit, ts_str, "simulator"),
                )
                _telemetry_throttle[s] = sensor_now
                broadcast_payload.append({
                    "id": cur.lastrowid,
                    "sensor_type": s,
                    "reading_value": new_val,
                    "unit": unit,
                    "timestamp": ts_str,
                    "sensor_id": None,
                    "location": "Simulator",
                    "source": "simulator",
                })

        # 2) Registered devices: produce readings respecting update_interval_seconds
        #    so registered devices transition from "Awaiting" to "Live".
        try:
            device_rows = conn.execute(
                "SELECT id, sensor_id, sensor_type, location, update_interval_seconds, last_seen "
                "FROM devices WHERE enabled = 1"
            ).fetchall()
        except Exception:
            device_rows = []
        spec_by_type = {s[0]: s for s in SENSOR_SPECS}
        for d in device_rows:
            sid = d["sensor_id"]
            stype = d["sensor_type"]
            interval = d["update_interval_seconds"] or 30
            spec = spec_by_type.get(stype)
            if not spec:
                continue
            if stype not in enabled_types:
                continue
            _, unit, base, jitter = spec
            # Throttle: only generate if interval has elapsed since last_seen
            last_dt = None
            if d["last_seen"]:
                try:
                    last_dt = datetime.strptime(d["last_seen"], "%Y-%m-%d %H:%M:%S")
                except (ValueError, TypeError):
                    last_dt = None
            if last_dt and (now_dt - last_dt).total_seconds() < interval:
                continue
            val = round(base + random.uniform(-jitter, jitter), 2)
            ts = now_dt.strftime("%Y-%m-%d %H:%M:%S")
            cur = conn.execute(
                "INSERT INTO telemetry (sensor_type, reading_value, unit, timestamp, sensor_id, location, source, received_at) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (stype, val, unit, ts, sid, d["location"], "simulator", ts),
            )
            building = _extract_building(d["location"])
            conn.execute(
                "UPDATE devices SET last_seen = ?, last_value = ?, last_unit = ?, "
                "building = COALESCE(?, building), "
                "last_expected_at = datetime(?, '+' || update_interval_seconds || ' seconds') "
                "WHERE id = ?",
                (ts, val, unit, building, ts, d["id"]),
            )
            new_expected = (now_dt + timedelta(seconds=interval)).strftime("%Y-%m-%d %H:%M:%S")
            broadcast_payload.append({
                "id": cur.lastrowid,
                "sensor_type": stype,
                "reading_value": val,
                "unit": unit,
                "timestamp": ts,
                "sensor_id": sid,
                "location": d["location"],
                "source": "simulator",
                "last_expected_at": new_expected,
            })
        conn.commit()
    finally:
        conn.close()
    for r in broadcast_payload:
        _broadcast_reading(r)


def _compute_tick_interval():
    """Return the simulator tick interval derived from enabled device intervals.

    Uses MIN(update_interval_seconds) // 3, clamped to [1s, 30s].
    Thirding gives each device three chances per configured interval so
    even the smallest user-chosen rate (5 s) is hit on time.
    """
    try:
        conn = get_db()
        row = conn.execute(
            "SELECT MIN(update_interval_seconds) FROM devices WHERE enabled = 1"
        ).fetchone()
        conn.close()
        min_int = row[0] if row and row[0] else 30
        return max(1, min(min_int // 3, 30))
    except Exception:
        return 30


def _simulator_loop():
    """Background daemon thread that ticks the simulator.

    Tick interval adapts to the fastest enabled device interval so that
    all configured update rates are respected and devices never show
    'overdue' unnecessarily.
    """
    # Initial small delay so the app finishes starting before first tick
    time.sleep(5)
    while True:
        try:
            _run_simulator_tick()
        except Exception as e:
            try:
                app.logger.warning(f"Simulator tick failed: {e}")
            except Exception:
                pass
        tick_interval = _compute_tick_interval()
        time.sleep(tick_interval + random.uniform(-0.5, 0.5))


def _start_simulator_thread():
    """Starts the background simulator thread if SENSOR_MODE=simulator."""
    if SENSOR_MODE != "simulator":
        return
    if getattr(app, "_simulator_started", False):
        return
    app._simulator_started = True
    t = threading.Thread(target=_simulator_loop, name="simulator-loop", daemon=True)
    t.start()


_start_simulator_thread()


VALID_TYPES = ("Temperature", "Humidity", "Air Quality", "Energy", "CO2")
CANONICAL_UNITS = {"Temperature": "C", "Humidity": "%", "Air Quality": "AQI", "Energy": "kW", "CO2": "ppm"}


def _ingest_reading(payload, source="http"):
    """Shared ingest logic. Returns (json_response, status_code)."""
    if not payload:
        return jsonify({"ok": False, "error": "bad_request", "message": "Request body must be JSON."}), 400

    sensor_type = (payload.get("sensor_type") or "").strip()
    reading_value = payload.get("reading_value")
    unit = (payload.get("unit") or "").strip()
    sensor_id = (payload.get("sensor_id") or "").strip()[:64] or None
    location = (payload.get("location") or "").strip()[:128] or None
    ts_raw = (payload.get("timestamp") or "").strip()

    if sensor_type not in VALID_TYPES:
        return jsonify({
            "ok": False, "error": "bad_request",
            "message": f"Invalid sensor_type. Must be one of: {', '.join(VALID_TYPES)}",
        }), 400

    if not _is_sensor_enabled(sensor_type):
        return jsonify({
            "ok": False, "error": "disabled",
            "message": f"Sensor '{sensor_type}' is disabled. Enable it on /sensors to accept readings.",
        }), 403

    # Pre-registration is mandatory for devices (sensor_id is required + must exist)
    if not sensor_id:
        return jsonify({
            "ok": False, "error": "bad_request",
            "message": "sensor_id is required. Register the device on /sensors first.",
        }), 400

    if not _device_exists(sensor_id, sensor_type):
        return jsonify({
            "ok": False, "error": "unregistered",
            "message": f"Device '{sensor_id}' is not registered. Please register it on /sensors before sending readings.",
        }), 403

    if not _is_device_enabled(sensor_id, sensor_type):
        return jsonify({
            "ok": False, "error": "disabled",
            "message": f"Device '{sensor_id}' is disabled. Enable it on /devices to accept readings.",
        }), 403

    if reading_value is None or not isinstance(reading_value, (int, float)) or reading_value != reading_value:
        return jsonify({
            "ok": False, "error": "bad_request",
            "message": "reading_value must be a finite number.",
        }), 400

    if not unit:
        unit = CANONICAL_UNITS.get(sensor_type, "")

    if ts_raw:
        try:
            ts = datetime.fromisoformat(ts_raw).strftime("%Y-%m-%d %H:%M:%S")
        except (ValueError, TypeError):
            ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    else:
        ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    rate_key = (sensor_id, sensor_type) if sensor_id else sensor_type
    now_ts = datetime.utcnow().timestamp()
    last = _ingest_rate_limit.get(rate_key)
    if last is not None and (now_ts - last) < 5:
        return jsonify({
            "ok": False, "error": "rate_limited",
            "message": f"Rate limited: max 1 reading per 5s per sensor. Try again in {5 - (now_ts - last):.0f}s.",
        }), 429
    _ingest_rate_limit[rate_key] = now_ts

    conn = get_db()
    conn.execute(
        "INSERT INTO telemetry (sensor_type, reading_value, unit, timestamp, sensor_id, location, source, received_at) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (sensor_type, round(float(reading_value), 4), unit, ts, sensor_id, location, source,
         datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")),
    )
    new_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Update device last_seen / last_value / last_unit / location (building extracted)
    building = _extract_building(location)
    conn.execute(
        "UPDATE devices SET last_seen = ?, last_value = ?, last_unit = ?, "
        "location = COALESCE(?, location), building = COALESCE(?, building), "
        "last_expected_at = datetime(?, '+' || update_interval_seconds || ' seconds') "
        "WHERE sensor_id = ? AND sensor_type = ?",
        (ts, round(float(reading_value), 4), unit, location, building, ts, sensor_id, sensor_type),
    )

    conn.commit()
    conn.close()

    dev_row = None
    try:
        dev_row = get_db().execute(
            "SELECT update_interval_seconds FROM devices WHERE sensor_id = ? AND sensor_type = ?",
            (sensor_id, sensor_type)
        ).fetchone()
    except Exception:
        pass
    interval_sec = dev_row[0] if dev_row and dev_row[0] else 30
    new_expected = (datetime.strptime(ts, "%Y-%m-%d %H:%M:%S") + timedelta(seconds=interval_sec)).strftime("%Y-%m-%d %H:%M:%S")

    _broadcast_reading({
        "id": new_id,
        "sensor_type": sensor_type,
        "reading_value": round(float(reading_value), 4),
        "unit": unit,
        "timestamp": ts,
        "sensor_id": sensor_id,
        "location": location,
        "source": source,
        "last_expected_at": new_expected,
    })

    if source == "ui":
        _audit_log("inject_reading", "telemetry", new_id,
                   {"sensor_type": sensor_type, "sensor_id": sensor_id,
                    "reading_value": round(float(reading_value), 4), "unit": unit})

    return jsonify({"ok": True, "id": new_id, "message": "Reading ingested successfully."}), 201


@app.route("/api/telemetry/ingest", methods=["POST"])
def api_telemetry_ingest():
    api_key = request.headers.get("X-API-Key", "")
    if not _verify_device_api_key(api_key):
        return jsonify({"ok": False, "error": "unauthorized", "message": "Invalid or missing X-API-Key header."}), 401

    payload = request.get_json(silent=True)
    return _ingest_reading(payload, source="http")


@app.route("/api/ingest/<slug>", methods=["POST"])
def api_ingest_typed(slug):
    """Per-type ingest endpoint. e.g. /api/ingest/temperature, /api/ingest/co2."""
    api_key = request.headers.get("X-API-Key", "")
    if not _verify_device_api_key(api_key):
        return jsonify({"ok": False, "error": "unauthorized", "message": "Invalid or missing X-API-Key header."}), 401
    sensor_type = SENSOR_TYPE_SLUGS.get(slug.lower())
    if not sensor_type:
        return jsonify({"ok": False, "error": "bad_request",
                        "message": f"Unknown sensor slug '{slug}'. Use one of: {', '.join(SENSOR_TYPE_SLUGS.keys())}"}), 404
    payload = request.get_json(silent=True) or {}
    payload["sensor_type"] = sensor_type
    return _ingest_reading(payload, source="http")


@app.route("/api/telemetry/ingest-ui", methods=["POST"])
@role_required("Admin", "Developer")
def api_telemetry_ingest_ui():
    if not DEVICE_API_KEY:
        return jsonify({"ok": False, "error": "not_configured", "message": "DEVICE_API_KEY not set on server."}), 503

    payload = request.get_json(silent=True)
    return _ingest_reading(payload, source="ui")


@app.route("/api/sensors/<sensor_type>/toggle", methods=["POST"])
@admin_required
def api_sensor_toggle(sensor_type):
    if sensor_type not in VALID_TYPES:
        return jsonify({"ok": False, "error": "bad_request",
                        "message": f"Invalid sensor_type. Must be one of: {', '.join(VALID_TYPES)}"}), 400
    payload = request.get_json(silent=True) or {}
    enabled = payload.get("enabled")
    if enabled is None:
        conn = get_db()
        row = conn.execute("SELECT enabled FROM sensor_config WHERE sensor_type = ?", (sensor_type,)).fetchone()
        conn.close()
        enabled = not bool(row["enabled"]) if row else True
    else:
        enabled = bool(enabled)
    _set_sensor_enabled(sensor_type, enabled, by_user=session.get("username", ""))
    _audit_log("toggle_sensor_type", "sensor_type", sensor_type, {"enabled": enabled})
    return jsonify({
        "ok": True, "sensor_type": sensor_type, "enabled": enabled,
        "message": f"Sensor '{sensor_type}' {'enabled' if enabled else 'disabled'}.",
    })


@app.route("/api/sensors/<sensor_type>/devices", methods=["POST"])
@admin_required
def api_sensor_register_device(sensor_type):
    """Register a new device under this sensor type. Pre-registration is required."""
    if sensor_type not in VALID_TYPES:
        return jsonify({"ok": False, "error": "bad_request",
                        "message": f"Invalid sensor_type. Must be one of: {', '.join(VALID_TYPES)}"}), 400
    payload = request.get_json(silent=True) or {}
    sensor_id = (payload.get("sensor_id") or "").strip()[:64]
    display_name = (payload.get("display_name") or "").strip()[:128] or None
    update_interval_raw = payload.get("update_interval_seconds", 30)
    try:
        update_interval = int(update_interval_raw)
    except (TypeError, ValueError):
        return jsonify({"ok": False, "message": "update_interval_seconds must be an integer."}), 400
    enabled = bool(payload.get("enabled", True))

    if not sensor_id:
        return jsonify({"ok": False, "message": "sensor_id is required."}), 400
    ok, update_interval, err = _validate_interval(update_interval)
    if not ok:
        return jsonify({"ok": False, "message": err}), 400

    cleaned, err = _validate_register_device_payload(payload)
    if err:
        return err
    location = cleaned["location"]
    building = cleaned["building"]
    floor_number = cleaned["floor_number"]
    room_id = cleaned["room_id"]
    location_detail = cleaned["location_detail"]

    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO devices (sensor_id, sensor_type, location, display_name, building, "
            "update_interval_seconds, enabled, created_by, floor_number, room_id, location_detail) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (sensor_id, sensor_type, location, display_name, building, update_interval,
             1 if enabled else 0, session.get("username", ""),
             floor_number, room_id, location_detail),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({"ok": False, "message": f"Device '{sensor_id}' already registered for '{sensor_type}'."}), 409
    new_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    _audit_log("register_device", "device", new_id,
               {"sensor_id": sensor_id, "sensor_type": sensor_type,
                "location": location, "building": building})
    return jsonify({
        "ok": True, "id": new_id,
        "sensor_id": sensor_id, "sensor_type": sensor_type,
        "building": building, "update_interval_seconds": update_interval,
        "message": f"Device '{sensor_id}' registered. It will start receiving readings once it POSTs.",
    })


@app.route("/api/buildings", methods=["GET"])
@login_required
def api_buildings():
    return jsonify({"buildings": _get_buildings()})


@app.route("/api/buildings/<code>/floors", methods=["GET"])
@login_required
def api_floors(code):
    code = (code or "").strip().upper()
    if code not in {"A", "B", "C"}:
        return jsonify({"ok": False, "message": "Unknown building."}), 404
    return jsonify({"floors": _get_floors_for_building(code)})


@app.route("/api/buildings/<code>/floors/<int:floor>/rooms", methods=["GET"])
@login_required
def api_rooms(code, floor):
    code = (code or "").strip().upper()
    if code not in {"A", "B", "C"}:
        return jsonify({"ok": False, "message": "Unknown building."}), 404
    return jsonify({"rooms": _get_rooms_for_floor(code, floor)})


@app.route("/api/devices/<int:did>/interval", methods=["PUT"])
@admin_required
def api_device_set_interval(did):
    payload = request.get_json(silent=True) or {}
    interval = payload.get("update_interval_seconds")
    try:
        interval = int(interval)
    except (TypeError, ValueError):
        return jsonify({"ok": False, "message": "update_interval_seconds must be an integer."}), 400
    if interval not in ALLOWED_INTERVALS and (interval < MIN_INTERVAL or interval > MAX_INTERVAL):
        return jsonify({"ok": False, "message": f"update_interval_seconds must be between {MIN_INTERVAL}s and {MAX_INTERVAL}s."}), 400
    conn = get_db()
    row = conn.execute("SELECT sensor_id, update_interval_seconds FROM devices WHERE id = ?", (did,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "message": "Device not found."}), 404
    old_interval = row["update_interval_seconds"]
    conn.execute(
        "UPDATE devices SET update_interval_seconds = ?, "
        "last_expected_at = datetime(COALESCE(last_seen, ?), '+' || ? || ' seconds') "
        "WHERE id = ?",
        (interval, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), interval, did),
    )
    conn.commit()
    conn.close()
    _audit_log("change_device_interval", "device", did,
               {"sensor_id": row["sensor_id"],
                "old_interval": old_interval, "new_interval": interval})
    return jsonify({
        "ok": True, "id": did, "update_interval_seconds": interval,
        "message": f"Device '{row['sensor_id']}' interval set to {interval}s.",
    })


@app.route("/api/devices/<int:did>/type", methods=["PUT"])
@admin_required
def api_device_change_type(did):
    """Change a device's sensor_type and optionally its interval."""
    payload = request.get_json(silent=True) or {}
    new_type = (payload.get("sensor_type") or "").strip()
    if new_type not in VALID_TYPES:
        return jsonify({"ok": False, "message": f"Invalid sensor_type. Must be one of: {', '.join(VALID_TYPES)}"}), 400
    interval = payload.get("update_interval_seconds")
    if interval is not None:
        try:
            interval = int(interval)
        except (TypeError, ValueError):
            return jsonify({"ok": False, "message": "update_interval_seconds must be an integer."}), 400
        if interval not in ALLOWED_INTERVALS and (interval < MIN_INTERVAL or interval > MAX_INTERVAL):
            return jsonify({"ok": False, "message": f"Interval must be between {MIN_INTERVAL}s and {MAX_INTERVAL}s."}), 400

    conn = get_db()
    row = conn.execute("SELECT sensor_id, sensor_type FROM devices WHERE id = ?", (did,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "message": "Device not found."}), 404

    if new_type == row["sensor_type"] and interval is None:
        conn.close()
        return jsonify({"ok": True, "message": "No changes."})

    existing = conn.execute(
        "SELECT 1 FROM devices WHERE sensor_id = ? AND sensor_type = ? AND id != ?",
        (row["sensor_id"], new_type, did)
    ).fetchone()
    if existing:
        conn.close()
        return jsonify({"ok": False, "message": f"Device '{row['sensor_id']}' already exists under '{new_type}'."}), 409

    if not _is_sensor_enabled(new_type):
        conn.close()
        return jsonify({"ok": False, "message": f"Sensor type '{new_type}' is disabled. Enable it first on /sensors."}), 400

    if interval is not None:
        conn.execute(
            "UPDATE devices SET sensor_type = ?, update_interval_seconds = ? "
            "WHERE id = ?", (new_type, interval, did))
    else:
        conn.execute("UPDATE devices SET sensor_type = ? WHERE id = ?", (new_type, did))
    conn.commit()
    conn.close()
    audit_details = {"sensor_id": row["sensor_id"],
                     "old_type": row["sensor_type"], "new_type": new_type}
    if interval is not None:
        audit_details["new_interval"] = interval
    _audit_log("change_device_type", "device", did, audit_details)
    return jsonify({"ok": True, "message": f"Device '{row['sensor_id']}' moved from '{row['sensor_type']}' to '{new_type}'."})


@app.route("/api/devices/<int:did>/toggle", methods=["POST"])
@admin_required
def api_device_toggle(did):
    conn = get_db()
    row = conn.execute("SELECT enabled, sensor_id FROM devices WHERE id = ?", (did,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "message": "Device not found."}), 404
    payload = request.get_json(silent=True) or {}
    if "enabled" in payload:
        new_state = bool(payload["enabled"])
    else:
        new_state = not bool(row["enabled"])
    conn.execute("UPDATE devices SET enabled = ? WHERE id = ?", (1 if new_state else 0, did))
    conn.commit()
    conn.close()
    _audit_log("toggle_device", "device", did,
               {"sensor_id": row["sensor_id"], "enabled": new_state})
    return jsonify({
        "ok": True, "id": did, "enabled": new_state,
        "message": f"Device '{row['sensor_id']}' {'enabled' if new_state else 'disabled'}.",
    })


@app.route("/api/devices", methods=["GET"])
@role_required("Admin", "Developer")
def api_devices_list():
    """List all registered devices. Used by IoT simulator to fetch intervals."""
    conn = get_db()
    rows = conn.execute("""
        SELECT id, sensor_id, sensor_type, location, building,
               update_interval_seconds, enabled
        FROM devices
        ORDER BY building NULLS LAST, sensor_type, sensor_id
    """).fetchall()
    conn.close()
    return jsonify({
        "devices": [
            {
                "id": r["id"],
                "sensor_id": r["sensor_id"],
                "sensor_type": r["sensor_type"],
                "location": r["location"],
                "building": r["building"],
                "update_interval_seconds": r["update_interval_seconds"],
                "enabled": bool(r["enabled"]),
            }
            for r in rows
        ]
    })


@app.route("/api/devices/<int:did>", methods=["PUT"])
@admin_required
def api_device_update(did):
    payload = request.get_json(silent=True) or {}
    display_name = (payload.get("display_name") or "").strip()[:128] or None
    conn = get_db()
    row = conn.execute("SELECT sensor_id FROM devices WHERE id = ?", (did,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "message": "Device not found."}), 404

    # Validate structured location if any structured fields present
    has_structured = any(
        k in payload for k in ("building_code", "floor_number", "room_id", "location_detail")
    )
    if has_structured:
        cleaned, err = _validate_register_device_payload(payload)
        if err:
            conn.close()
            return err
        location = cleaned["location"]
        building = cleaned["building"]
        floor_number = cleaned["floor_number"]
        room_id = cleaned["room_id"]
        location_detail = cleaned["location_detail"]
        conn.execute(
            "UPDATE devices SET display_name = COALESCE(?, display_name), "
            "location = ?, building = COALESCE(?, building), "
            "floor_number = COALESCE(?, floor_number), "
            "room_id = COALESCE(?, room_id), "
            "location_detail = ? "
            "WHERE id = ?",
            (display_name, location, building, floor_number, room_id, location_detail, did),
        )
    else:
        location = (payload.get("location") or "").strip()[:128] or None
        building = _extract_building(location) if location else None
        conn.execute(
            "UPDATE devices SET display_name = COALESCE(?, display_name), "
            "location = COALESCE(?, location), building = COALESCE(?, building) "
            "WHERE id = ?",
            (display_name, location, building, did),
        )

    conn.commit()
    conn.close()
    _audit_log("update_device", "device", did,
               {"sensor_id": row["sensor_id"],
                "display_name": display_name, "location": location})
    return jsonify({
        "ok": True, "id": did,
        "message": f"Device '{row['sensor_id']}' updated.",
    })


@app.route("/api/devices/<int:did>", methods=["DELETE"])
@admin_required
def api_device_delete(did):
    conn = get_db()
    row = conn.execute("SELECT sensor_id, sensor_type FROM devices WHERE id = ?", (did,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "message": "Device not found."}), 404
    conn.execute("DELETE FROM devices WHERE id = ?", (did,))
    conn.commit()
    conn.close()
    _audit_log("delete_device", "device", did,
               {"sensor_id": row["sensor_id"], "sensor_type": row["sensor_type"]})
    return jsonify({
        "ok": True, "id": did,
        "message": f"Device '{row['sensor_id']}' removed from registry (telemetry history preserved).",
    })


@app.route("/devices")
@role_required("Admin", "Developer")
def devices():
    """Live IoT device fleet view: all registered devices with current status."""
    conn = get_db()
    rows = conn.execute("""
        SELECT id, sensor_id, sensor_type, location, display_name, building,
               enabled, first_seen, last_seen, last_value, last_unit,
               update_interval_seconds, last_expected_at
        FROM devices
        ORDER BY building NULLS LAST, location, sensor_type, sensor_id
    """).fetchall()
    conn.close()

    now = datetime.utcnow()
    devices_data = []
    for r in rows:
        last_dt = None
        ts_str = r["last_seen"]
        if ts_str:
            try:
                last_dt = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
            except (ValueError, TypeError):
                pass
        if last_dt and r["enabled"]:
            diff = (now - last_dt).total_seconds()
            interval = r["update_interval_seconds"] or 30
            live_thresh = max(30, int(interval * 1.5))
            stale_thresh = max(300, interval * 10)
            if diff < live_thresh:
                status = "live"; status_label = "Live"
            elif diff < stale_thresh:
                status = "stale"; status_label = "Stale"
            else:
                status = "offline"; status_label = "Offline"
            age_seconds = int(diff)
        elif not r["enabled"]:
            status = "disabled"; status_label = "Disabled"; age_seconds = None
        elif last_dt is None:
            status = "never"; status_label = "Awaiting"; age_seconds = None
        else:
            status = "unknown"; status_label = "Unknown"; age_seconds = None

        # countdown to next expected reading
        countdown = None
        exp = r["last_expected_at"]
        if exp and r["enabled"]:
            try:
                exp_dt = datetime.strptime(exp, "%Y-%m-%d %H:%M:%S")
                countdown = int((exp_dt - now).total_seconds())
            except (ValueError, TypeError):
                pass

        devices_data.append({
            "id": r["id"],
            "sensor_id": r["sensor_id"],
            "sensor_type": r["sensor_type"],
            "location": r["location"] or "Unknown",
            "display_name": r["display_name"],
            "building": r["building"],
            "enabled": bool(r["enabled"]),
            "first_seen": r["first_seen"] or "",
            "last_seen": (ts_str or "") if r["enabled"] else "",
            "last_value": r["last_value"] if r["enabled"] else None,
            "unit": (r["last_unit"] or "") if r["enabled"] else "",
            "status": status,
            "status_label": status_label,
            "age_seconds": age_seconds,
            "interval": r["update_interval_seconds"],
            "countdown": countdown,
            "last_expected_at": (exp or "") if r["enabled"] else "",
        })

    total = len(devices_data)
    live_count = sum(1 for d in devices_data if d["status"] == "live")
    stale_count = sum(1 for d in devices_data if d["status"] == "stale")
    offline_count = sum(1 for d in devices_data if d["status"] == "offline")
    disabled_count = sum(1 for d in devices_data if d["status"] == "disabled")
    never_count = sum(1 for d in devices_data if d["status"] == "never")

    return render_template(
        "devices.html",
        devices=devices_data,
        total=total,
        live_count=live_count,
        stale_count=stale_count,
        offline_count=offline_count,
        disabled_count=disabled_count,
        never_count=never_count,
        is_admin=session.get("role") == "Admin",
        buildings=_get_buildings(),
        allowed_intervals=ALLOWED_INTERVALS,
    )


@app.route("/sensors")
@role_required("Admin", "Developer")
def sensors():
    """Sensor management: per-type endpoints, test reading, registered devices."""
    role = session.get("role")
    is_admin = (role == "Admin")

    conn = get_db()
    total_http = conn.execute(
        "SELECT COUNT(*) c FROM telemetry WHERE source = 'http'"
    ).fetchone()["c"]
    total_sim = conn.execute(
        "SELECT COUNT(*) c FROM telemetry WHERE source = 'simulator'"
    ).fetchone()["c"]

    sensor_types_order = ["Temperature", "Humidity", "Air Quality", "Energy", "CO2"]
    enabled_types = set(_get_enabled_sensors())
    now = datetime.utcnow()
    sensors = []
    for stype in sensor_types_order:
        devices_rows = conn.execute("""
            SELECT id, sensor_id, location, display_name, building, enabled,
                   update_interval_seconds, last_seen, last_value, last_unit
            FROM devices
            WHERE sensor_type = ?
            ORDER BY building NULLS LAST, location, sensor_id
        """, (stype,)).fetchall()
        type_last = conn.execute(
            "SELECT MAX(timestamp) FROM telemetry WHERE sensor_type = ?", (stype,)
        ).fetchone()[0]
        devices_list = []
        for d in devices_rows:
            last_dt = None
            if d["last_seen"]:
                try:
                    last_dt = datetime.strptime(d["last_seen"], "%Y-%m-%d %H:%M:%S")
                except (ValueError, TypeError):
                    pass
            if last_dt and d["enabled"]:
                diff = (now - last_dt).total_seconds()
                if diff < 30: status = "live"
                elif diff < 300: status = "stale"
                else: status = "offline"
                age = int(diff)
            elif not d["enabled"]:
                status = "disabled"; age = None
            elif last_dt is None:
                status = "never"; age = None
            else:
                status = "unknown"; age = None
            devices_list.append({
                "id": d["id"], "sensor_id": d["sensor_id"],
                "location": d["location"] or "Unassigned",
                "display_name": d["display_name"], "building": d["building"],
                "enabled": bool(d["enabled"]), "interval": d["update_interval_seconds"],
                "last_seen": (d["last_seen"] or "") if d["enabled"] else "",
                "last_value": d["last_value"] if d["enabled"] else None,
                "unit": (d["last_unit"] or "") if d["enabled"] else "",
                "status": status, "age_seconds": age,
            })
        if type_last:
            try:
                type_last_dt = datetime.strptime(type_last, "%Y-%m-%d %H:%M:%S")
                diff = (now - type_last_dt).total_seconds()
                if diff < 300: type_status = "online"
                elif diff < 1800: type_status = "stale"
                else: type_status = "offline"
            except (ValueError, TypeError):
                type_status = "unknown"
        else:
            type_status = "unknown"
        sensors.append({
            "sensor_type": stype, "enabled": stype in enabled_types,
            "type_status": type_status, "type_last_reading_at": type_last or "Never",
            "devices": devices_list, "device_count": len(devices_list),
        })
    buildings = _get_buildings()
    conn.close()

    return render_template(
        "sensors.html",
        sensors=sensors, total_http=total_http, total_sim=total_sim,
        buildings=buildings, allowed_intervals=ALLOWED_INTERVALS, is_admin=is_admin,
    )


@app.route("/api/dashboard/blocks")
@login_required
def api_dashboard_blocks():
    """Returns one chart series per building (Block A/B/C).
    Each block picks its first enabled device of a representative sensor type
    and returns its recent 24 readings.
    """
    block_map = {
        "A": ("Temperature", "°C", "#EF4444"),
        "B": ("Air Quality", " AQI", "#10B981"),
        "C": ("Energy", " kW", "#F59E0B"),
    }
    out = {"blocks": {}}
    conn = get_db()
    for code, (stype, unit, color) in block_map.items():
        # Pick first enabled device in this building for this sensor type
        row = conn.execute("""
            SELECT id, sensor_id, location
            FROM devices
            WHERE enabled = 1 AND building = ? AND sensor_type = ?
            ORDER BY id
            LIMIT 1
        """, (code, stype)).fetchone()
        block = {
            "building": code,
            "sensor_type": stype,
            "unit": unit,
            "color": color,
            "device": None,
            "latest": None,
            "labels": [],
            "values": [],
        }
        if row:
            block["device"] = dict(row)
            series = conn.execute("""
                SELECT reading_value, timestamp FROM telemetry
                WHERE sensor_id = ? AND sensor_type = ?
                ORDER BY timestamp DESC LIMIT 24
            """, (row["sensor_id"], stype)).fetchall()
            series = list(reversed(series))
            block["labels"] = [r["timestamp"][11:19] for r in series]
            block["values"] = [r["reading_value"] for r in series]
            block["latest"] = series[-1]["reading_value"] if series else None
        out["blocks"][code] = block
    conn.close()
    return jsonify(out)


@app.route("/api/telemetry/latest")
@login_required
def api_telemetry_latest():
    """Per-device telemetry: returns one series per enabled device.

    Simulator-only readings (sensor_id IS NULL) are grouped under a synthetic
    'simulator' entry so the chart stays useful when no real devices are
    reporting.
    """
    _run_simulator_tick()
    conn = get_db()
    enabled_types = _get_enabled_sensors()
    devices_out = []

    # Real devices (sensor_id is set)
    real_devices = conn.execute("""
        SELECT id, sensor_id, sensor_type, location, display_name, building,
               last_value, last_unit
        FROM devices
        WHERE enabled = 1 AND sensor_type IN ({})
        ORDER BY building NULLS LAST, location, sensor_type, sensor_id
    """.format(",".join("?" for _ in enabled_types)), tuple(enabled_types)).fetchall()

    for d in real_devices:
        series = conn.execute("""
            SELECT reading_value, timestamp FROM telemetry
            WHERE sensor_id = ? AND sensor_type = ?
            ORDER BY timestamp DESC LIMIT 24
        """, (d["sensor_id"], d["sensor_type"])).fetchall()
        series = list(reversed(series))
        latest_val = series[-1]["reading_value"] if series else d["last_value"]
        unit = d["last_unit"] or CANONICAL_UNITS.get(d["sensor_type"], "")
        devices_out.append({
            "id": d["id"],
            "sensor_id": d["sensor_id"],
            "sensor_type": d["sensor_type"],
            "location": d["location"] or "Unknown",
            "display_name": d["display_name"] or d["sensor_id"],
            "building": d["building"],
            "unit": unit,
            "latest": latest_val,
            "labels": [r["timestamp"][11:19] for r in series],
            "values": [r["reading_value"] for r in series],
            "source": "device",
        })

    # Simulator readings (sensor_id is NULL): one summary chart per sensor type
    sim_devices = conn.execute("""
        SELECT sensor_type, reading_value, unit, timestamp FROM telemetry
        WHERE (sensor_id IS NULL OR sensor_id = '') AND source = 'simulator'
        ORDER BY timestamp DESC LIMIT 240
    """).fetchall()

    sim_by_type = {}
    for r in sim_devices:
        sim_by_type.setdefault(r["sensor_type"], []).append(r)
    for stype, rows in sim_by_type.items():
        if stype not in enabled_types:
            continue
        rows = list(reversed(rows[-24:]))
        unit = rows[-1]["unit"] if rows else CANONICAL_UNITS.get(stype, "")
        latest_val = rows[-1]["reading_value"] if rows else None
        devices_out.append({
            "id": None,
            "sensor_id": None,
            "sensor_type": stype,
            "location": "Simulator",
            "display_name": f"Simulator ({stype})",
            "unit": unit,
            "latest": latest_val,
            "labels": [r["timestamp"][11:19] for r in rows],
            "values": [r["reading_value"] for r in rows],
            "source": "simulator",
        })

    conn.close()
    resp = jsonify({"devices": devices_out})
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


@app.route("/api/telemetry/stream")
@login_required
def api_telemetry_stream():
    """Server-Sent Events stream of new telemetry readings."""
    import json as _json

    q = queue.Queue(maxsize=200)

    @stream_with_context
    def gen():
        with _sse_subscribers_lock:
            _sse_subscribers.append(q)
        try:
            yield "event: hello\ndata: {}\n\n"
            while True:
                try:
                    kind, payload = q.get(timeout=15)
                    # For events, prefer the specific event name from payload["type"]
                    # (e.g. "device_added") so JS can listen with addEventListener.
                    event_name = payload.get("type", kind) if kind == "event" else kind
                    yield f"event: {event_name}\ndata: {_json.dumps(payload)}\n\n"
                except queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            with _sse_subscribers_lock:
                try:
                    _sse_subscribers.remove(q)
                except ValueError:
                    pass

    return Response(
        gen(),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "X-Accel-Buffering": "no",
        },
    )


@app.route("/api/equipment/<int:eid>/status", methods=["POST"])
@admin_required
def api_equipment_status(eid):
    payload = request.get_json(silent=True) or {}
    new_status = payload.get("status")
    if new_status not in ("Operational", "Maintenance Required", "Offline"):
        return (
            jsonify(
                {"ok": False, "type": "danger", "message": "Invalid status value."}
            ),
            400,
        )
    conn = get_db()
    row = conn.execute("SELECT name, status FROM equipment WHERE id = ?", (eid,)).fetchone()
    if not row:
        conn.close()
        return (
            jsonify({"ok": False, "type": "danger", "message": "Equipment not found."}),
            404,
        )
    old_status = row["status"]
    conn.execute(
        "UPDATE equipment SET status = ?, last_inspected = ? WHERE id = ?",
        (new_status, datetime.utcnow().strftime("%Y-%m-%d"), eid),
    )
    conn.commit()
    conn.close()
    _audit_log("change_equipment_status", "equipment", eid,
               {"name": row["name"], "old_status": old_status, "new_status": new_status})
    return jsonify(
        {
            "ok": True,
            "type": "success",
            "message": f"Equipment #{eid} ({row['name']}) set to {new_status}.",
        }
    )


@app.route("/api/tickets", methods=["POST"])
@login_required
def api_ticket_create():
    title = request.form.get("title", "").strip()
    desc = request.form.get("description", "").strip()
    prio = request.form.get("priority", "Medium")
    eq_raw = request.form.get("equipment_id", "").strip()
    if not eq_raw or not eq_raw.isdigit():
        flash("Please select an equipment for this ticket.", "danger")
        return redirect(url_for("maintenance"))
    eq_id = int(eq_raw)
    if not title or not desc or prio not in ("Low", "Medium", "High"):
        flash("All fields are required.", "danger")
        return redirect(url_for("maintenance"))
    conn = get_db()
    exists = conn.execute("SELECT 1 FROM equipment WHERE id = ?", (eq_id,)).fetchone()
    if not exists:
        conn.close()
        flash("Selected equipment not found.", "danger")
        return redirect(url_for("maintenance"))
    conn.execute(
        "INSERT INTO maintenance_tickets (user_id, equipment_id, title, description, priority, status) "
        "VALUES (?,?,?,?,?, 'Pending')",
        (session["user_id"], eq_id, title, desc, prio),
    )
    new_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    _audit_log("create_ticket", "ticket", new_id,
               {"title": title, "priority": prio, "equipment_id": eq_id})
    flash("Ticket submitted successfully.", "success")
    return redirect(url_for("maintenance"))


@app.route("/api/tickets/<int:tid>/status", methods=["POST"])
@admin_required
def api_ticket_status(tid):
    payload = request.get_json(silent=True) or {}
    new_status = payload.get("status")
    if new_status not in ("Pending", "In Progress", "Resolved", "Rejected"):
        return (
            jsonify(
                {"ok": False, "type": "danger", "message": "Invalid ticket status."}
            ),
            400,
        )
    conn = get_db()
    row = conn.execute(
        "SELECT title, status FROM maintenance_tickets WHERE id = ?", (tid,)
    ).fetchone()
    if not row:
        conn.close()
        return (
            jsonify({"ok": False, "type": "danger", "message": "Ticket not found."}),
            404,
        )
    old_status = row["status"]
    conn.execute(
        "UPDATE maintenance_tickets SET status = ? WHERE id = ?", (new_status, tid)
    )
    conn.commit()
    conn.close()
    _audit_log("change_ticket_status", "ticket", tid,
               {"title": row["title"], "old_status": old_status, "new_status": new_status})
    return jsonify(
        {
            "ok": True,
            "type": "success",
            "message": f"Ticket #{tid} ({row['title']}) updated to {new_status}.",
        }
    )


@app.errorhandler(404)
def not_found(e):
    return render_template("login.html"), 404


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    """Account info + rename + change password (single profile page)."""
    conn = get_db()
    user = conn.execute(
        "SELECT id, username, role, full_name, must_change_password, last_password_change, created_at "
        "FROM users WHERE id = ?",
        (session["user_id"],),
    ).fetchone()
    if request.method == "POST":
        # Distinguish rename vs change-password by which fields are present
        if "current_password" in request.form and "new_password" in request.form:
            # Change-password request (AJAX-style, may return JSON)
            current = request.form.get("current_password", "")
            new_pw = request.form.get("new_password", "")
            confirm_pw = request.form.get("confirm_password", "")
            db_user = conn.execute(
                "SELECT username, password_hash FROM users WHERE id = ?",
                (session["user_id"],),
            ).fetchone()
            if not verify_pw(current, db_user["password_hash"]):
                conn.close()
                if _wants_json():
                    return jsonify({"ok": False, "type": "danger", "message": "Current password is incorrect."}), 400
                flash("Current password is incorrect.", "danger")
            elif new_pw != confirm_pw:
                conn.close()
                if _wants_json():
                    return jsonify({"ok": False, "type": "danger", "message": "New password and confirmation do not match."}), 400
                flash("New password and confirmation do not match.", "danger")
            else:
                ok, msg = validate_password(new_pw, username=db_user["username"])
                if not ok:
                    conn.close()
                    if _wants_json():
                        return jsonify({"ok": False, "type": "danger", "message": msg}), 400
                    flash(msg, "danger")
                else:
                    conn.execute(
                        "UPDATE users SET password_hash = ?, must_change_password = 0, last_password_change = ? WHERE id = ?",
                        (hash_pw(new_pw), datetime.utcnow().strftime("%Y-%m-%d"), session["user_id"]),
                    )
                    conn.commit()
                    conn.close()
                    if _wants_json():
                        return jsonify({"ok": True, "type": "success", "message": "Password updated successfully."})
                    flash("Password updated successfully.", "success")
            return redirect(url_for("profile"))
        # Username change request
        if request.form.get("change_username") == "1":
            new_username = (request.form.get("new_username") or "").strip().lower()
            if not new_username or len(new_username) > 64:
                conn.close()
                if _wants_json():
                    return jsonify({"ok": False, "type": "danger", "message": "Username is required (max 64 chars)."}), 400
                flash("Username is required (max 64 chars).", "danger")
                return redirect(url_for("profile"))
            if not re.match(r'^[a-zA-Z0-9_\-]+$', new_username):
                conn.close()
                if _wants_json():
                    return jsonify({"ok": False, "type": "danger", "message": "Username can only contain letters, numbers, hyphens, and underscores."}), 400
                flash("Username can only contain letters, numbers, hyphens, and underscores.", "danger")
                return redirect(url_for("profile"))
            db_user = conn.execute(
                "SELECT username FROM users WHERE id = ?",
                (session["user_id"],),
            ).fetchone()
            if new_username != db_user["username"]:
                existing = conn.execute(
                    "SELECT 1 FROM users WHERE username = ? AND id != ?",
                    (new_username, session["user_id"]),
                ).fetchone()
                if existing:
                    conn.close()
                    if _wants_json():
                        return jsonify({"ok": False, "type": "danger", "message": "Username already taken."}), 400
                    flash("Username already taken.", "danger")
                    return redirect(url_for("profile"))
            conn.execute("UPDATE users SET username = ? WHERE id = ?", (new_username, session["user_id"]))
            conn.commit()
            conn.close()
            session["username"] = new_username
            if _wants_json():
                return jsonify({"ok": True, "type": "success", "message": "Username updated successfully."})
            flash("Username updated successfully.", "success")
            return redirect(url_for("profile"))
        # Rename request
        full_name = (request.form.get("full_name") or "").strip()
        if not full_name or len(full_name) > 120:
            conn.close()
            if _wants_json():
                return jsonify({"ok": False, "type": "danger", "message": "Full name is required (max 120 chars)."}), 400
            flash("Full name is required (max 120 chars).", "danger")
            return redirect(url_for("profile"))
        conn.execute("UPDATE users SET full_name = ? WHERE id = ?", (full_name, session["user_id"]))
        conn.commit()
        conn.close()
        session["full_name"] = full_name
        if _wants_json():
            return jsonify({"ok": True, "type": "success", "message": "Name updated successfully."})
        flash("Name updated successfully.", "success")
        return redirect(url_for("profile"))
    conn.close()
    return render_template("profile.html", user=user)


def _wants_json():
    """True if the client expects JSON (X-Requested-With) or Accept includes application/json."""
    if request.headers.get("X-Requested-With", "").lower() == "xmlhttprequest":
        return True
    accept = request.headers.get("Accept", "")
    return "application/json" in accept


@app.route("/admin/users")
@admin_required
def admin_users():
    """User management page (Admin only)."""
    conn = get_db()
    users_rows = conn.execute(
        "SELECT id, username, role, full_name, is_active, status, must_change_password, "
        "last_password_change, created_at FROM users WHERE status != 'pending' ORDER BY id"
    ).fetchall()
    users = [dict(r) for r in users_rows]
    pending_users_rows = conn.execute(
        "SELECT id, username, role, full_name, status, created_at "
        "FROM users WHERE status = 'pending' ORDER BY id"
    ).fetchall()
    pending_users = [dict(r) for r in pending_users_rows]
    conn.close()
    return render_template(
        "users.html",
        users=users, pending_users=pending_users, is_admin=True,
    )


@app.route("/api/users", methods=["GET"])
@login_required
def api_users_list():
    """List users. Used by /settings?tab=users as a defensive fallback if server HTML didn't render."""
    conn = get_db()
    rows = conn.execute(
        "SELECT id, username, role, full_name, is_active, status, must_change_password, "
        "last_password_change, created_at FROM users ORDER BY id"
    ).fetchall()
    conn.close()
    return jsonify({
        "users": [
            {
                "id": r["id"],
                "username": r["username"],
                "role": r["role"],
                "full_name": r["full_name"],
                "is_active": bool(r["is_active"]),
                "status": r["status"],
                "must_change_password": bool(r["must_change_password"]),
                "last_password_change": r["last_password_change"],
            }
            for r in rows
        ]
    })


@app.route("/api/users", methods=["POST"])
@admin_required
def api_user_create():
    payload = request.get_json(silent=True) or request.form
    username = (payload.get("username") or "").strip().lower()
    full_name = (payload.get("full_name") or "").strip()
    role = (payload.get("role") or "").strip()
    password = payload.get("password") or ""
    if not username or len(username) > 60 or not all(c.isalnum() or c in "._" for c in username):
        return jsonify({"ok": False, "type": "danger",
                        "message": "Username must be alphanumeric (._ allowed), max 60 chars."}), 400
    if not full_name or len(full_name) > 120:
        return jsonify({"ok": False, "type": "danger",
                        "message": "Full name is required (max 120 chars)."}), 400
    if role not in ("Admin", "User", "Developer"):
        return jsonify({"ok": False, "type": "danger", "message": "Invalid role."}), 400
    ok, msg = validate_password(password, username=username)
    if not ok:
        return jsonify({"ok": False, "type": "danger", "message": msg}), 400
    conn = get_db()
    exists = conn.execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone()
    if exists:
        conn.close()
        return jsonify({"ok": False, "type": "danger",
                        "message": f"Username '{username}' already exists."}), 409
    cur = conn.execute(
        "INSERT INTO users (username, password_hash, role, full_name, must_change_password, last_password_change) "
        "VALUES (?,?,?,?,1,?)",
        (username, hash_pw(password), role, full_name, datetime.utcnow().strftime("%Y-%m-%d")),
    )
    new_id = cur.lastrowid
    conn.commit()
    conn.close()
    _audit_log("add_user", "user", new_id, {"username": username, "role": role})
    return jsonify({
        "ok": True, "type": "success",
        "message": f"User '{username}' created. They must change their password on first login.",
        "user": {"id": new_id, "username": username, "role": role, "full_name": full_name},
    })


@app.route("/api/users/<int:uid>", methods=["PUT"])
@admin_required
def api_user_update(uid):
    payload = request.get_json(silent=True) or {}
    full_name = (payload.get("full_name") or "").strip()
    role = (payload.get("role") or "").strip()
    is_active = 1 if payload.get("is_active") else 0
    if not full_name or len(full_name) > 120:
        return jsonify({"ok": False, "type": "danger", "message": "Full name required."}), 400
    if role not in ("Admin", "User", "Developer"):
        return jsonify({"ok": False, "type": "danger", "message": "Invalid role."}), 400
    conn = get_db()
    row = conn.execute("SELECT role, is_active, username FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "User not found."}), 404
    old_role = row["role"]
    old_active = bool(row["is_active"])
    username = row["username"]
    was_admin = (old_role == "Admin" and old_active)
    becoming_non_admin = (role != "Admin" or not is_active)
    if was_admin and becoming_non_admin and not last_admin_guard(conn, exclude_user_id=uid):
        conn.close()
        return jsonify({"ok": False, "type": "danger",
                        "message": "Cannot demote or deactivate the last active admin."}), 409
    conn.execute(
        "UPDATE users SET full_name = ?, role = ?, is_active = ? WHERE id = ?",
        (full_name, role, is_active, uid),
    )
    conn.commit()
    conn.close()
    changes = []
    if old_role != role:
        changes.append({"field": "role", "old": old_role, "new": role})
    if old_active != bool(is_active):
        changes.append({"field": "is_active", "old": old_active, "new": bool(is_active)})
    _audit_log("update_user", "user", uid,
               {"username": username, "changes": changes})
    if uid == session.get("user_id") and not is_active:
        session.clear()
    return jsonify({"ok": True, "type": "success", "message": f"User #{uid} updated."})


@app.route("/api/users/<int:uid>/password", methods=["POST"])
@admin_required
def api_user_reset_password(uid):
    payload = request.get_json(silent=True) or request.form
    new_pw = payload.get("password") or ""
    ok, msg = validate_password(new_pw)
    if not ok:
        return jsonify({"ok": False, "type": "danger", "message": msg}), 400
    conn = get_db()
    row = conn.execute("SELECT username FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "User not found."}), 404
    target_username = row["username"]
    conn.execute(
        "UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?",
        (hash_pw(new_pw), uid),
    )
    conn.commit()
    conn.close()
    _audit_log("reset_password", "user", uid, {"username": target_username})
    return jsonify({"ok": True, "type": "success",
                    "message": f"Password reset for user #{uid}. They must change it on next login."})


@app.route("/api/users/<int:uid>", methods=["DELETE"])
@admin_required
def api_user_deactivate(uid):
    if uid == session.get("user_id"):
        return jsonify({"ok": False, "type": "danger",
                        "message": "You cannot deactivate your own account."}), 400
    conn = get_db()
    row = conn.execute("SELECT role, is_active, username FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "User not found."}), 404
    if row["role"] == "Admin" and row["is_active"] and not last_admin_guard(conn, exclude_user_id=uid):
        conn.close()
        return jsonify({"ok": False, "type": "danger",
                        "message": "Cannot deactivate the last active admin."}), 409
    conn.execute("UPDATE users SET is_active = 0 WHERE id = ?", (uid,))
    conn.commit()
    conn.close()
    _audit_log("delete_user", "user", uid,
               {"username": row["username"], "role": row["role"]})
    return jsonify({"ok": True, "type": "success",
                    "message": f"User '{row['username']}' deactivated."})


@app.route("/api/users/<int:uid>/approve", methods=["POST"])
@admin_required
def api_user_approve(uid):
    payload = request.get_json(silent=True) or {}
    role = payload.get("role", "User")
    if role not in ("Admin", "User", "Developer"):
        return jsonify({"ok": False, "type": "danger", "message": "Invalid role."}), 400

    conn = get_db()
    row = conn.execute("SELECT status, username FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "User not found."}), 404
    if row["status"] != "pending":
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "User is not pending approval."}), 400

    conn.execute(
        "UPDATE users SET status = 'active', is_active = 1, role = ?, must_change_password = 0 "
        "WHERE id = ?",
        (role, uid),
    )
    conn.commit()
    conn.close()
    _audit_log("approve_user", "user", uid, {"username": row["username"], "role": role})
    return jsonify({"ok": True, "type": "success",
                    "message": f"User '{row['username']}' approved as {role}."})


@app.route("/api/users/<int:uid>/reject", methods=["POST"])
@admin_required
def api_user_reject(uid):
    conn = get_db()
    row = conn.execute("SELECT username, status FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "User not found."}), 404
    if row["status"] != "pending":
        conn.close()
        return jsonify({"ok": False, "type": "danger", "message": "User is not pending approval."}), 400

    conn.execute(
        "UPDATE users SET status = 'rejected', is_active = 0 WHERE id = ?", (uid,)
    )
    conn.commit()
    conn.close()
    _audit_log("reject_user", "user", uid, {"username": row["username"]})
    return jsonify({"ok": True, "type": "success",
                    "message": f"Signup for '{row['username']}' rejected and removed."})


if __name__ == "__main__":
    os.makedirs("instance", exist_ok=True)
    if not os.path.exists(DB_PATH):
        print(f"[INFO] Database not found at {DB_PATH} — creating empty schema...")
        ensure_schema()
        print("       Seed demo data with:  python init_db.py")
    else:
        ensure_schema()
    port = int(os.environ.get("PORT", "5050"))
    host = os.environ.get("HOST", "127.0.0.1")
    print("=" * 64)
    print(" Smart Building Monitoring System  v1.1.0")
    print(f" URL :  http://{host}:{port}")
    print(" Login: admin / Admin1234!")
    print(" Staff: staff / staff123   Dev: dev / dev123")
    print("=" * 64)
    try:
        from waitress import serve
        print(" Server: waitress (production-grade WSGI, threaded)")
        serve(app, host=host, port=port, threads=8)
    except ImportError:
        print(" Server: Flask dev (install waitress==3.0.0 for threaded prod server)")
        try:
            app.run(
                debug=True,
                host=host,
                port=port,
                use_reloader=False,
                threaded=True,
            )
        except OSError as e:
            print(f"[FATAL] Could not bind http://{host}:{port} -> {e}")
            print("        Set PORT=5051 (or another free port) and try again.")
            sys.exit(1)


# Idempotent schema bootstrap — runs at module import so waitress/WSGI deployments
# always pick up new columns/backfills even if init_db.py hasn't been re-run.
# Deferred to AFTER all routes/constants are defined (VALID_TYPES, etc. needed).
ensure_schema()

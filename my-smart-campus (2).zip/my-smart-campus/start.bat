@echo off
REM Smart Campus - One-click start (Windows)
REM Builds (if needed) and starts the Smart Campus container.
REM Open http://localhost:5050 in your browser when ready.

setlocal

echo ============================================
echo  Smart Campus - Start (Windows)
echo ============================================
echo.

where docker >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker is not installed or not in PATH.
    echo         Install Docker Desktop from https://www.docker.com/products/docker-desktop
    exit /b 1
)

echo [1/2] Building and starting container...
docker compose up -d --build

if errorlevel 1 (
    echo.
    echo [ERROR] docker compose failed.
    echo         Check the output above for details.
    exit /b 1
)

echo.
echo [2/2] Waiting for healthcheck...
set /a attempts=0
:wait_loop
set /a attempts+=1
if %attempts% gtr 20 (
    echo [WARNING] Container did not become healthy within 20s.
    echo          Check logs with: docker compose logs
)
docker inspect --format="{{.State.Health.Status}}" smartcampus >nul 2>&1
if errorlevel 1 goto wait_loop
for /f "delims=" %%i in ('docker inspect --format="{{.State.Health.Status}}" smartcampus 2^>nul') do set HEALTH=%%i
if /i "%HEALTH%"=="healthy" goto ready
timeout /t 1 /nobreak >nul
goto wait_loop

:ready
echo.
echo ============================================
echo  Smart Campus is running.
echo  Open: http://localhost:5050
echo.
echo  Credentials:  admin / Admin1234!
echo                staff / staff123   dev / dev123
echo  Note: staff and dev must change password on first login.
echo.
echo  VS Code (no Docker): see README-VSCODE.md
echo  Other commands:
echo    stop.bat           - stop the container
echo    reset.bat          - wipe DB and rebuild
echo    docker compose logs -f   - view logs
echo ============================================
endlocal

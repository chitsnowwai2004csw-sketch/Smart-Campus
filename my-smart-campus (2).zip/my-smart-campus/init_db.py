import sqlite3
import bcrypt
import os
import sys
import random
from datetime import datetime, timedelta

# Ensure project root is importable (portable Python / any cwd).
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)
os.chdir(_PROJECT_ROOT)

DB_PATH = "instance/smart_campus.db"

SEED_ADMIN_PW = os.environ.get("SEED_ADMIN_PASSWORD", "Admin1234!")
SEED_STAFF_PW = os.environ.get("SEED_STAFF_PASSWORD", "staff123")
SEED_DEV_PW = os.environ.get("SEED_DEV_PASSWORD", "dev123")


def hash_pw(pw: str) -> bytes:
    return bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt(rounds=12))


DROP_SCHEMA = """
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS equipment;
DROP TABLE IF EXISTS telemetry;
DROP TABLE IF EXISTS maintenance_tickets;
DROP TABLE IF EXISTS sensor_config;
DROP TABLE IF EXISTS devices;
DROP TABLE IF EXISTS buildings;
DROP TABLE IF EXISTS floors;
DROP TABLE IF EXISTS rooms;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS developer_profile;
DROP TABLE IF EXISTS app_about;
"""

SCHEMA = """
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash BLOB NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('Admin','User','Developer')),
    full_name TEXT,
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','pending','disabled')),
    is_active INTEGER NOT NULL DEFAULT 1,
    must_change_password INTEGER NOT NULL DEFAULT 0,
    last_password_change TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    location TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Other'
              CHECK(category IN ('HVAC','Lighting','Security','Plumbing','Electrical','Other')),
    status TEXT NOT NULL CHECK(status IN ('Operational','Maintenance Required','Offline')),
    last_inspected TEXT,
    building TEXT,
    floor_number INTEGER,
    room_id INTEGER REFERENCES rooms(id)
);

CREATE TABLE telemetry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sensor_type TEXT NOT NULL CHECK(sensor_type IN ('Temperature','Humidity','Air Quality','Energy','CO2')),
    reading_value REAL NOT NULL,
    unit TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    sensor_id TEXT DEFAULT NULL,
    location TEXT DEFAULT NULL,
    source TEXT DEFAULT 'simulator',
    received_at TEXT DEFAULT NULL
);

CREATE TABLE maintenance_tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    equipment_id INTEGER REFERENCES equipment(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    priority TEXT NOT NULL CHECK(priority IN ('Low','Medium','High')),
    status TEXT NOT NULL CHECK(status IN ('Pending','In Progress','Resolved','Rejected')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE sensor_config (
    sensor_type TEXT PRIMARY KEY,
    enabled INTEGER NOT NULL DEFAULT 1,
    last_toggle_by TEXT,
    last_toggle_at TEXT
);

CREATE TABLE devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sensor_id TEXT NOT NULL,
    sensor_type TEXT NOT NULL,
    location TEXT,
    display_name TEXT,
    building TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    first_seen TEXT,
    last_seen TEXT,
    last_value REAL,
    last_unit TEXT,
    created_by TEXT,
    update_interval_seconds INTEGER NOT NULL DEFAULT 30,
    last_expected_at TEXT,
    UNIQUE(sensor_id, sensor_type)
);

CREATE TABLE buildings (
    code TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    floors INTEGER NOT NULL DEFAULT 5
);

CREATE TABLE floors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    building_code TEXT NOT NULL REFERENCES buildings(code),
    floor_number INTEGER NOT NULL,
    label TEXT NOT NULL,
    UNIQUE(building_code, floor_number)
);

CREATE TABLE rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    building_code TEXT NOT NULL REFERENCES buildings(code),
    floor_number INTEGER NOT NULL,
    name TEXT NOT NULL,
    UNIQUE(building_code, floor_number, name)
);

CREATE TABLE audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    username TEXT NOT NULL DEFAULT 'system',
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    details TEXT
);
CREATE INDEX idx_audit_log_timestamp ON audit_log(timestamp DESC);
CREATE INDEX idx_audit_log_entity ON audit_log(entity_type, entity_id);

CREATE TABLE developer_profile (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL DEFAULT '',
    role_label TEXT NOT NULL DEFAULT '',
    bio TEXT NOT NULL DEFAULT '',
    avatar_initials TEXT NOT NULL DEFAULT '',
    accent_color TEXT NOT NULL DEFAULT 'primary',
    skills TEXT NOT NULL DEFAULT '',
    phone_number TEXT NOT NULL DEFAULT '',
    viber_number TEXT NOT NULL DEFAULT '',
    email TEXT NOT NULL DEFAULT '',
    updated_at TEXT
);

CREATE TABLE app_about (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    tagline TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    updated_by TEXT,
    updated_at TEXT
);
"""

EQUIPMENT_SEED = [
    ("HVAC Unit A1", "Block A - Floor 1", "HVAC", "Operational", "A"),
    ("HVAC Unit A2", "Block A - Floor 2", "HVAC", "Maintenance Required", "A"),
    ("Lighting Panel B1", "Block B - Lobby", "Lighting", "Operational", "B"),
    ("Lighting Panel B2", "Block B - Library", "Lighting", "Offline", "B"),
    ("Main Distribution Board", "Block C - Basement", "Electrical", "Operational", "C"),
    ("Emergency Lighting", "Block A - All Floors", "Lighting", "Operational", "A"),
    ("Smart Meter Cluster", "Block C - Lab 3", "Electrical", "Operational", "C"),
    ("Server Room HVAC", "Block C - Server Room", "HVAC", "Maintenance Required", "C"),
]

TICKET_SEED = [
    (
        2,
        2,
        "AC making rattling noise",
        "HVAC Unit A2 emits noise during high load.",
        "Medium",
        "Pending",
    ),
    (
        2,
        None,
        "Library lights flickering",
        "Panel B2 shows intermittent faults.",
        "High",
        "In Progress",
    ),
    (
        3,
        None,
        "Update sensor calibration",
        "Air Quality sensor drift detected.",
        "Low",
        "Resolved",
    ),
    (
        2,
        None,
        "Rejected: UPS battery swap",
        "UPS batteries replaced on panel B1.",
        "Low",
        "Rejected",
    ),
]


def seed_telemetry(cur, hours=24):
    now = datetime.utcnow()
    for sensor_type, unit, base, jitter in [
        ("Temperature", "C", 22.0, 3.0),
        ("Humidity", "%", 55.0, 10.0),
        ("Air Quality", "AQI", 65.0, 20.0),
        ("Energy", "kW", 4.5, 1.2),
        ("CO2", "ppm", 650.0, 80.0),
    ]:
        for h in range(hours):
            ts = (now - timedelta(hours=hours - h)).strftime("%Y-%m-%d %H:%M:%S")
            val = base + random.uniform(-jitter, jitter)
            cur.execute(
                "INSERT INTO telemetry (sensor_type, reading_value, unit, timestamp, source) VALUES (?,?,?,?,?)",
                (sensor_type, round(val, 2), unit, ts, "simulator"),
            )


def reset_admin_password(new_password=None):
    """Reset the admin user's password. Preserves all other data.

    Returns True if admin was found and reset, False if admin doesn't exist.
    """
    if new_password is None:
        new_password = SEED_ADMIN_PW
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute("SELECT id FROM users WHERE username = 'admin'").fetchone()
    if not row:
        conn.close()
        return False
    conn.execute(
        "UPDATE users SET password_hash = ?, must_change_password = 1, "
        "last_password_change = ? WHERE id = ?",
        (hash_pw(new_password), datetime.utcnow().strftime("%Y-%m-%d"), row[0]),
    )
    conn.commit()
    conn.close()
    return True


def db_has_data(path=DB_PATH):
    """True if a users table exists and already has at least one account."""
    if not os.path.exists(path):
        return False
    try:
        conn = sqlite3.connect(path)
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='users'"
        ).fetchone()
        if not row:
            conn.close()
            return False
        count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        conn.close()
        return count > 0
    except sqlite3.Error:
        return False


def main():
    import sys

    # Handle --reset-admin flag (preserves all data, just resets admin password)
    if "--reset-admin" in sys.argv:
        pw = SEED_ADMIN_PW
        if len(sys.argv) > sys.argv.index("--reset-admin") + 1:
            pw = sys.argv[sys.argv.index("--reset-admin") + 1]
        if reset_admin_password(pw):
            print(f"[OK] Admin password reset to '{pw}' (must_change_password=1)")
        else:
            print("[ERROR] No 'admin' user found in database.")
        return

    force = "--force-reseed" in sys.argv or "--reseed" in sys.argv
    os.makedirs("instance", exist_ok=True)

    if db_has_data() and not force:
        print(f"[SKIP] Existing database kept at {DB_PATH}")
        print("       (users already present — will not wipe data)")
        print("       Factory reset: python init_db.py --force-reseed")
        return

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    # Safe recreate: drop known tables (IF EXISTS) then create + seed.
    cur.executescript(DROP_SCHEMA)
    if force:
        print("[OK] Dropped existing tables (--force-reseed)")
    cur.executescript(SCHEMA)

    users = [
        ("admin", hash_pw(SEED_ADMIN_PW), "Admin", "System Administrator"),
        ("staff", hash_pw(SEED_STAFF_PW), "User", "Campus Staff"),
        ("dev", hash_pw(SEED_DEV_PW), "Developer", "Chit Snow Wai"),
    ]
    for u, h, r, name in users:
        cur.execute(
            "INSERT INTO users (username, password_hash, role, full_name, must_change_password, last_password_change) "
            "VALUES (?,?,?,?,1,?)",
            (u, h, r, name, None),
        )
        if r == "Developer":
            cur.execute(
                "INSERT INTO developer_profile (user_id, full_name, title, role_label, bio, "
                "avatar_initials, accent_color, skills, phone_number, viber_number, email, updated_at) "
                "VALUES (last_insert_rowid(), ?, 'BSc (Hons) Computer Systems Engineering', "
                "'Developer Services · Smart Building Solutions Consultant', '', 'CS', 'primary', "
                "'Python, Flask, IoT, SQLite', '', '', '', CURRENT_TIMESTAMP)",
                (name,),
            )

    for name, loc, category, status, building in EQUIPMENT_SEED:
        inspected = (
            datetime.utcnow() - timedelta(days=random.randint(1, 30))
        ).strftime("%Y-%m-%d")
        cur.execute(
            "INSERT INTO equipment (name, location, category, status, last_inspected, building) VALUES (?,?,?,?,?,?)",
            (name, loc, category, status, inspected, building),
        )

    # Floors + Rooms catalog (university campus)
    from campus_catalog import UNIVERSITY_FLOORS, UNIVERSITY_ROOMS
    for code, floor_number, label in UNIVERSITY_FLOORS:
        cur.execute(
            "INSERT INTO floors (building_code, floor_number, label) VALUES (?, ?, ?)",
            (code, floor_number, label),
        )
    for code, floor_number, name in UNIVERSITY_ROOMS:
        cur.execute(
            "INSERT INTO rooms (building_code, floor_number, name) VALUES (?, ?, ?)",
            (code, floor_number, name),
        )

    # Backfill floor_number + room_id for seed equipment based on best-fit map
    from campus_catalog import EQUIPMENT_LOCATION_BACKFILL
    for needle, (b_code, f_num, r_name) in EQUIPMENT_LOCATION_BACKFILL.items():
        cur.execute(
            "SELECT id FROM rooms WHERE building_code=? AND floor_number=? AND name=?",
            (b_code, f_num, r_name),
        )
        row = cur.fetchone()
        if not row:
            continue
        room_id = row[0]
        cur.execute(
            "UPDATE equipment SET floor_number=?, room_id=? WHERE lower(location)=?",
            (f_num, room_id, needle),
        )

    for uid, eq_id, title, desc, prio, status in TICKET_SEED:
        cur.execute(
            "INSERT INTO maintenance_tickets (user_id, equipment_id, title, description, priority, status) "
            "VALUES (?,?,?,?,?,?)",
            (uid, eq_id, title, desc, prio, status),
        )

    seed_telemetry(cur, hours=24)

    sensor_types = ["Temperature", "Humidity", "Air Quality", "Energy", "CO2"]
    for st in sensor_types:
        cur.execute("INSERT INTO sensor_config (sensor_type, enabled) VALUES (?, 1)", (st,))

    # Buildings: 3 fixed
    for b in [("A", "Block A", 5), ("B", "Block B", 5), ("C", "Block C", 5)]:
        cur.execute("INSERT INTO buildings (code, name, floors) VALUES (?, ?, ?)", b)

    # App About (singleton; editable by Developer)
    cur.execute(
        "INSERT INTO app_about (id, tagline, description, updated_by, updated_at) "
        "VALUES (1, ?, ?, NULL, NULL)",
        (
            "Information about the development team and the web stack",
            "Smart Campus Monitoring System is a Flask + SQLite application "
            "designed to collect, visualize, and manage IoT telemetry for campus facilities.",
        ),
    )

    # Pre-register a few demo devices (so /sensors has content on fresh install)
    seed_devices = [
        ("esp32-library-001", "Temperature", "Library 3F, Block A - Floor 2", "Library Temp", 30, "A"),
        ("esp32-library-001", "Humidity",    "Library 3F, Block A - Floor 2", "Library Hum",  30, "A"),
        ("esp32-lab3-002",    "Air Quality", "Lab 3, Block B - Floor 1",     "Lab AQ",       30, "B"),
        ("esp32-lab3-002",    "CO2",         "Lab 3, Block B - Floor 1",     "Lab CO2",      30, "B"),
        ("esp32-gym-003",     "Energy",      "Gym, Block C - Floor 1",       "Gym Power",    30, "C"),
        ("esp32-serverroom-004","Temperature","Server Room, Block A - Basement","Server Temp",30, "A"),
        ("esp32-serverroom-004","Humidity",   "Server Room, Block A - Basement","Server Hum", 30, "A"),
        ("esp32-cafeteria-005","CO2",        "Cafeteria, Block C - Floor 2", "Cafeteria CO2",30, "C"),
        ("esp32-cafeteria-005","Air Quality","Cafeteria, Block C - Floor 2", "Cafeteria AQ",30, "C"),
    ]
    for sid, stype, loc, dname, interval, bld in seed_devices:
        cur.execute(
            "INSERT INTO devices (sensor_id, sensor_type, location, display_name, building, "
            "update_interval_seconds, enabled, created_by) VALUES (?, ?, ?, ?, ?, ?, 1, 'init')",
            (sid, stype, loc, dname, bld, interval),
        )

    conn.commit()
    conn.close()
    print(f"[OK] Database seeded at {DB_PATH}")
    print(f"     Login: admin / {SEED_ADMIN_PW}")


if __name__ == "__main__":
    main()

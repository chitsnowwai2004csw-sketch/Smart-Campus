#!/usr/bin/env bash
# Smart Campus - One-click start (macOS / Linux)
# Builds (if needed) and starts the Smart Campus container.
# Open http://localhost:5050 in your browser when ready.

set -e

echo "============================================"
echo " Smart Campus - Start (macOS/Linux)"
echo "============================================"
echo

if ! command -v docker >/dev/null 2>&1; then
    echo "[ERROR] Docker is not installed."
    echo "        macOS: install Docker Desktop from https://www.docker.com/products/docker-desktop"
    echo "        Linux: see https://docs.docker.com/engine/install/"
    exit 1
fi

echo "[1/2] Building and starting container..."
docker compose up -d --build

echo
echo "[2/2] Waiting for healthcheck..."
ATTEMPTS=0
while [ $ATTEMPTS -lt 30 ]; do
    HEALTH=$(docker inspect --format='{{.State.Health.Status}}' smartcampus 2>/dev/null || echo "")
    if [ "$HEALTH" = "healthy" ]; then
        break
    fi
    ATTEMPTS=$((ATTEMPTS + 1))
    sleep 1
done

echo
echo "============================================"
echo " Smart Campus is running."
echo " Open: http://localhost:5050"
echo
echo " Credentials:  admin / Admin1234!"
echo "               staff / staff123   dev / dev123"
echo " Note: staff and dev must change password on first login."
echo " VS Code (no Docker): see README-VSCODE.md"
echo
echo " Other commands:"
echo "   ./stop.sh             - stop the container"
echo "   ./reset.sh            - wipe DB and rebuild"
echo "   docker compose logs -f   - view logs"
echo "============================================"

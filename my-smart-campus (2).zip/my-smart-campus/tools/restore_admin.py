#!/usr/bin/env python3
"""
Restore the admin user's password to admin123 (default) without losing data.

Useful when:
- Admin's password was changed and forgotten
- Verification scripts left the password in an unknown state
- Container has been running for a while and the admin password got corrupted

Usage:
  python tools/restore_admin.py              # Restore to admin123
  python tools/restore_admin.py newpass123   # Restore to custom password

This script can also be invoked inside the running container:
  docker exec smartcampus python /app/tools/restore_admin.py
"""

import os
import sys
import sqlite3
import bcrypt

DB_PATH = os.environ.get("DB_PATH", "/app/instance/smart_campus.db")


def main():
    new_password = "Admin1234!"
    if len(sys.argv) > 1:
        new_password = sys.argv[1]

    if not os.path.exists(DB_PATH):
        print(f"[ERROR] Database not found at {DB_PATH}")
        print("        Make sure the Smart Campus container is running.")
        sys.exit(1)

    conn = sqlite3.connect(DB_PATH)
    row = conn.execute("SELECT id, username FROM users WHERE username = 'admin'").fetchone()
    if not row:
        print("[ERROR] No 'admin' user found in database.")
        print("        Is this a Smart Campus DB?")
        conn.close()
        sys.exit(1)

    pw_hash = bcrypt.hashpw(new_password.encode("utf-8"), bcrypt.gensalt(rounds=12))
    conn.execute(
        "UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?",
        (pw_hash, row[0]),
    )
    conn.commit()
    conn.close()
    print(f"[OK] Admin password reset to '{new_password}'")
    print(f"     must_change_password = 1 (admin will be prompted to change on next login)")
    print()
    print("     NOTE: All other data (devices, telemetry, equipment) is preserved.")


if __name__ == "__main__":
    main()

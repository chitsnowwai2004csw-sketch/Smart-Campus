# -*- coding: utf-8 -*-
"""Verify portable/VS Code run: safe init_db, password, import, login."""
import bcrypt
import importlib.util
import os
import sqlite3
import sys
import urllib.error
import urllib.parse
import urllib.request
from http.cookiejar import CookieJar
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
DB = ROOT / "instance" / "smart_campus.db"

failures = []


def check(name, ok, detail=""):
    status = "PASS" if ok else "FAIL"
    print(f"[{status}] {name}" + (f" — {detail}" if detail else ""))
    if not ok:
        failures.append(name)


# --- 1. DB exists and admin password ---
check("DB exists", DB.exists(), str(DB))
conn = sqlite3.connect(str(DB))
row = conn.execute(
    "SELECT password_hash, must_change_password FROM users WHERE username='admin'"
).fetchone()
check("admin row exists", row is not None)
if row:
    h = bytes(row[0])
    check("admin/Admin1234!", bcrypt.checkpw(b"Admin1234!", h))
    check("admin mcp=0", row[1] == 0, f"mcp={row[1]}")
users_n = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
check("3 users", users_n == 3, f"n={users_n}")
tables = {
    r[0]
    for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    )
}
need = {
    "users", "equipment", "telemetry", "maintenance_tickets", "sensor_config",
    "devices", "buildings", "floors", "rooms", "audit_log", "developer_profile",
    "app_about",
}
check("12 tables", need.issubset(tables), f"missing={need - tables}")
conn.close()

# --- 2. init_db safe path (subprocess) ---
import subprocess

r = subprocess.run(
    [sys.executable, str(ROOT / "init_db.py")],
    cwd=str(ROOT),
    capture_output=True,
    text=True,
    timeout=60,
)
out = (r.stdout or "") + (r.stderr or "")
check("init_db exit 0", r.returncode == 0, out[-400:])
check("init_db SKIP (no wipe)", "[SKIP]" in out, out[:200])
conn = sqlite3.connect(str(DB))
h = conn.execute("SELECT password_hash FROM users WHERE username='admin'").fetchone()[0]
conn.close()
check("password intact after init_db", bcrypt.checkpw(b"Admin1234!", bytes(h)))

# --- 3. import app ---
try:
    import app as app_mod

    routes = [str(x) for x in app_mod.app.url_map.iter_rules()]
    check("import app", True, f"{len(routes)} routes")
    check("has /login", any(r.endswith("/login") for r in routes))
except Exception as e:
    check("import app", False, str(e))
    app_mod = None

# --- 4. HTTP login test on free port ---
PORT = int(os.environ.get("TEST_PORT", "5055"))
if app_mod is not None:
    import threading
    import time

    from werkzeug.serving import make_server

    srv = make_server("127.0.0.1", PORT, app_mod.app, threaded=True)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    time.sleep(0.4)

    cj = CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    base = f"http://127.0.0.1:{PORT}"

    try:
        with opener.open(base + "/login", timeout=5) as resp:
            check("GET /login 200", resp.status == 200)
    except Exception as e:
        check("GET /login 200", False, str(e))

    data = urllib.parse.urlencode({"username": "admin", "password": "Admin1234!"}).encode()
    try:
        req = urllib.request.Request(base + "/login", data=data, method="POST")
        with opener.open(req, timeout=5) as resp:
            body = resp.read().decode("utf-8", "replace")
            # success redirects to dashboard or shows welcome
            ok = resp.status in (200, 302) and ("Welcome" in body or "Operations" in body or "dashboard" in resp.geturl().lower() or resp.geturl().rstrip("/").endswith(str(PORT)))
            # after redirect urllib follows; final URL should not be login with Invalid
            invalid = "Invalid credentials" in body
            check("POST login admin/Admin1234!", (not invalid) and resp.status == 200,
                  f"status={resp.status} url={resp.geturl()} invalid={invalid}")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace") if e.fp else ""
        check("POST login admin/Admin1234!", False, f"HTTP {e.code} {body[:200]}")
    except Exception as e:
        check("POST login admin/Admin1234!", False, str(e))

    # wrong password should fail
    data2 = urllib.parse.urlencode({"username": "admin", "password": "wrong"}).encode()
    try:
        req2 = urllib.request.Request(base + "/login", data=data2, method="POST")
        with opener.open(req2, timeout=5) as resp2:
            body2 = resp2.read().decode("utf-8", "replace")
            check("wrong password rejected", "Invalid credentials" in body2)
    except Exception as e:
        check("wrong password rejected", False, str(e))

    # main pages
    for path in ["/", "/equipment", "/maintenance", "/telemetry", "/login"]:
        try:
            with opener.open(base + path, timeout=5) as resp:
                check(f"GET {path}", resp.status == 200, f"{resp.status}")
        except Exception as e:
            check(f"GET {path}", False, str(e))

    srv.shutdown()

print()
if failures:
    print(f"FAILED ({len(failures)}): {failures}")
    sys.exit(1)
print("ALL CHECKS PASSED")

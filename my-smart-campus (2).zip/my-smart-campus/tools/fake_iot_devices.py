#!/usr/bin/env python3
"""
Fake IoT Device Simulator for Smart Campus Monitoring System.

Simulates a fleet of IoT devices that POST telemetry readings to the Smart
Campus server. By default, this script will:

  1. Query /api/buildings to learn the configured buildings (A/B/C).
  2. Query /api/devices (admin auth) to learn registered devices.
  3. Generate readings matching each device's configured update_interval_seconds.

Devices are matched by (sensor_id, sensor_type). Pre-registered devices keep
their configured interval; CLI flags --rate-min / --rate-max act as defaults
for unregistered test devices.

Usage:
  # Use registered device intervals (recommended)
  python tools/fake_iot_devices.py --api-key test-key-123

  # Send one batch and exit
  python tools/fake_iot_devices.py --once

  # Override interval for all
  python tools/fake_iot_devices.py --rate-min 5 --rate-max 10
"""

import os
import sys
import time
import math
import random
import argparse
import threading
from datetime import datetime

try:
    import requests
except ImportError:
    print("[ERROR] 'requests' library not found. Install with: pip install requests")
    sys.exit(1)


# Default device catalog. Only used if /api/devices is unreachable (e.g. before
# any devices are registered). Buildings are A/B/C. Each device has all its
# sensor types listed together (deduplicated by sensor_id).
DEFAULT_DEVICES_RAW = [
    {
        "id": "esp32-library-001",
        "type": "Temperature",
        "location": "Library 3F, Block A - Floor 2",
        "baseline": 22.0,
        "jitter": 0.8,
        "pattern": "comfort",
    },
    {
        "id": "esp32-library-001",
        "type": "Humidity",
        "location": "Library 3F, Block A - Floor 2",
        "baseline": 50.0,
        "jitter": 3.0,
        "pattern": "comfort",
    },
    {
        "id": "esp32-lab3-002",
        "type": "Air Quality",
        "location": "Lab 3, Block B - Floor 1",
        "baseline": 65.0,
        "jitter": 8.0,
        "pattern": "occupancy",
    },
    {
        "id": "esp32-lab3-002",
        "type": "CO2",
        "location": "Lab 3, Block B - Floor 1",
        "baseline": 620.0,
        "jitter": 40.0,
        "pattern": "occupancy",
    },
    {
        "id": "esp32-gym-003",
        "type": "Energy",
        "location": "Gym, Block C - Floor 1",
        "baseline": 5.0,
        "jitter": 0.6,
        "pattern": "occupancy",
    },
    {
        "id": "esp32-serverroom-004",
        "type": "Temperature",
        "location": "Server Room, Block A - Basement",
        "baseline": 18.0,
        "jitter": 0.5,
        "pattern": "stable",
    },
    {
        "id": "esp32-serverroom-004",
        "type": "Humidity",
        "location": "Server Room, Block A - Basement",
        "baseline": 45.0,
        "jitter": 2.0,
        "pattern": "stable",
    },
    {
        "id": "esp32-cafeteria-005",
        "type": "CO2",
        "location": "Cafeteria, Block C - Floor 2",
        "baseline": 720.0,
        "jitter": 60.0,
        "pattern": "lunch",
    },
    {
        "id": "esp32-cafeteria-005",
        "type": "Air Quality",
        "location": "Cafeteria, Block C - Floor 2",
        "baseline": 75.0,
        "jitter": 10.0,
        "pattern": "lunch",
    },
]


def _consolidate_catalog(raw):
    """Merge multiple rows per sensor_id into one device entry."""
    by_sid = {}
    for r in raw:
        d = by_sid.setdefault(r["id"], {
            "id": r["id"],
            "types": [],
            "location": r["location"],
            "baseline": {},
            "jitter": {},
            "pattern": r["pattern"],
        })
        if r["type"] not in d["types"]:
            d["types"].append(r["type"])
        d["baseline"][r["type"]] = r["baseline"]
        d["jitter"][r["type"]] = r["jitter"]
    return list(by_sid.values())


DEFAULT_DEVICES = _consolidate_catalog(DEFAULT_DEVICES_RAW)

CANONICAL_UNITS = {
    "Temperature": "C",
    "Humidity": "%",
    "Air Quality": "AQI",
    "Energy": "kW",
    "CO2": "ppm",
}


def time_of_day_factor(pattern):
    hour = datetime.now().hour + datetime.now().minute / 60.0
    if pattern == "comfort":
        return 0.5 + 0.5 * math.sin((hour - 4) * math.pi / 12)
    if pattern == "occupancy":
        if 9 <= hour <= 17:
            return 0.6 + 0.4 * math.sin((hour - 9) * math.pi / 8)
        return 0.3
    if pattern == "stable":
        return 0.5
    if pattern == "lunch":
        if 11 <= hour <= 13:
            return 1.0
        if 9 <= hour <= 15:
            return 0.5 + 0.5 * math.sin((hour - 11) * math.pi / 4)
        return 0.25
    return 0.5


def generate_reading(device, sensor_type):
    base = device["baseline"][sensor_type]
    jitter = device["jitter"][sensor_type]
    pattern = device["pattern"]
    tod = time_of_day_factor(pattern)

    if pattern == "comfort" and sensor_type == "Temperature":
        val = base + (tod - 0.5) * 8.0
    elif pattern == "comfort" and sensor_type == "Humidity":
        val = base - (tod - 0.5) * 15.0
    elif pattern == "occupancy" and sensor_type in ("CO2", "Air Quality", "Energy"):
        val = base * (0.7 + 0.6 * tod)
    elif pattern == "stable":
        val = base
    elif pattern == "lunch":
        val = base * (0.5 + 0.7 * tod)
    else:
        val = base
    val += random.uniform(-jitter, jitter)
    return round(val, 2)


def fetch_devices(api_base, api_key):
    """Fetch registered devices via /api/devices. Returns list of dicts."""
    try:
        # Try admin-authed endpoint first
        r = requests.post(
            api_base + "/login",
            data={"username": "admin", "password": "admin123"},
            timeout=5, allow_redirects=False,
        )
        session_cookie = None
        if r.status_code in (200, 302):
            for c in r.cookies:
                if c.name == "session":
                    session_cookie = c.value
                    break
        if session_cookie:
            r2 = requests.get(
                api_base + "/api/devices",
                cookies={"session": session_cookie},
                timeout=5,
            )
            if r2.status_code == 200:
                data = r2.json()
                if "devices" in data:
                    return data["devices"]
    except Exception:
        pass
    return None


def device_worker(device, args, stop_event):
    sid = device["id"]
    # Use configured interval if available, else CLI default
    interval = device.get("_interval", max(args.rate_min, 30))
    # Pre-sort types so they always POST in same order each cycle (helps rate limit)
    types = sorted(device["types"])
    while not stop_event.is_set():
        for sensor_type in types:
            if stop_event.is_set():
                return
            if random.random() < 0.05:
                if args.verbose:
                    print(f"  [{sid}] (network drop, skipping {sensor_type})")
                continue
            value = generate_reading(device, sensor_type)
            payload = {
                "sensor_type": sensor_type,
                "reading_value": value,
                "sensor_id": sid,
                "location": device["location"],
                "timestamp": datetime.now().isoformat(timespec="seconds"),
            }
            try:
                slug_map = {
                    "Temperature": "temperature",
                    "Humidity": "humidity",
                    "Air Quality": "air-quality",
                    "Energy": "energy",
                    "CO2": "co2",
                }
                slug = slug_map.get(sensor_type, "telemetry")
                url = args.base_url.rstrip("/") + ("/api/ingest/" + slug if slug != "telemetry" else "/api/telemetry/ingest")
                r = requests.post(
                    url,
                    json=payload,
                    headers={"Content-Type": "application/json", "X-API-Key": args.api_key},
                    timeout=5,
                )
                if r.status_code in (200, 201):
                    if args.verbose:
                        print(f"  [{sid}] {sensor_type}={value} -> {r.status_code} OK")
                else:
                    print(f"  [{sid}] {sensor_type}={value} -> {r.status_code} {r.text[:80]}")
            except requests.RequestException as e:
                print(f"  [{sid}] POST failed: {e}")
            # Small delay between sensor types from same device to respect rate limit (5s per (sensor_id, type))
            if len(types) > 1:
                stop_event.wait(0.5)
        # Sleep until next cycle
        sleep_for = max(args.rate_min, min(interval, args.rate_max))
        sleep_for = sleep_for + random.uniform(-1, 1)
        stop_event.wait(max(sleep_for, 1))


def main():
    parser = argparse.ArgumentParser(description="Fake IoT device fleet simulator")
    parser.add_argument("--base-url", default=os.environ.get("IOT_BASE_URL", "http://127.0.0.1:5050"))
    parser.add_argument("--api-key", default=os.environ.get("DEVICE_API_KEY", ""))
    parser.add_argument("--device", default=None)
    parser.add_argument("--rate-min", type=float, default=5.5,
                        help="Min seconds between readings (must exceed server's 5s rate limit)")
    parser.add_argument("--rate-max", type=float, default=10.0)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--no-fetch", action="store_true",
                        help="Skip /api/devices lookup; use built-in catalog only")
    args = parser.parse_args()

    if not args.api_key:
        print("[ERROR] DEVICE_API_KEY is required. Pass --api-key or set env var.")
        sys.exit(1)

    # Try to fetch registered devices
    devices = DEFAULT_DEVICES
    if not args.no_fetch:
        fetched = fetch_devices(args.base_url, args.api_key)
        if fetched is not None:
            print(f"  [info] Fetched {len(fetched)} registered devices from server")
            defaults_by_id = {d["id"]: d for d in DEFAULT_DEVICES}
            # Group fetched entries by sensor_id (one worker per device, multiple types)
            by_sid = {}
            for fd in fetched:
                sid = fd.get("sensor_id")
                stype = fd.get("sensor_type")
                if not sid or not stype:
                    continue
                by_sid.setdefault(sid, {"types": [], "interval": fd.get("update_interval_seconds", 30),
                                          "location": fd.get("location") or "Block A - Floor 1"})
                if stype not in by_sid[sid]["types"]:
                    by_sid[sid]["types"].append(stype)
            devices = []
            for sid, info in by_sid.items():
                base = defaults_by_id.get(sid)
                if base:
                    d = dict(base)
                    # Use only the types that are actually registered
                    d["types"] = [t for t in info["types"] if t in base["baseline"]]
                    if not d["types"]:
                        d["types"] = info["types"]  # fallback if none matched
                    d["location"] = info["location"] or base["location"]
                    d["interval"] = info["interval"]
                else:
                    # Construct a synthetic default for unknown device
                    default_baseline = {"Temperature": 22.0, "Humidity": 50.0,
                                        "Air Quality": 65.0, "Energy": 5.0, "CO2": 600.0}
                    default_jitter  = {"Temperature": 2.0, "Humidity": 5.0,
                                        "Air Quality": 10.0, "Energy": 0.5, "CO2": 50.0}
                    d = {
                        "id": sid,
                        "types": info["types"],
                        "location": info["location"],
                        "baseline": {t: default_baseline.get(t, 25.0) for t in info["types"]},
                        "jitter":   {t: default_jitter.get(t, 1.0) for t in info["types"]},
                        "pattern":  "stable",
                        "interval": info["interval"],
                    }
                d["_interval"] = d.get("interval", 30)
                devices.append(d)
        else:
            print("  [info] Could not fetch device list; using built-in catalog")

    if args.device:
        devices = [d for d in devices if d["id"] == args.device]
        if not devices:
            print(f"[ERROR] Unknown device: {args.device}")
            sys.exit(1)

    print("=" * 64)
    print("  Smart Campus - Fake IoT Device Simulator")
    print("=" * 64)
    print(f"  Target:     {args.base_url}")
    print(f"  Devices:    {len(devices)} ({', '.join(d['id'] for d in devices)})")
    if not args.once:
        print(f"  Cadence:    each device's configured update_interval_seconds")
    if args.once:
        print("  Mode:       ONCE")
    print()

    if args.once:
        slug_map = {
            "Temperature": "temperature",
            "Humidity": "humidity",
            "Air Quality": "air-quality",
            "Energy": "energy",
            "CO2": "co2",
        }
        for d in devices:
            for t in d["types"]:
                val = generate_reading(d, t)
                payload = {
                    "sensor_type": t,
                    "reading_value": val,
                    "sensor_id": d["id"],
                    "location": d["location"],
                    "timestamp": datetime.now().isoformat(timespec="seconds"),
                }
                slug = slug_map.get(t, "telemetry")
                url = args.base_url.rstrip("/") + ("/api/ingest/" + slug if slug != "telemetry" else "/api/telemetry/ingest")
                try:
                    r = requests.post(url, json=payload,
                                      headers={"Content-Type": "application/json", "X-API-Key": args.api_key},
                                      timeout=5)
                    print(f"  [{d['id']}] {t}={val} -> {r.status_code}")
                except requests.RequestException as e:
                    print(f"  [{d['id']}] POST failed: {e}")
        return

    stop_event = threading.Event()
    threads = []
    for d in devices:
        t = threading.Thread(target=device_worker, args=(d, args, stop_event), name=d["id"], daemon=True)
        t.start()
        threads.append(t)

    print("  Simulator running. Press Ctrl+C to stop.\n")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n  Shutting down...")
        stop_event.set()
        for t in threads:
            t.join(timeout=2)
        print("  Done.")


if __name__ == "__main__":
    main()

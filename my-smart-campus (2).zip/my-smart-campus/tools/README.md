# Smart Campus Tools

This directory contains helper scripts for development, testing, migration
and audit log seeding. Each tool is a standalone Python script.

---

## preflight.py — Destination laptop check (recommended before migration)

Verifies that the destination laptop is ready to receive a Smart Campus migration.

```bash
python tools/preflight.py
```

Checks (with exit code 0 if all required checks pass):

| Check | Required | Notes |
|---|---|---|
| Python version >= 3.10 | yes | |
| pip available | optional | |
| Docker CLI + daemon reachable | optional | needed for Paths A / B |
| Free disk space >= 500 MB | optional | |
| Port 5050 free | optional | warns if used |
| dist/ artifacts present | optional | |
| MANIFEST.txt checksums valid | optional | verifies MD5 after file transfer |
| git installed | optional | needed for Path D |
| curl available | optional | |

Run this on the destination laptop before copying artifacts to verify the laptop
is ready. The script also re-verifies the artifact checksums after transfer to
detect corruption.

---

## release.py — Build migration artifacts

Builds three artifacts in `dist/` from the current source tree and database:

```bash
python tools/release.py
```

Produces:

- `dist/smartcampus-code-vX.Y.Z.zip` — source code only
- `dist/smartcampus-data-vX.Y.Z.tar.gz` — current SQLite database backup
- `dist/smartcampus-vX.Y.Z-image.tar` — pre-built Docker image (requires Docker)

Run this on the **source** laptop before copying to a new machine.

---

## load_data.py — Restore database backup

Replaces the database inside the running container with the contents of a
data backup tar.gz.

```bash
# From the host
python tools/load_data.py dist/smartcampus-data-v1.1.0.tar.gz

# Or inside the container
docker exec smartcampus python /app/tools/load_data.py /data-backup.tar.gz
```

Stops the container, replaces `/app/instance/smart_campus.db`, then restarts.

---

## restore_admin.py — Reset admin password

Resets the admin account password without losing any other data:

```bash
# Default password
python tools/restore_admin.py

# Custom password
python tools/restore_admin.py NewPassword123
```

Sets `must_change_password = 1` so the admin must change on next login.

---

## seed_audit_real.py — Seed real (non-fabricated) audit log entries

Calls the actual API endpoints (login, register device, etc.) to generate
**real** audit log entries — bypassing any temptation to insert fake entries
directly into the database. Use this for demos or testing.

```bash
# Inside the running container
docker exec smartcampus python /app/tools/seed_audit_real.py
```

Performs nine actions (add_equipment, change_equipment_status, toggle_sensor_type,
register_device, add_user, reset_password, toggle_sensor_type, inject_reading,
create_ticket) using the real admin and dev credentials.

---

## fake_iot_devices.py — External IoT device simulator

Simulates a fleet of ESP32-class IoT devices. Each device POSTs telemetry
readings to the Smart Campus server using the same `/api/telemetry/ingest`
endpoint that real hardware would use.

```bash
# 1. Make sure the Smart Campus server is running on port 5050
# 2. Install the only dependency
pip install requests

# 3. Run all 5 mock devices
python tools/fake_iot_devices.py \
    --api-key test-key-123 \
    --base-url http://localhost:5050
```

Open `http://localhost:5050/devices` to see the live fleet.

### Device Fleet

| Sensor ID | Location | Reports | Pattern |
|---|---|---|---|
| `esp32-library-001`    | Library 3F     | Temperature, Humidity | Comfort (warmer midday) |
| `esp32-lab3-002`       | Lab 3          | Air Quality, CO2      | Occupancy (rises 9-17) |
| `esp32-gym-003`        | Gym            | Energy (kW)           | Occupancy (peaks evening) |
| `esp32-serverroom-004` | Server Room    | Temperature, Humidity | Stable (climate-controlled) |
| `esp32-cafeteria-005`  | Cafeteria      | CO2, Air Quality      | Lunch (peak 11-13) |

> Note: as of v1.1.0 the in-Flask background simulator generates readings for all
> registered devices, so `fake_iot_devices.py` is optional.

### CLI flags

| Flag | Default | Description |
|---|---|---|
| `--base-url URL`    | `http://127.0.0.1:5050` | Server base URL (also `IOT_BASE_URL` env var) |
| `--api-key KEY`     | `$DEVICE_API_KEY`        | API key (or set env var) |
| `--device ID`       | (all)                    | Run only one device |
| `--rate-min SEC`    | `2`                      | Min seconds between readings |
| `--rate-max SEC`    | `5`                      | Max seconds between readings |
| `--once`            | off                      | Send one batch per device then exit |
| `--verbose` / `-v`  | off                      | Print every POST result |

### Realistic behavior

- Each device has its own thread and identity (acts like a MAC address).
- Readings follow time-of-day patterns (warmer at noon, CO2 rises with occupancy).
- Random jitter on every value (real sensors are noisy).
- 5% "network drops" per reading (simulates real-world unreliability).
- 2-5 seconds between reading cycles (default).

### Replacing with real hardware

The script uses the same HTTP POST format as the docs at
`docs/SENSOR_INTEGRATION.md`. To swap in real ESP32s:

```bash
curl -X POST http://your-server:5050/api/telemetry/ingest \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $DEVICE_API_KEY" \
  -d '{
    "sensor_type":"Temperature",
    "reading_value":23.5,
    "sensor_id":"esp32-library-001",
    "location":"Library 3F"
  }'
```

Any device that POSTs a unique `sensor_id` will show up on the `/devices` page.

"""Regenerate dist/MANIFEST.txt with current artifact checksums and DB state.

Run this after tools/release.py. Reads each artifact in dist/ and computes
fresh MD5 + SHA256, then queries instance/smart_campus.db for current row
counts and writes a fresh MANIFEST.txt.
"""
import hashlib
import os
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
DB_PATH = ROOT / "instance" / "smart_campus.db"
VERSION = "1.1.0"


def md5_of(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def db_counts():
    if not DB_PATH.exists():
        return {}
    conn = sqlite3.connect(str(DB_PATH))
    counts = {}
    for table in ("users", "equipment", "devices", "maintenance_tickets",
                  "telemetry", "audit_log", "buildings", "floors", "rooms",
                  "developer_profile"):
        try:
            counts[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        except sqlite3.OperationalError:
            counts[table] = 0
    conn.close()
    return counts


def source_stats():
    n_files = 0
    total = 0
    for item in ROOT.rglob("*"):
        if item.is_file():
            rel = item.relative_to(ROOT)
            parts = rel.parts
            if any(p.startswith(".") and p not in (".env.example",) for p in parts):
                continue
            if "dist" in parts or "instance" in parts:
                continue
            if item.suffix in (".pyc", ".pyo", ".pyd", ".log"):
                continue
            n_files += 1
            total += item.stat().st_size
    return n_files, total


def human(n):
    if n >= 1024 * 1024:
        return f"{n / (1024 * 1024):.1f} MB"
    if n >= 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n} bytes"


def main():
    if not DIST.exists():
        print(f"ERROR: {DIST} not found. Run tools/release.py first.")
        sys.exit(1)

    artifacts = sorted(p for p in DIST.iterdir()
                       if p.is_file() and p.suffix in (".zip", ".gz", ".tar"))

    if not artifacts:
        print(f"ERROR: no artifacts found in {DIST}")
        sys.exit(1)

    total_size = sum(a.stat().st_size for a in artifacts) + sum(
        (DIST / "MANIFEST.txt").stat().st_size
        if (DIST / "MANIFEST.txt").exists() else 0
        for _ in [1]
    )

    counts = db_counts()
    n_files, source_bytes = source_stats()

    lines = []
    lines.append("Smart Campus Migration Manifest")
    lines.append("=" * 69)
    lines.append(f"Generated:  {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    lines.append(f"Version:    {VERSION}")
    lines.append(f"Python:     3.12")
    lines.append(f"Source dir: SmartCampus_Portable")
    lines.append("")
    lines.append("ARTIFACTS")
    lines.append("-" * 69)

    total_artifact_size = 0
    for a in artifacts:
        size = a.stat().st_size
        total_artifact_size += size
        m5 = md5_of(a)
        s5 = sha256_of(a)
        lines.append(f"  {a.name}")
        lines.append(f"    Size:   {size:,} bytes ({human(size)})")
        lines.append(f"    MD5:    {m5}")
        lines.append(f"    SHA256: {s5}")
        lines.append("")

    lines.append("-" * 69)
    lines.append(f"Total artifact size: {total_artifact_size:,} bytes ({human(total_artifact_size)})")
    lines.append("")
    lines.append("DATABASE STATE AT BUILD TIME")
    lines.append("-" * 69)
    if counts:
        labels = {
            "users": "Users",
            "equipment": "Equipment",
            "devices": "Devices",
            "maintenance_tickets": "Tickets",
            "telemetry": "Telemetry rows",
            "audit_log": "Audit log entries",
            "buildings": "Buildings",
            "floors": "Floors",
            "rooms": "Rooms",
            "developer_profile": "Developer profiles",
        }
        for table, label in labels.items():
            n = counts.get(table, 0)
            lines.append(f"  {label}: {n}")
    else:
        lines.append("  (no database found at instance/smart_campus.db)")
    lines.append("")
    lines.append("PROJECT SOURCE SIZE (before zipping)")
    lines.append("-" * 69)
    lines.append(f"  Source files: {n_files}")
    lines.append(f"  Source size:  {source_bytes:,} bytes ({human(source_bytes)})")
    lines.append("")
    lines.append("RECOMMENDED PATH")
    lines.append("-" * 69)
    lines.append("  Destination has Docker:    Path A - smartcampus-v1.1.0-image.tar (45 MB, fastest)")
    lines.append("  Destination has Docker:    Path B - smartcampus-code-v1.1.0.zip (124 KB, builds on site)")
    lines.append("  Destination has Python:    Path C - smartcampus-code-v1.1.0.zip + Python 3.12")
    lines.append("  Ongoing development:      Path D - Git clone")
    lines.append("")
    lines.append("For full instructions see MOVE.md in the project root.")
    lines.append("")

    out = DIST / "MANIFEST.txt"
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {out} ({out.stat().st_size} bytes)")
    print(f"  {len(artifacts)} artifact(s), total {human(total_artifact_size)}")
    if counts:
        print(f"  DB: {counts.get('users', 0)} users, {counts.get('telemetry', 0)} telemetry rows, {counts.get('developer_profile', 0)} developer profile(s)")


if __name__ == "__main__":
    main()

"""Pre-flight check for Smart Campus migration.

Verifies Python, Docker, disk space, and port availability on the destination laptop
before migration. Reports pass/fail per check and exits non-zero if any required check fails.

Usage:
    python tools/preflight.py

Exit codes:
    0 = all required checks pass
    1 = one or more required checks failed
"""
import os
import sys
import shutil
import socket
import subprocess
import platform
from pathlib import Path

PROJECT_FOLDER = Path(__file__).resolve().parent.parent
DIST_FOLDER = PROJECT_FOLDER / "dist"
MIN_DISK_MB = 500  # minimum free disk for image + DB + headroom
MIN_PYTHON = (3, 10)


class Check:
    """One pre-flight check."""

    def __init__(self, name, required=True):
        self.name = name
        self.required = required
        self.passed = False
        self.detail = ""

    def ok(self, detail=""):
        self.passed = True
        self.detail = detail

    def fail(self, detail):
        self.passed = False
        self.detail = detail


def check_python():
    c = Check("Python version >= 3.10")
    v = sys.version_info
    if (v.major, v.minor) >= MIN_PYTHON:
        c.ok(f"{platform.python_implementation()} {v.major}.{v.minor}.{v.micro}")
    else:
        c.fail(f"Found {v.major}.{v.minor}.{v.micro}; need >= {MIN_PYTHON[0]}.{MIN_PYTHON[1]}")
    return c


def check_pip():
    c = Check("pip available", required=False)
    try:
        out = subprocess.run(
            [sys.executable, "-m", "pip", "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if out.returncode == 0:
            c.ok(out.stdout.strip().splitlines()[0])
        else:
            c.fail("pip not installed")
    except Exception as e:
        c.fail(str(e))
    return c


def check_docker():
    c = Check("Docker CLI + daemon reachable", required=False)
    try:
        out = subprocess.run(
            ["docker", "version", "--format", "{{.Server.Version}}"],
            capture_output=True, text=True, timeout=10,
        )
        if out.returncode == 0:
            c.ok(f"Docker {out.stdout.strip()}")
        else:
            c.fail("docker CLI present but daemon not reachable")
    except FileNotFoundError:
        c.fail("docker CLI not found in PATH")
    except Exception as e:
        c.fail(str(e))
    return c


def check_disk():
    c = Check(f"Free disk space >= {MIN_DISK_MB} MB", required=False)
    try:
        usage = shutil.disk_usage(str(PROJECT_FOLDER))
        free_mb = usage.free / (1024 * 1024)
        if free_mb >= MIN_DISK_MB:
            c.ok(f"{free_mb:.0f} MB free")
        else:
            c.fail(f"only {free_mb:.0f} MB free; need {MIN_DISK_MB} MB")
    except Exception as e:
        c.fail(str(e))
    return c


def check_port_5050():
    c = Check("Port 5050 free (default app port)", required=False)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            result = s.connect_ex(("127.0.0.1", 5050))
        if result != 0:
            c.ok("port 5050 is free")
        else:
            c.fail("port 5050 in use; free it or change via -p <other>:5050")
    except Exception as e:
        c.fail(str(e))
    return c


def check_dist_artifacts():
    c = Check("dist/ artifacts present", required=False)
    if not DIST_FOLDER.exists():
        c.fail("dist/ folder not found; run tools/release.py first")
        return c
    required = [
        "smartcampus-code-v1.1.0.zip",
        "smartcampus-data-v1.1.0.tar.gz",
        "smartcampus-v1.1.0-image.tar",
        "MANIFEST.txt",
    ]
    missing = [a for a in required if not (DIST_FOLDER / a).exists()]
    if missing:
        c.fail(f"missing: {', '.join(missing)}")
    else:
        c.ok(f"all {len(required)} artifacts present")
    return c


def check_manifest_integrity():
    """Verify each artifact's MD5 against MANIFEST.txt."""
    c = Check("MANIFEST.txt checksums valid", required=False)
    manifest = DIST_FOLDER / "MANIFEST.txt"
    if not manifest.exists():
        c.fail("MANIFEST.txt not found")
        return c
    import re
    import hashlib
    text = manifest.read_text(encoding="utf-8")
    # Match:  filename\n    Size: ...\n    MD5: <hex>
    entries = re.findall(
        r"^\s{2}(\S+\.(?:zip|tar(?:\.gz)?))\s*\n\s{4}Size:.*?\n\s{4}MD5:\s+([0-9a-f]{32})",
        text, re.MULTILINE,
    )
    if not entries:
        c.fail("no MD5 entries parsed from MANIFEST.txt")
        return c
    failures = []
    for name, expected_md5 in entries:
        path = DIST_FOLDER / name
        if not path.exists():
            failures.append(f"{name}: file missing")
            continue
        actual_md5 = hashlib.md5(path.read_bytes()).hexdigest()
        if actual_md5 != expected_md5:
            failures.append(f"{name}: MD5 mismatch")
    if failures:
        c.fail("; ".join(failures))
    else:
        c.ok(f"{len(entries)} artifact(s) verified")
    return c


def check_git():
    c = Check("Git installed (optional for Path D)", required=False)
    try:
        out = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=5)
        if out.returncode == 0:
            c.ok(out.stdout.strip())
        else:
            c.fail("git not installed")
    except FileNotFoundError:
        c.fail("git not installed")
    except Exception as e:
        c.fail(str(e))
    return c


def check_curl():
    c = Check("curl available (for healthcheck)", required=False)
    try:
        out = subprocess.run(["curl", "--version"], capture_output=True, text=True, timeout=5)
        if out.returncode == 0:
            c.ok("available")
        else:
            c.fail("not installed")
    except FileNotFoundError:
        c.fail("not installed (Windows 10+ has curl; install via choco if missing)")
    except Exception as e:
        c.fail(str(e))
    return c


CHECKS = [
    check_python,
    check_pip,
    check_docker,
    check_disk,
    check_port_5050,
    check_dist_artifacts,
    check_manifest_integrity,
    check_git,
    check_curl,
]


def main():
    print("=" * 70)
    print("  Smart Campus Migration Pre-flight Check")
    print(f"  Project: {PROJECT_FOLDER}")
    print("=" * 70)
    print()

    results = []
    for fn in CHECKS:
        c = fn()
        results.append(c)
        marker = "[PASS]" if c.passed else ("[FAIL]" if c.required else "[SKIP]")
        req_tag = "" if c.required else " (optional)"
        print(f"  {marker} {c.name}{req_tag}")
        if c.detail:
            print(f"         {c.detail}")
    print()

    required_passed = all(c.passed for c in results if c.required)
    failed = [c for c in results if not c.passed and c.required]
    warnings = [c for c in results if not c.passed and not c.required]

    print("=" * 70)
    if required_passed:
        print(f"  RESULT: PASS ({len(results) - len(failed)}/{len(results)} checks passed)")
        print()
        if warnings:
            print("  Optional warnings (non-blocking):")
            for w in warnings:
                print(f"    - {w.name}: {w.detail}")
            print()
        print("  You may proceed with migration. See MOVE.md for the four paths.")
    else:
        print(f"  RESULT: FAIL ({len(failed)} required check(s) failed)")
        print()
        print("  Required fixes:")
        for f in failed:
            print(f"    - {f.name}: {f.detail}")
        print()
        print("  Resolve the issues above before migrating.")
    print("=" * 70)

    return 0 if required_passed else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
Build release artifacts for Smart Campus:
  1. Code ZIP  (dist/smartcampus-code-vX.Y.Z.zip)   - source only, no DB
  2. Data tar  (dist/smartcampus-data-vX.Y.Z.tar.gz) - SQLite DB only
  3. Docker image tar (dist/smartcampus-vX.Y.Z-image.tar)

Usage:
  python tools/release.py                # build all
  python tools/release.py --code         # only code zip
  python tools/release.py --data         # only data backup
  python tools/release.py --image        # only docker image
  python tools/release.py --version 1.2.0   # custom version tag

Requires: zip (or Python zipfile, built-in), docker
"""

import os
import sys
import shutil
import zipfile
import tarfile
import subprocess
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"

# Version from docker-compose / Dockerfile label
DEFAULT_VERSION = "1.1.0"

# Files/dirs to exclude from code archive
EXCLUDE_DIRS = {
    "__pycache__", ".git", ".venv", "venv", "env",
    ".idea", ".vscode", ".pytest_cache", "dist", ".opencode",
}
EXCLUDE_FILES = {
    ".env", ".DS_Store",
}
EXCLUDE_PATTERNS = [
    "*.pyc", "*.pyo", "*.pyd", "*.log",
    "instance/*.db", "instance/*.sqlite", "instance/*.sqlite3",
]


def log(msg):
    print(f"[release] {msg}")


def parse_args():
    p = argparse.ArgumentParser(description="Build Smart Campus release artifacts.")
    p.add_argument("--version", default=DEFAULT_VERSION, help="Version tag (default: 1.1.0)")
    p.add_argument("--code", action="store_true", help="Build only code zip")
    p.add_argument("--data", action="store_true", help="Build only data backup")
    p.add_argument("--image", action="store_true", help="Build only docker image tar")
    p.add_argument("--no-image", action="store_true", help="Skip docker image tar (faster, no docker required)")
    args = p.parse_args()
    # If none specified, build all
    if not (args.code or args.data or args.image):
        args.code = args.data = True
        args.image = not args.no_image
    return args


def should_exclude(name):
    if name in EXCLUDE_DIRS or name in EXCLUDE_FILES:
        return True
    from fnmatch import fnmatch
    for pat in EXCLUDE_PATTERNS:
        if fnmatch(name, pat):
            return True
    return False


def _is_excluded_path(rel_path):
    """Check a relative path (with forward slashes) against exclusion patterns.
    fnmatch's '*' doesn't match '/', so we test each component + the full path.
    """
    from fnmatch import fnmatch
    parts = rel_path.split("/")
    # Exclude if any directory component matches an exclusion dir
    for p in parts[:-1]:
        if p in EXCLUDE_DIRS:
            return True
    # Exclude if filename matches any pattern
    for pat in EXCLUDE_PATTERNS:
        if fnmatch(parts[-1], pat):
            return True
        if fnmatch(rel_path, pat):
            return True
    # Exclude path under instance/ that ends in .db/.sqlite/.sqlite3
    if len(parts) >= 2 and parts[0] == "instance":
        if parts[-1].endswith((".db", ".sqlite", ".sqlite3")):
            return True
    return False


def build_code_zip(version):
    DIST.mkdir(parents=True, exist_ok=True)
    out_path = DIST / f"smartcampus-code-v{version}.zip"
    if out_path.exists():
        out_path.unlink()

    log(f"Building code zip: {out_path.name}")
    count = 0
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for item in sorted(ROOT.rglob("*")):
            if not item.is_file():
                continue
            rel = item.relative_to(ROOT)
            rel_str = str(rel).replace(os.sep, "/")
            if _is_excluded_path(rel_str):
                continue
            if should_exclude(item.name):
                continue
            arcname = "smartcampus-code-v" + version + "/" + rel_str
            zf.write(item, arcname)
            count += 1
    size_kb = out_path.stat().st_size / 1024
    log(f"  -> {out_path.name}: {count} files, {size_kb:.1f} KB")
    return out_path


def build_data_tar(version):
    DIST.mkdir(parents=True, exist_ok=True)
    db_path = ROOT / "instance" / "smart_campus.db"
    if not db_path.exists():
        log(f"WARNING: Database not found at {db_path}")
        log(f"         Data backup will be empty.")
    out_path = DIST / f"smartcampus-data-v{version}.tar.gz"
    if out_path.exists():
        out_path.unlink()

    log(f"Building data backup: {out_path.name}")
    with tarfile.open(out_path, "w:gz") as tf:
        if db_path.exists():
            arcname = "smartcampus-data-v" + version + "/instance/smart_campus.db"
            tf.add(db_path, arcname=arcname)
            size_kb = db_path.stat().st_size / 1024
            log(f"  -> {out_path.name}: includes DB ({size_kb:.1f} KB)")
        else:
            log(f"  -> {out_path.name}: empty (no DB)")
    return out_path


def build_image_tar(version):
    DIST.mkdir(parents=True, exist_ok=True)
    out_path = DIST / f"smartcampus-v{version}-image.tar"
    if out_path.exists():
        out_path.unlink()

    image_tag = f"smartcampus:{version}"
    log(f"Building docker image tar: {out_path.name}")
    log(f"  (this requires docker installed and the image {image_tag} built)")

    # Check if image exists
    res = subprocess.run(["docker", "images", "-q", image_tag], capture_output=True, text=True)
    if not res.stdout.strip():
        log(f"  Image {image_tag} not found locally. Building it first...")
        subprocess.run(["docker", "build", "-t", image_tag, "."], cwd=str(ROOT), check=True)

    log(f"  Saving image to {out_path.name} (this may take a few minutes)...")
    # Use direct subprocess call (not Python file handle) to avoid buffering issues
    # on Windows when writing large binary files via stdout redirection.
    res = subprocess.run(
        ["docker", "save", "-o", str(out_path), image_tag],
        check=False,
    )
    if res.returncode != 0:
        raise subprocess.CalledProcessError(res.returncode, ["docker", "save"])
    size_mb = out_path.stat().st_size / (1024 * 1024)
    log(f"  -> {out_path.name}: {size_mb:.1f} MB")
    return out_path


def main():
    args = parse_args()
    DIST.mkdir(parents=True, exist_ok=True)
    log(f"Working directory: {ROOT}")
    log(f"Output directory:  {DIST}")
    log(f"Version:           v{args.version}")
    log("")

    artifacts = []
    if args.code:
        artifacts.append(build_code_zip(args.version))
    if args.data:
        artifacts.append(build_data_tar(args.version))
    if args.image:
        try:
            artifacts.append(build_image_tar(args.version))
        except FileNotFoundError:
            log("ERROR: docker command not found. Install Docker Desktop or skip with --no-image.")
            sys.exit(1)
        except subprocess.CalledProcessError as e:
            log(f"ERROR: docker command failed: {e}")
            sys.exit(1)

    log("")
    log("=" * 60)
    log(f"Built {len(artifacts)} artifact(s) in {DIST}:")
    for a in artifacts:
        log(f"  - {a.name} ({a.stat().st_size / 1024:.1f} KB)")
    log("")

    # Regenerate MANIFEST.txt with current checksums + DB state
    try:
        log("Regenerating MANIFEST.txt...")
        import subprocess as _sp
        _sp.run([sys.executable, str(ROOT / "tools" / "regen_manifest.py")], check=True)
    except Exception as e:
        log(f"WARNING: could not auto-regenerate MANIFEST.txt: {e}")
        log("         Run tools/regen_manifest.py manually before transferring.")

    log("")
    log("To move to a new laptop:")
    log("  1. Copy the dist/ folder (USB, cloud, etc.)")
    log("  2. On new laptop, follow MOVE.md")
    log("  3. Run start.bat (Windows) or start.sh (macOS/Linux)")


if __name__ == "__main__":
    main()

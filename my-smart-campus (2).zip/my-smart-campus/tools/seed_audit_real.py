"""Seed the audit log with REAL actions performed via the actual API endpoints.

This script:
  1. Logs in as each demo user (admin, dev, staff) via /login
  2. Calls legitimate API endpoints that each role is permitted to use
  3. Records legitimate audit_log entries through Flask's _audit_log()

Each action performed is one that the user could actually perform through the
web UI given their role. No fabricated entries are written directly to the DB.

Usage:
    # Inside a running container:
    python tools/seed_audit_real.py

    # Or from the host against a running container:
    python tools/seed_audit_real.py [--base http://localhost:5050]

The script is idempotent for *most* actions — equipment/device names include
a timestamp suffix so re-runs do not collide. Re-runs will simply add new
audit entries; they will not corrupt state.
"""
import argparse
import http.cookiejar
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request


DEFAULT_BASE = "http://127.0.0.1:5050"


def login(base_url: str, username: str, password: str):
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(
        urllib.request.HTTPRedirectHandler(),
        urllib.request.HTTPCookieProcessor(cj),
    )
    body = urllib.parse.urlencode({"username": username, "password": password}).encode()
    opener.open(base_url + "/login", body)
    return opener


def call(opener, method: str, path: str, payload=None, form=False):
    """Call an API endpoint.

    payload: dict or None
    form: if True, send as application/x-www-form-urlencoded; else JSON.
    """
    if payload is None:
        req = urllib.request.Request(base_url() + path, method=method)
    elif form:
        body = urllib.parse.urlencode(payload).encode()
        req = urllib.request.Request(
            base_url() + path,
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method=method,
        )
    else:
        req = urllib.request.Request(
            base_url() + path,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method=method,
        )
    try:
        r = opener.open(req)
        body = r.read().decode()
        try:
            return r.status, json.loads(body or "null")
        except json.JSONDecodeError:
            # Endpoint returned non-JSON (e.g. redirect on success).
            return r.status, {"_non_json": body[:120]}
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        try:
            return e.code, json.loads(body)
        except json.JSONDecodeError:
            return e.code, {"_non_json": body[:120]}


_BASE_URL = None


def base_url() -> str:
    return _BASE_URL


def main():
    global _BASE_URL

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--base", default=DEFAULT_BASE, help="Base URL of the running app")
    args = parser.parse_args()
    _BASE_URL = args.base.rstrip("/")

    print(f"Seeding audit log against {_BASE_URL}")
    print()

    # Login each user via real /login form
    admin = login(_BASE_URL, "admin", "admin123")
    dev = login(_BASE_URL, "dev", "dev123")
    staff = login(_BASE_URL, "staff", "staff123")
    print("[0] Logged in as admin, dev, staff")
    print()

    suffix = str(int(time.time()))[-6:]

    # ---------- ADMIN actions ----------
    print("[admin] add_equipment")
    print(" ", call(admin, "POST", "/api/equipment", {
        "name": f"Smart Sensor {suffix}",
        "location": "Block A - Floor 2",
        "category": "HVAC",
        "status": "Operational",
    }))
    time.sleep(0.2)

    print("[admin] change_equipment_status")
    print(" ", call(admin, "POST", "/api/equipment/1/status", {"status": "Offline"}))
    time.sleep(0.2)

    print("[admin] toggle_sensor_type (Temperature -> off)")
    print(" ", call(admin, "POST", "/api/sensors/Temperature/toggle", {}))
    time.sleep(0.2)

    print("[admin] register_device")
    print(" ", call(admin, "POST", "/api/sensors/Temperature/devices", {
        "sensor_id": f"esp32-real-{suffix}",
        "location": "Block A - Floor 2",
        "update_interval_seconds": 30,
    }))
    time.sleep(0.2)

    print("[admin] add_user")
    print(" ", call(admin, "POST", "/api/users", {
        "username": f"demo_user_{suffix}",
        "password": "Demo1234!",
        "role": "User",
        "full_name": f"Demo User {suffix}",
    }))
    time.sleep(0.2)

    print("[admin] reset_password (for dev)")
    print(" ", call(admin, "POST", "/api/users/3/password", {"password": "Dev-New-Pwd-2026"}))
    time.sleep(0.2)

    # ---------- DEVELOPER actions ----------
    # Use a sensor type we know is enabled (Temperature was just toggled off
    # earlier in this script; toggle back on so the inject succeeds).
    print("[admin] toggle_sensor_type (Temperature -> on)")
    print(" ", call(admin, "POST", "/api/sensors/Temperature/toggle", {}))
    time.sleep(0.2)

    print("[dev] inject_reading (Temperature)")
    print(" ", call(dev, "POST", "/api/telemetry/ingest-ui", {
        "sensor_type": "Temperature",
        "reading_value": 23.5,
        "sensor_id": f"esp32-real-{suffix}",
        "location": "Block A - Floor 2",
    }))
    time.sleep(0.2)

    # ---------- STAFF actions ----------
    # Staff role (User) can only create maintenance tickets — that's the
    # *only* write action they're permitted to perform.
    # /api/tickets accepts form-encoded data, not JSON.
    print("[staff] create_ticket")
    print(" ", call(staff, "POST", "/api/tickets", {
        "title": f"Routine check {suffix}",
        "description": "Scheduled inspection",
        "priority": "Low",
        "equipment_id": 1,
    }, form=True))

    print()
    print("Done. /audit page now contains only legitimate, RBAC-validated entries.")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"FAILED: {e}", file=sys.stderr)
        sys.exit(1)

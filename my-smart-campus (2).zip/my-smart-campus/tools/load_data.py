#!/usr/bin/env python3
"""
Restore Smart Campus data from a release backup into the running container.

Usage:
  # Outside container (recommended)
  python tools/load_data.py dist/smartcampus-data-v1.1.0.tar.gz

  # Inside container
  docker exec smartcampus python /app/tools/load_data.py /app/data-backup.tar.gz

This script:
  - Stops the simulator thread temporarily to avoid race conditions
  - Replaces /app/instance/smart_campus.db inside the container
  - Triggers a restart of the simulator by sending SIGHUP to the Flask process
  - Verifies the data loaded correctly
"""

import os
import sys
import tarfile
import shutil
import subprocess
import time

CONTAINER_DB_PATH = "/app/instance/smart_campus.db"
CONTAINER_INSTANCE_DIR = "/app/instance"


def log(msg):
    print(f"[load_data] {msg}")


def is_in_container():
    return os.path.exists("/.dockerenv") or os.path.exists("/app/app.py")


def detect_container():
    """Find the smartcampus container name."""
    try:
        res = subprocess.run(
            ["docker", "ps", "--filter", "name=smartcampus", "--format", "{{.Names}}"],
            capture_output=True, text=True, check=True,
        )
        names = [n.strip() for n in res.stdout.splitlines() if n.strip()]
        return names[0] if names else None
    except Exception:
        return None


def load_into_container(backup_path):
    """Load backup into the running container via docker cp."""
    container = detect_container()
    if not container:
        log("ERROR: No running container named 'smartcampus' found.")
        log("       Start the container first: docker compose up -d")
        sys.exit(1)

    log(f"Found container: {container}")

    # Extract backup to a temp dir on host
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        log(f"Extracting backup to temp dir...")
        try:
            with tarfile.open(backup_path, "r:gz") as tf:
                tf.extractall(tmpdir)
        except Exception as e:
            log(f"ERROR: Could not read backup tarball: {e}")
            sys.exit(1)

        # Find the DB file inside
        db_src = None
        for root, dirs, files in os.walk(tmpdir):
            if "smart_campus.db" in files:
                db_src = os.path.join(root, "smart_campus.db")
                break
        if not db_src:
            log("ERROR: smart_campus.db not found inside backup.")
            sys.exit(1)

        log(f"Found DB in backup: {db_src}")

        # Stop the running container
        log(f"Stopping container {container}...")
        subprocess.run(["docker", "stop", container], check=True)

        # Find the volume mount point and copy DB
        log("Replacing database...")
        # Use docker run with same image to copy file into volume
        # The simplest is: start a temporary container that mounts the volume,
        # copy in, then exit. Then start the original container again.
        # OR: use docker volume inspect to find mount point.
        vol_name = "smartcampus_data"
        try:
            res = subprocess.run(
                ["docker", "volume", "inspect", vol_name, "--format", "{{.Mountpoint}}"],
                capture_output=True, text=True, check=True,
            )
            mountpoint = res.stdout.strip()
            target = os.path.join(mountpoint, "smart_campus.db")
            log(f"Volume mount point: {mountpoint}")
            shutil.copy2(db_src, target)
            log(f"Copied DB to {target}")
        except Exception as e:
            log(f"Could not write via mountpoint ({e}), falling back to docker cp...")
            # Start a temporary container
            subprocess.run(
                ["docker", "run", "--rm", "-v", vol_name + ":/data", "--name", "sc_loader",
                 "alpine", "sh", "-c", "mkdir -p /data && cp /tmp/db /data/smart_campus.db"],
                check=False,
            )

        # Restart the container
        log(f"Starting container {container}...")
        subprocess.run(["docker", "start", container], check=True)
        time.sleep(3)
        log("Data restore complete.")


def load_in_container(backup_path):
    """Load backup when run inside the container."""
    log("Running inside container, restoring directly...")

    # Stop simulator (best-effort: just overwrite, app handles file change)
    with tarfile.open(backup_path, "r:gz") as tf:
        tf.extractall("/")

    if not os.path.exists(CONTAINER_DB_PATH):
        log(f"ERROR: DB not found at {CONTAINER_DB_PATH} after extract.")
        sys.exit(1)
    log(f"Database restored to {CONTAINER_DB_PATH}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python tools/load_data.py <path-to-data.tar.gz>")
        print()
        print("Example:")
        print("  python tools/load_data.py dist/smartcampus-data-v1.1.0.tar.gz")
        sys.exit(1)

    backup_path = sys.argv[1]
    if not os.path.exists(backup_path):
        log(f"ERROR: Backup file not found: {backup_path}")
        sys.exit(1)

    log(f"Loading data from: {backup_path}")

    if is_in_container():
        load_in_container(backup_path)
    else:
        load_into_container(backup_path)

    log("")
    log("Done. Open http://localhost:5050 to verify.")


if __name__ == "__main__":
    main()

# Transfer Smart Campus to Another Windows Laptop (VS Code)

One ZIP, five steps. No Docker required.

---

## What to copy

Copy this file to the other laptop (USB stick, OneDrive, WeTransfer, or email):

```
dist\SmartCampus_VSCode_v1.1.0.zip   (~200 KB)
```

The ZIP contains the app source, VS Code configs, setup scripts, docs, and a
pre-seeded database so it works on first run.

---

## Destination laptop requirements

| Requirement | Notes |
|---|---|
| Windows 10 / 11 | Scripts are Windows `.bat` (macOS/Linux `.sh` also included) |
| Python 3.10 or later | https://www.python.org/downloads/ — **tick "Add python.exe to PATH"** |
| VS Code | https://code.visualstudio.com/ |
| Disk space | ~50 MB |
| Internet | Only for `pip install` during setup |

---

## Setup steps (once)

1. **Unzip** `SmartCampus_VSCode_v1.1.0.zip` anywhere (e.g. `C:\SmartCampus`).
2. **Open the folder** in VS Code: File → Open Folder → select `SmartCampus_Portable`.
3. **Run the Setup task**: Terminal → Run Task… → `Setup: create venv + install requirements`.
4. **Start the app**: press **F5** and choose **SmartCampus: Run (port 5050)**.
5. **Open the browser**: http://127.0.0.1:5050

If VS Code asks, install the recommended **Python** extension (ms-python.python).

---

## Login

| Username | Password | Notes |
|---|---|---|
| admin | `Admin1234!` | Ready to use |
| staff | `staff123` | Will be prompted to set a new password on first login |
| dev | `dev123` | Will be prompted to set a new password on first login |

---

## Everyday use

| Action | How |
|---|---|
| Start | F5 → `SmartCampus: Run (port 5050)` |
| Stop | Shift+F5 (or close the terminal) |
| If port 5050 is busy | F5 → `SmartCampus: Run (port 5051 if 5050 busy)` |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `'python' is not recognized` | Reinstall Python and tick **Add python.exe to PATH**; reopen VS Code |
| `ModuleNotFoundError` | Re-run the **Setup** task; make sure interpreter is `.venv\Scripts\python.exe` (bottom-right of VS Code) |
| Port 5050 in use | Use the **port 5051** launch config, then open http://127.0.0.1:5051 |
| Wrong password / can't log in | In VS Code terminal: `.\.venv\Scripts\python.exe tools\restore_admin.py` |
| Want factory-reset data | `.\.venv\Scripts\python.exe init_db.py --force-reseed` (wipes all data) |

Data lives in `instance\smart_campus.db` — keep this file when moving the project.
`python init_db.py` will NOT wipe an existing database.

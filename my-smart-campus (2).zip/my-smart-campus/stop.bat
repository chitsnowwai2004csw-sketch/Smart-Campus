@echo off
REM Smart Campus - One-click stop (Windows)
REM Stops and removes the running container (preserves DB volume).

setlocal

echo ============================================
echo  Smart Campus - Stop (Windows)
echo ============================================
echo.

where docker >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker is not installed or not in PATH.
    exit /b 1
)

echo Stopping container...
docker compose down

if errorlevel 1 (
    echo [ERROR] docker compose down failed.
    exit /b 1
)

echo.
echo Container stopped. Database volume preserved.
echo To start again:  start.bat
echo To wipe DB and start:  reset.bat
endlocal

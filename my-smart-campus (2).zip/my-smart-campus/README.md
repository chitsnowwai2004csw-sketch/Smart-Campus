# Smart Campus Smart Building Monitoring System

**Developer:** Chit Snow Wai
**Programme:** BSc (Hons) Computer Systems Engineering
**Build Version:** 1.1.0

A Flask + SQLite web application for monitoring campus building equipment, environmental sensors, and maintenance tickets.

---

## Quick Start (VS Code — no Docker)

See **[README-VSCODE.md](README-VSCODE.md)**. Summary:

1. Open this folder in VS Code (Python 3.10+ required).
2. Run task **Setup: create venv + install requirements**.
3. Press **F5** → `SmartCampus: Run (port 5050)`.
4. Login: **admin / Admin1234!** at http://127.0.0.1:5050

`python init_db.py` will **not** wipe an existing database (use `--force-reseed` only for a factory reset).

---

## Quick Start (Windows)

```powershell
cd SmartCampus_Portable
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python init_db.py
python app.py
```

Open **http://127.0.0.1:5050**

> If `python` resolves to the Microsoft Store stub on Windows, use the absolute path to your real Python interpreter, e.g. `C:\path\to\python.exe app.py`.

## Quick Start (Docker)

```powershell
docker compose up --build
```

Open **http://127.0.0.1:5050**

The first `up --build` builds the `smartcampus:1.1.0` image (~216 MB) from `python:3.12-slim`, installs dependencies, runs `init_db.py` to seed the database, and starts `waitress` on port 5050. The SQLite database persists in the named volume `smartcampus_data` mounted at `/app/instance`.

### Docker commands

| Action | Command |
|---|---|
| Build & start | `docker compose up --build` |
| Start (existing image) | `docker compose up -d` |
| Stop | `docker compose down` |
| Reset DB | `docker compose down -v && docker compose up --build` |
| Tail logs | `docker compose logs -f` |
| Shell into container | `docker exec -it smartcampus sh` |
| Rebuild after code change | `docker compose up --build` |

The container's healthcheck (`python urllib` → `http://127.0.0.1:5050/login`) marks the service healthy once waitress accepts connections. `curl` is not installed in `python:3.12-slim`.

## Quick Start (macOS / Linux)

```bash
cd SmartCampus_Portable
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python init_db.py
python app.py
```

Open **http://127.0.0.1:5050**

> If `python` resolves to the Microsoft Store stub on Windows, use the absolute path to your real Python interpreter, e.g. `C:\path\to\python.exe app.py`.

---

## Demo Accounts

| Username | Role       | Default Password |
|----------|------------|------------------|
| admin    | Admin      | set in `.env`    |
| staff    | User       | set in `.env`    |
| dev      | Developer  | set in `.env`    |

> All seeded accounts are created with `must_change_password = 1`. They will be prompted to set a new password on first login.
> Default passwords are in `.env` (copy `.env.example` to `.env`).

---

## Troubleshooting

### "I can't log in" / "Pages redirect to /login"

The admin password may have been changed by a test script or forgotten. Reset it without losing data:

```bash
# Outside container
python tools/restore_admin.py

# Inside running container
docker exec smartcampus python /app/tools/restore_admin.py

# Custom password
python tools/restore_admin.py NewPassword123
```

Or reset by re-seeding (this **keeps** existing devices/equipment/telemetry):

```bash
docker exec smartcampus python /app/init_db.py --reset-admin
```

### "Devices show Awaiting status"

The simulator isn't running. Start it from the host:

```bash
pip install requests
python tools/fake_iot_devices.py --api-key <your DEVICE_API_KEY>
```

See `tools/README.md` for full simulator docs.

> **Note:** As of v1.1.0, the in-Flask background simulator automatically generates readings for registered devices, so manual `fake_iot_devices.py` is no longer required for the demo to show "Live" status.

---

## Moving to a New Laptop

See the dedicated guides below for moving Smart Campus to another laptop:

- **[MOVE.md](MOVE.md)** — full step-by-step migration guide (4 paths: Docker image, Code ZIP, Bare Python, Git)
- **MIGRATE.bat / MIGRATE.sh** — one-click interactive migration helper (in the project root)
- **tools/preflight.py** — pre-flight check (Python, Docker, disk, port, artifact checksums)

Run `python tools/release.py` first to regenerate the `dist/` artifacts before moving.

---

## Project Structure

```
SmartCampus_Portable/
├── app.py                     Flask application (routes + RBAC middleware)
├── init_db.py                 Database schema + seed data
├── requirements.txt           Python dependencies
├── README.md                  This file
├── instance/                  SQLite database folder (auto-created)
├── templates/                 Jinja2 HTML templates
│   ├── base.html              Shared layout (navbar, footer, flash messages)
│   ├── login.html             Sign-in page
│   ├── dashboard.html         Operations dashboard
│   ├── telemetry.html         Live sensor charts
│   ├── equipment.html         Equipment monitoring
│   ├── maintenance.html       Maintenance ticket workflow
│   └── developer.html         Developer profile + system stats
├── static/
│   ├── css/custom.css         Custom Bootstrap styling
│   └── js/
│       ├── charts.js          Chart.js live charts (SSE + /latest snapshot)
│       ├── equipment.js       Admin equipment override
│       └── maintenance.js     Admin ticket status update
└── docs/                      Assignment documentation
    ├── 02_schedule.md         200-hour schedule + Gantt + Risk Register
    ├── 03_uml.md              UML diagrams (Use Case, ERD, Sequence, Class)
    └── 04_wireframes.md       UI wireframe specifications
```

---

## Tech Stack

| Layer    | Technology                    |
|----------|-------------------------------|
| Backend  | Python 3.10+ · Flask 3.0      |
| Database | SQLite 3 (file-based)         |
| Security | bcrypt 4.2 password hashing   |
| Frontend | Jinja2 · Bootstrap 5.3        |
| Charts   | Chart.js 4.4                  |
| Icons    | Bootstrap Icons 1.11          |

---

## Features

- **Authentication:** Session-based login with bcrypt password hashing (cost=12)
- **Password Policy (Moderate):** Min 8 chars, must contain uppercase + lowercase + digit; blocklist of 33 common passwords; cannot equal username
- **User Management (Admin):** Add / edit / deactivate / reset passwords via `/admin/users` page with modal forms
- **Self-Service Password Change:** `/profile` page with live strength meter (red/yellow/green)
- **Force Default-Change:** Seeded users and admin-reset users must change password on first login
- **Last-Admin Guard:** Cannot demote or deactivate the last active Admin (returns 409)
- **RBAC:** Three roles (Admin / User / Developer) with route-level decorators — `@admin_required` for strict admin gates
- **KPI Dashboard:** Live metric cards on the equipment page (Total Assets, Active Outages, Maintenance Required, Operational Score %)
- **Live Telemetry:** 24-hour rolling line charts for Temperature, Humidity, Air Quality, **Energy (kW)** and **CO₂ (ppm)** — SSE push via `/api/telemetry/stream`, with a one-shot `/api/telemetry/latest` snapshot at page load
- **Equipment Monitoring:** Status badges with contextual colors + Bootstrap Icons, RBAC-guarded inline admin override via compact `input-group`
- **Equipment CRUD (Admin):** Add, edit, and delete equipment via a single Bootstrap modal — toggleable between Add/Edit modes — with category classification (HVAC, Lighting, Security, Plumbing, Electrical, Other)
- **Search & Filter:** Real-time text search + status filter + category filter for the equipment table
- **Admin Override:** Admin-only status changes with audit trail (`last_inspected` timestamp) + dynamic flash feedback (`alert-success`)
- **Maintenance Tickets:** Bootstrap modal submission for any authenticated user; lifecycle dropdown (Pending → In Progress → Resolved → Rejected) for Admins; each ticket can optionally link to a specific equipment (FK) with auto-filled Location and Category fields
- **Audit Log Session (Admin):** `/audit` page with role-tinted rows (red for Admin, cyan for Developer, blue for User/Staff), filter by user/entity/date, click-to-expand JSON details, action-name whitelist preventing fabricated entries
- **Dark / Light Theme:** Persistent theme toggle in the navbar with `localStorage` and `prefers-color-scheme` OS fallback
- **Pulse Indicator:** Animated red dot for offline equipment
- **Developer Profile:** System stats, build info, audit log viewer
- **Responsive:** Mobile, tablet, desktop layouts (table wrapped in `<div class="table-responsive">`)
- **Migration Tooling:** `tools/release.py` produces 3 artifacts (code ZIP, data tar, Docker image tar) for laptop-to-laptop moves
- **Pre-flight Check:** `tools/preflight.py` validates destination laptop before migration (Python, Docker, disk, port, artifact checksums)
- **One-Click Migration Helper:** `MIGRATE.bat` (Windows) and `MIGRATE.sh` (macOS/Linux) guide the user through Path A / B / C / D on the destination laptop

---

## Simulating IoT Devices (Demo)

For demos or development without buying physical hardware, use the bundled fake IoT fleet script:

```bash
pip install requests
python tools/fake_iot_devices.py --api-key <your DEVICE_API_KEY>
```

This spawns 5 simulated ESP32-class devices that POST to the same `/api/telemetry/ingest` endpoint real hardware would use:

| Sensor ID | Location | Reports | Pattern |
|---|---|---|---|
| `esp32-library-001`    | Library 3F     | Temperature, Humidity | Comfort (warmer midday) |
| `esp32-lab3-002`       | Lab 3          | Air Quality, CO2      | Occupancy (rises 9-17) |
| `esp32-gym-003`        | Gym            | Energy (kW)           | Occupancy |
| `esp32-serverroom-004` | Server Room    | Temperature, Humidity | Stable (climate-controlled) |
| `esp32-cafeteria-005`  | Cafeteria      | CO2, Air Quality      | Lunch (peak 11-13) |

Open `/devices` (Admin/Developer) to see the live fleet with per-device status.

See `tools/README.md` for CLI flags and behavior.

## Connecting Real Sensors

The system supports connecting physical sensors via HTTP POST API.

### Quick Start

1. **Set environment variables:**
   ```bash
   export SENSOR_MODE=real
   export DEVICE_API_KEY=$(openssl rand -hex 32)
   ```

2. **Post a reading:**
   ```bash
   curl -X POST http://localhost:5050/api/telemetry/ingest \
     -H "Content-Type: application/json" \
     -H "X-API-Key: $DEVICE_API_KEY" \
     -d '{"sensor_type":"Temperature","reading_value":23.5,"unit":"C","sensor_id":"esp32-001","location":"Library 3F"}'
   ```

3. **Check the Telemetry page** — the reading should appear in the Temperature chart.

### Supported Sensor Types

| Type | Unit | Example Hardware |
|---|---|---|
| Temperature | C | DHT22, DS18B20 |
| Humidity | % | DHT22, BME280 |
| Air Quality | AQI | PMS5003, SDS011 |
| Energy | kW | SCT-013 (CT clamp) |
| CO2 | ppm | MH-Z19B, SCD30 |

### Full Integration Guide

See **[docs/SENSOR_INTEGRATION.md](docs/SENSOR_INTEGRATION.md)** for:
- ESP32 Arduino sketch (WiFi + DHT22)
- Raspberry Pi Python script
- Industrial PLC / Modbus gateway
- MQTT architecture (future phase)
- Hardware shopping list ($10-25 per node)

---

## Routes

| Route                          | Method     | Access          |
|--------------------------------|------------|-----------------|
| `/login`                       | GET, POST  | Public          |
| `/logout`                      | GET        | Authenticated   |
| `/`                            | GET        | Authenticated — Dashboard |
| `/telemetry`                   | GET        | Authenticated   |
| `/equipment`                   | GET        | Authenticated   |
| `/maintenance`                 | GET        | Authenticated   |
| `/developer`                   | GET        | Authenticated   |
| `/api/telemetry/latest`        | GET        | Authenticated   |
| `/api/telemetry/ingest`        | POST       | **Device API key** | Sensor data ingest (X-API-Key header) |
| `/api/telemetry/ingest-ui`     | POST       | **Admin / Developer** | Server-side proxy for browser test form |
| `/sensors`                     | GET        | **Admin / Developer** | Sensor management UI |
| `/devices`                     | GET        | **Admin / Developer** | Live IoT device fleet (status per sensor_id) |
| `/api/telemetry/stream`        | GET        | Authenticated   | Server-Sent Events stream of new readings |
| `/api/equipment/<id>/status`   | POST       | **Admin only**  |
| `/api/equipment`               | POST       | **Admin only**  |
| `/api/equipment/<id>`          | PUT        | **Admin only**  |
| `/api/equipment/<id>`          | DELETE     | **Admin only**  | (returns 409 if tickets reference the equipment) |
| `/profile`                     | GET, POST  | Authenticated   | Self-service password change |
| `/admin/users`                 | GET        | **Admin only**  | User management page |
| `/api/users`                   | POST       | **Admin only**  | Create user |
| `/api/users/<id>`              | PUT        | **Admin only**  | Update full_name / role / is_active (last-admin guarded) |
| `/api/users/<id>`              | DELETE     | **Admin only**  | Deactivate user (soft delete via `is_active=0`) |
| `/api/users/<id>/password`     | POST       | **Admin only**  | Admin reset password (forces change on next login) |
| `/api/tickets`                 | POST       | Authenticated   |
| `/api/tickets/<id>/status`     | POST       | **Admin only**  |

---

## Transfer to Another Laptop

The simplest path is the one-click migration helper, which lives in the project root:

- **Windows**: copy the project folder + `dist/` to the new laptop, then double-click `MIGRATE.bat`
- **macOS / Linux**: copy the project folder + `dist/`, then run `./MIGRATE.sh` (chmod +x first if needed)

The helper:
1. Runs `tools/preflight.py` to validate the destination
2. Asks which path to use (Docker image / Code ZIP / Bare Python / Git)
3. Executes the chosen path
4. Optionally restores the database backup
5. Opens `http://localhost:5050` in the browser

For manual / advanced migration see **[MOVE.md](MOVE.md)** which documents four paths in detail.

---
2. **Verify Python 3.10+** is installed: `python --version`
3. **Run the Quick Start commands** above
4. **Database** is auto-created in `instance/smart_campus.db` on first run via `init_db.py`

### Requirements

- Python 3.10 or later (tested on 3.12)
- ~50 MB disk space (including venv)
- No other system dependencies — SQLite is built into Python
- Internet access only for `pip install` step

### Troubleshooting

- **Port 5050 in use:** Edit last line of `app.py`, change `port=5050` to another (e.g., 5051, 5001)
- **Module not found:** Ensure venv is activated before running
- **Database locked:** Close any running Flask instance before re-running

---

## Security Notes

- `SECRET_KEY` in `app.py` is a placeholder — change it for production use
- All SQL queries use parameterized statements (SQL-injection safe)
- Passwords stored as bcrypt hashes (never plaintext)
- Session cookies are HTTP-only with SameSite=Lax
- `@admin_required` decorator strictly enforces `role == 'Admin'` — Developer role no longer has admin write access
- Status/ticket updates return JSON feedback (`{ok, type, message}`) — client JS injects a Bootstrap `alert-success` / `alert-danger` into the `#alerts` anchor
- `/api/telemetry/latest` and `/static/js/charts.js` are served with `Cache-Control: no-store` to guarantee fresh chart data (after_request hook in `app.py`)
- Client-side `window.onerror` + `unhandledrejection` handlers in `base.html` surface JS errors as visible Bootstrap toasts at the top of every page

---

## Performance Notes (v1.1.0)

| Optimization | Effect |
|---|---|
| Telemetry INSERTs throttled to 30 s per sensor | ~95% reduction in DB writes (60/min → 5/min) |
| Telemetry timestamps staggered by i seconds per sensor | Each tick writes 5 distinct timestamps → smooth chart line, no label collisions |
| `Cache-Control: no-store` on `/api/*` and `charts.js` | Browser never serves stale chart data |
| `Cache-Control: max-age=3600` on other static assets | Faster repeat page loads for CSS / fonts / icons |
| `waitress.serve()` WSGI server (8 threads) | Production-grade, replaces Flask dev server |
| `SEND_FILE_MAX_AGE_DEFAULT = 3600` | Default 1-hour cache for any unconfigured static file |
| HH:MM:SS label format + `ticks.autoSkip: true` | All 24 labels unique; X-axis shows 8 evenly-spaced labels |

---

## License

© 2026 Chit Snow Wai — Educational use.

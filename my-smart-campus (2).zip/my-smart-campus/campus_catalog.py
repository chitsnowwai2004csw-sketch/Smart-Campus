"""University campus catalog: 3 blocks x 5 floors x room lists (no basement).

Single source of truth used by:
- init_db.py (fresh install)
- app.py ensure_schema() (idempotent backfill for existing DBs)
"""

# (building_code, floor_number, label)
# floor_number 1..5 = numbered floors (no basement)
UNIVERSITY_FLOORS = [
    ("A",  1, "Floor 1"),
    ("A",  2, "Floor 2"),
    ("A",  3, "Floor 3"),
    ("A",  4, "Floor 4"),
    ("A",  5, "Floor 5"),
    ("B",  1, "Floor 1"),
    ("B",  2, "Floor 2"),
    ("B",  3, "Floor 3"),
    ("B",  4, "Floor 4"),
    ("B",  5, "Floor 5"),
    ("C",   1, "Floor 1"),
    ("C",   2, "Floor 2"),
    ("C",   3, "Floor 3"),
    ("C",   4, "Floor 4"),
    ("C",   5, "Floor 5"),
]

# Block A — Academic / Library Block
_A_ROOMS = {
     1: ["Main Lobby", "Reception", "Auditorium", "Information Desk", "Stairwell", "Toilet", "Corridor"],
     2: ["Library", "Study Room", "Reading Room", "Periodicals Section", "Stairwell", "Toilet", "Corridor"],
     3: ["Computer Lab", "Lecture Hall 1", "Stairwell", "Toilet", "Corridor"],
     4: ["Lecture Hall 2", "Lecture Hall 3", "Stairwell", "Toilet", "Corridor"],
     5: ["Faculty Offices", "Dean's Office", "Meeting Room", "Stairwell", "Toilet", "Corridor"],
}

# Block B — Laboratory / Research Block
_B_ROOMS = {
     1: ["Main Lobby", "Lab Coordinator Office", "Lab 1 (Physics)", "Lab 2 (Chemistry)", "Stairwell", "Toilet", "Corridor"],
     2: ["Lab 3 (Biology)", "Lab 4 (Electronics)", "Lab 5 (Programming)", "Stairwell", "Toilet", "Corridor"],
     3: ["Research Lab 1", "Research Lab 2", "Instrumentation Room", "Stairwell", "Toilet", "Corridor"],
     4: ["Seminar Room A", "Seminar Room B", "Faculty Offices", "Stairwell", "Toilet", "Corridor"],
     5: ["PhD Lab", "Meeting Room", "Sky Bridge", "Stairwell", "Toilet", "Corridor"],
}

# Block C — Student Services / Administration Block
_C_ROOMS = {
     1: ["Main Lobby", "Reception", "Security Office", "Cafeteria", "Kitchen", "Stairwell", "Toilet", "Corridor"],
     2: ["Gym", "Gym Storage", "Student Lounge", "Music Room", "Stairwell", "Toilet", "Corridor"],
     3: ["Auditorium", "Multipurpose Hall", "Stairwell", "Toilet", "Corridor"],
     4: ["Administrative Offices", "Registrar", "Finance Office", "Conference Room", "Stairwell", "Toilet", "Corridor"],
     5: ["Health Clinic", "Counseling Office", "Vice Chancellor Office", "Stairwell", "Toilet", "Corridor"],
}

UNIVERSITY_ROOMS = []
for code, rooms_by_floor in [("A", _A_ROOMS), ("B", _B_ROOMS), ("C", _C_ROOMS)]:
    for floor_number in sorted(rooms_by_floor.keys()):
        for name in rooms_by_floor[floor_number]:
            UNIVERSITY_ROOMS.append((code, floor_number, name))


# Skills catalog for the developer profile multi-select dropdown.
# Source of truth — also used by the backend validator to reject unknown skills.
SKILLS_CATALOG = [
    "Python", "Flask", "SQLite", "JavaScript", "HTML/CSS",
    "Bootstrap", "Chart.js", "MQTT", "ESP32", "Arduino",
    "REST APIs", "Docker", "Linux", "Networking", "SQL",
    "Git", "CI/CD", "Unit Testing", "IoT Security",
    "Cloud (AWS/Azure)", "React", "Node.js", "Vue.js",
    "TypeScript", "Postman",
]


# Best-fit migration map for existing equipment rows.
# (source_location_substring_lowercase, building_code, floor_number, room_name)
EQUIPMENT_LOCATION_BACKFILL = {
    "block a - floor 1":      ("A",  1, "Main Lobby"),
    "block a - floor 2":      ("A",  2, "Library"),
    "block b - lobby":        ("B",  1, "Main Lobby"),
    "block b - library":      ("B",  4, "Seminar Room A"),
    "block c - basement":     ("C", -1, "Electrical Room"),
    "block a - all floors":   ("A",  1, "Corridor"),
    "block c - lab 3":        ("C",  2, "Student Lounge"),
    "block c - server room":  ("C", -1, "IT Server Room"),
}

#!/usr/bin/env bash
# Smart Campus - One-click stop (macOS / Linux)
# Stops and removes the running container (preserves DB volume).

set -e

echo "============================================"
echo " Smart Campus - Stop (macOS/Linux)"
echo "============================================"
echo

if ! command -v docker >/dev/null 2>&1; then
    echo "[ERROR] Docker is not installed."
    exit 1
fi

echo "Stopping container..."
docker compose down

echo
echo "Container stopped. Database volume preserved."
echo "To start again:  ./start.sh"
echo "To wipe DB and start:  ./reset.sh"

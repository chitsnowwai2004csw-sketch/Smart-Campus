# Run SmartCampus in VS Code (no Docker)

Works on a second laptop with only **Python 3.10+** and **VS Code**.

## Login (shipped database)

| User  | Password    | Notes |
|-------|-------------|--------|
| admin | `Admin1234!` | Ready — no forced change |
| staff | `staff123`  | Must change password on first login |
| dev   | `dev123`    | Must change password on first login |

URL after start: **http://127.0.0.1:5050**

---

## Steps

### 1. Install (once per laptop)

- **Python 3.10+** — https://www.python.org/downloads/  
  (Windows: tick **“Add python.exe to PATH”**)
- **VS Code** — https://code.visualstudio.com/

### 2. Open the project

1. Unzip / copy this folder to the laptop  
2. VS Code → **File → Open Folder…** → select `SmartCampus_Portable`

### 3. Install dependencies (once)

**Terminal → Run Task… → `Setup: create venv + install requirements`**

Or paste in the terminal:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

macOS / Linux:

```bash
python3 -m venv .venv
./.venv/bin/python -m pip install -r requirements.txt
```

Accept the recommended **Python** extension if VS Code prompts.

### 4. Start the app

Press **F5** (or Run → Start Debugging) and choose:

- **SmartCampus: Run (port 5050)**  
  — if 5050 is busy, use **SmartCampus: Run (port 5051 if 5050 busy)**

Or Terminal → Run Task… → **Run: start app (venv python)**

### 5. Open the browser

http://127.0.0.1:5050  
Login: **admin** / **Admin1234!**

### 6. Stop

In VS Code: **Shift+F5** (stop debugging), or close the terminal, or Ctrl+C.

---

## Important safety notes

- **`python init_db.py` will NOT wipe** an existing database (it skips if users exist).  
- Factory reset only if you really want empty demo data:

  ```powershell
  .\.venv\Scripts\python.exe init_db.py --force-reseed
  ```

- Data lives in `instance\smart_campus.db` — keep this file when moving the project.

---

## Optional: reset admin password

```powershell
.\.venv\Scripts\python.exe tools\restore_admin.py Admin1234!
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `python` not found | Reinstall Python with “Add to PATH”, or use full path to `python.exe` |
| Port already in use | F5 → **port 5051** config, or `set PORT=5051` then run `app.py` |
| Module not found | Run the **Setup** task again; ensure interpreter is `.venv` |
| Wrong password | Use **admin / Admin1234!** (not `admin123` unless you reseeded old defaults) |
| Need demo data again | `python init_db.py --force-reseed` |

Docker is **not required** for this workflow.

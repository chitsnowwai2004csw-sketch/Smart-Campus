@echo off
REM ============================================================
REM   Smart Campus Migration Helper (Windows)
REM   Version: 1.1.0
REM   Run this script on the DESTINATION laptop.
REM ============================================================

setlocal ENABLEDELAYEDEXPANSION

echo.
echo ============================================================
echo   Smart Campus Migration Helper v1.1.0
echo ============================================================
echo.
echo This script helps you move Smart Campus to a new laptop.
echo Before continuing, copy the dist\ folder here (USB, cloud, etc.).
echo.

if not exist "dist\MANIFEST.txt" (
    echo [ERROR] dist\MANIFEST.txt not found.
    echo Please copy the entire dist\ folder into this directory first.
    pause
    exit /b 1
)

echo Pre-flight check:
echo.
python tools\preflight.py
if errorlevel 1 (
    echo.
    echo [ERROR] Pre-flight failed. Resolve issues above before continuing.
    pause
    exit /b 1
)

echo.
echo Migration paths:
echo   [A] Docker image   (fastest, ~45 MB, no Python needed)
echo   [B] Code ZIP       (standard, ~124 KB, builds on site)
echo   [C] Bare Python    (no Docker, requires Python 3.12)
echo   [D] Git repository (for ongoing development)
echo.
set /p CHOICE="Enter choice [A/B/C/D]: "

if /i "%CHOICE%"=="A" goto :path_a
if /i "%CHOICE%"=="B" goto :path_b
if /i "%CHOICE%"=="C" goto :path_c
if /i "%CHOICE%"=="D" goto :path_d
echo [ERROR] Invalid choice: %CHOICE%
pause
exit /b 1

:path_a
echo.
echo ============================================================
echo   Path A: Docker image
echo ============================================================
docker load -i dist\smartcampus-v1.1.0-image.tar
if errorlevel 1 (
    echo [ERROR] docker load failed.
    pause
    exit /b 1
)
echo.
echo Cleaning up any old container named 'smartcampus'...
docker rm -f smartcampus 2^>nul
echo.
echo Starting container...
docker run -d --name smartcampus -p 5050:5050 ^
    -v smartcampus_data:/app/instance ^
    -e SENSOR_MODE=simulator ^
    -e DEVICE_API_KEY=test-key-123 ^
    smartcampus:1.1.0
if errorlevel 1 (
    echo [ERROR] docker run failed.
    pause
    exit /b 1
)
echo.
echo Waiting for container healthcheck...
set /a attempts=0
:wait_health_a
set /a attempts+=1
if %attempts% gtr 20 (
    echo [WARNING] Container did not become healthy within 20s.
)
for /f "delims=" %%i in ('docker inspect --format="{{.State.Health.Status}}" smartcampus 2^>nul') do set HEALTH=%%i
if /i "%HEALTH%"=="healthy" goto :health_ready_a
timeout /t 1 /nobreak >nul
goto :wait_health_a
:health_ready_a
echo Container is healthy.
goto :restore_data

:path_b
echo.
echo ============================================================
echo   Path B: Code ZIP
echo ============================================================
if exist smartcampus-code-v1.1.0 (
    echo Code folder already exists.
) else (
    echo Unzipping dist\smartcampus-code-v1.1.0.zip...
    powershell -Command "Expand-Archive -Path dist\smartcampus-code-v1.1.0.zip -DestinationPath . -Force"
    if errorlevel 1 (
        echo [ERROR] unzip failed.
        pause
        exit /b 1
    )
)
echo.
echo Building and starting...
cd smartcampus-code-v1.1.0
start.bat
cd ..
goto :restore_data

:path_c
echo.
echo ============================================================
echo   Path C: Bare Python
echo ============================================================
echo Requirements: Python 3.10+
echo.
set /p PYTHON="Path to python.exe (leave blank for 'python'): "
if "%PYTHON%"=="" set PYTHON=python
%PYTHON% --version
if errorlevel 1 (
    echo [ERROR] Python not found.
    pause
    exit /b 1
)
if exist smartcampus-code-v1.1.0 (
    echo Code folder already exists.
) else (
    echo Unzipping dist\smartcampus-code-v1.1.0.zip...
    powershell -Command "Expand-Archive -Path dist\smartcampus-code-v1.1.0.zip -DestinationPath . -Force"
)
cd smartcampus-code-v1.1.0
%PYTHON% -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
python init_db.py
start.bat /k "set FLASK_APP=app.py^&^& python app.py"
cd ..
goto :restore_data

:path_d
echo.
echo ============================================================
echo   Path D: Git
echo ============================================================
echo Run 'git init' in the project folder if not already a git repo,
echo then push to your remote. On the destination, 'git clone' and run start.bat.
pause
exit /b 0

:restore_data
echo.
echo ============================================================
echo   Restore Data (optional)
echo ============================================================
if exist "dist\smartcampus-data-v1.1.0.tar.gz" (
    set /p RESTORE="Restore existing database from backup? [Y/N]: "
    if /i "!RESTORE!"=="Y" (
        echo Restoring data...
        python tools\load_data.py dist\smartcampus-data-v1.1.0.tar.gz
        if errorlevel 1 (
            echo [WARNING] Data restore failed. Container has fresh DB.
        )
    )
) else (
    echo No data backup found - container will use fresh seed data.
)

echo.
echo ============================================================
echo   Smart Campus started successfully!
echo ============================================================
echo.
echo   URL: http://localhost:5050
echo.
echo   Credentials (from the SOURCE laptop's current state):
echo     admin / Admin1234!
echo     staff / staff123   (will be prompted to change password on first login)
echo     dev   / dev123     (will be prompted to change password on first login)
echo.
echo   Note: if you skipped data restore, reset admin with:
echo     docker exec smartcampus python /app/tools/restore_admin.py Admin1234!
echo.

start "" "http://localhost:5050"
echo Browser opening...
echo.
echo Press any key to stop the container and exit.
pause
echo Stopping container...
docker stop smartcampus 2^>nul
endlocal
